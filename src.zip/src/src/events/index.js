/**
 * Agrégateur d'événements
 * Exporte tous les handlers d'événements sous forme de tableau plat
 * Le eventHandler.js charge ce fichier pour enregistrer chaque listener
 */

// Note : ce fichier n'est PAS chargé directement par eventHandler.js
// car eventHandler.js lit les fichiers .js du dossier events/
// Les fichiers qui exportent un tableau sont gérés ci-dessous

module.exports = [];

/**
 * Événement : ready
 * Déclenché quand le bot est connecté et prêt
 */

const { ActivityType } = require('discord.js');

module.exports = {
  name: 'clientReady',
  once: true,
  async execute(client) {
    console.log(`[BOT] Connecté en tant que ${client.user.tag}`);
    console.log(`[BOT] Présent sur ${client.guilds.cache.size} serveur(s)`);

    // Définir le statut du bot
    client.user.setPresence({
      activities: [{ name: '/help | Bot Pro', type: ActivityType.Watching }],
      status: 'online',
    });
  },
};

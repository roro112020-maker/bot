/**
 * Anti-Nuke + Anti-Raid
 * Anti-Nuke : suppression massive salons/rôles, bans en masse
 * Anti-Raid : mass-joins → lockdown automatique du serveur
 */

const { Events, EmbedBuilder, AuditLogEvent, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, addModLog } = require('../handlers/database');

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getUserLog(client, guildId, userId) {
  const key = `${guildId}:${userId}`;
  if (!client.antiNukeLog.has(key)) client.antiNukeLog.set(key,{ channelDeletes:[], roleDeletes:[], bans:[] });
  return client.antiNukeLog.get(key);
}

function countRecent(times, windowSec) {
  const cutoff = Date.now()-windowSec*1000;
  return times.filter(t=>t>cutoff).length;
}

async function alertLog(guild, config, title, description, perpetrator) {
  if (!config.log_channel) return;
  const ch = guild.channels.cache.get(config.log_channel);
  if (!ch) return;
  const embed = new EmbedBuilder()
    .setTitle(`🚨 ALERTE SÉCURITÉ — ${title}`)
    .setDescription(description)
    .setColor(0xff0000)
    .addFields({ name:'Responsable', value:`${perpetrator?.tag||perpetrator?.user?.tag||'Inconnu'} (${perpetrator?.id||'?'})`, inline:true })
    .setTimestamp();
  await ch.send({ embeds:[embed] }).catch(()=>{});
}

async function sanctionMember(guild, userId, reason) {
  try { await guild.members.ban(userId,{ reason, deleteMessageSeconds:0 }); console.log(`[ANTI-NUKE] Banni : ${userId}`); }
  catch { try { const m=await guild.members.fetch(userId).catch(()=>null); if(m) await m.kick(reason); } catch {} }
}

async function getAuditExecutor(guild, actionType, targetId) {
  try {
    await new Promise(r=>setTimeout(r,800));
    const logs  = await guild.fetchAuditLogs({ type:actionType, limit:3 });
    const entry = logs.entries.find(e=>!targetId||e.target?.id===targetId);
    return entry?.executor||null;
  } catch { return null; }
}

// ─── Anti-Nuke : suppression de salons ────────────────────────────────────────
const channelDeleteHandler = {
  name: Events.ChannelDelete,
  once: false,
  async execute(channel, client) {
    if (!channel.guild) return;
    const config = getGuildConfig(channel.guild.id);
    if (!config.antinuke_enabled) return;
    const executor = await getAuditExecutor(channel.guild, AuditLogEvent.ChannelDelete, channel.id);
    if (!executor||executor.id===client.user.id) return;
    const log   = getUserLog(client, channel.guild.id, executor.id);
    log.channelDeletes.push(Date.now());
    const count = countRecent(log.channelDeletes, config.antinuke_window||10);
    if (count>=(config.antinuke_threshold||5)) {
      log.channelDeletes=[];
      await sanctionMember(channel.guild, executor.id, `[Anti-Nuke] ${count} salons supprimés en ${config.antinuke_window}s`);
      addModLog(channel.guild.id,'ANTINUKE_CHANNEL',executor.id,client.user.id,`Suppression massive salons`,String(count));
      await alertLog(channel.guild,config,'Suppression massive de salons',`**${count}** salons supprimés en **${config.antinuke_window}s**.`,executor);
    }
  },
};

// ─── Anti-Nuke : suppression de rôles ─────────────────────────────────────────
const roleDeleteHandler = {
  name: Events.GuildRoleDelete,
  once: false,
  async execute(role, client) {
    const config = getGuildConfig(role.guild.id);
    if (!config.antinuke_enabled) return;
    const executor = await getAuditExecutor(role.guild, AuditLogEvent.RoleDelete, role.id);
    if (!executor||executor.id===client.user.id) return;
    const log   = getUserLog(client, role.guild.id, executor.id);
    log.roleDeletes.push(Date.now());
    const count = countRecent(log.roleDeletes, config.antinuke_window||10);
    if (count>=(config.antinuke_threshold||5)) {
      log.roleDeletes=[];
      await sanctionMember(role.guild, executor.id, `[Anti-Nuke] ${count} rôles supprimés en ${config.antinuke_window}s`);
      addModLog(role.guild.id,'ANTINUKE_ROLE',executor.id,client.user.id,`Suppression massive rôles`,String(count));
      await alertLog(role.guild,config,'Suppression massive de rôles',`**${count}** rôles supprimés en **${config.antinuke_window}s**.`,executor);
    }
  },
};

// ─── Anti-Nuke : bans en masse ─────────────────────────────────────────────────
const banAddHandler = {
  name: Events.GuildBanAdd,
  once: false,
  async execute(ban, client) {
    const config = getGuildConfig(ban.guild.id);
    if (!config.antinuke_enabled) return;
    const executor = await getAuditExecutor(ban.guild, AuditLogEvent.MemberBanAdd, ban.user.id);
    if (!executor||executor.id===client.user.id) return;
    const log   = getUserLog(client, ban.guild.id, executor.id);
    log.bans.push(Date.now());
    const count = countRecent(log.bans, config.antinuke_window||10);
    if (count>=(config.antinuke_threshold||5)) {
      log.bans=[];
      await sanctionMember(ban.guild, executor.id, `[Anti-Nuke] ${count} bans en ${config.antinuke_window}s`);
      addModLog(ban.guild.id,'ANTINUKE_BAN',executor.id,client.user.id,`Bans massifs`,String(count));
      await alertLog(ban.guild,config,'Bans massifs',`**${count}** bans en **${config.antinuke_window}s**.`,executor);
    }
  },
};

// ─── Anti-Raid : mass joins ────────────────────────────────────────────────────
// Suivi des joins récents par guild
const raidJoinMap = new Map(); // guildId -> [timestamps]
const raidLocked  = new Set(); // guilds actuellement en mode raid

const memberAddRaidHandler = {
  name: Events.GuildMemberAdd,
  once: false,
  async execute(member, client) {
    const config = getGuildConfig(member.guild.id);
    if (!config.antiraid_enabled) return;
    const joins    = config.antiraid_joins||10;
    const window   = config.antiraid_window||10;
    const guildId  = member.guild.id;

    if (!raidJoinMap.has(guildId)) raidJoinMap.set(guildId,[]);
    const times = raidJoinMap.get(guildId).filter(t=>Date.now()-t<window*1000);
    times.push(Date.now());
    raidJoinMap.set(guildId, times);

    if (times.length>=joins&&!raidLocked.has(guildId)) {
      raidLocked.add(guildId);
      raidJoinMap.set(guildId,[]);

      // Lockdown : empêcher @everyone d'envoyer des messages
      try {
        await member.guild.roles.everyone.setPermissions(
          member.guild.roles.everyone.permissions.remove(PermissionFlagsBits.SendMessages),
          '[Anti-Raid] Raid détecté — lockdown automatique'
        );
      } catch(e) { console.error('[ANTIRAID] Lockdown échoué:', e.message); }

      addModLog(guildId,'ANTIRAID',guildId,client.user.id,`Raid détecté : ${times.length} joins en ${window}s`,null);

      if (config.log_channel) {
        const logCh = member.guild.channels.cache.get(config.log_channel);
        if (logCh) {
          const embed = new EmbedBuilder()
            .setTitle('🚨 RAID DÉTECTÉ — Lockdown automatique activé !')
            .setDescription(`**${times.length}** membres ont rejoint en moins de **${window} secondes**.\n\n🔒 Le serveur est maintenant en **lockdown** (personne ne peut écrire).\n\nPour déverrouiller : \`/unlockdown\` dans chaque salon, ou retire manuellement le lockdown.`)
            .setColor(0xff0000).setTimestamp();
          await logCh.send({ embeds:[embed] }).catch(()=>{});
        }
      }

      // Auto-déverrouillage après 5 minutes
      setTimeout(async () => {
        raidLocked.delete(guildId);
        try {
          await member.guild.roles.everyone.setPermissions(
            member.guild.roles.everyone.permissions.add(PermissionFlagsBits.SendMessages),
            '[Anti-Raid] Fin du lockdown automatique'
          );
          if (config.log_channel) {
            const logCh = member.guild.channels.cache.get(config.log_channel);
            if (logCh) await logCh.send({ content:'✅ Lockdown anti-raid levé automatiquement après 5 minutes.' }).catch(()=>{});
          }
        } catch {}
      }, 5*60*1000);
    }
  },
};

module.exports = [channelDeleteHandler, roleDeleteHandler, banAddHandler, memberAddRaidHandler];

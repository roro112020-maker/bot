/**
 * Gestionnaire d'interactions (slash commands, boutons)
 * Tickets, Reaction Roles, Giveaways, Suggestions, Polls
 */

const {
  Collection, EmbedBuilder, ButtonBuilder, ButtonStyle,
  ActionRowBuilder, ChannelType, PermissionFlagsBits,
} = require('discord.js');
const {
  getGuildConfig, createTicket, getTicketByChannel, closeTicket, getTicketPanel,
  getGiveawayByMessage, updateGiveawayParticipants, getGiveaway,
  getRRPanelByMessage, getRRRoles,
  getSuggestionByMessage, updateSuggestionVotes,
} = require('../handlers/database');
const path  = require('path');
const fs    = require('fs');

module.exports = {
  name: 'interactionCreate',
  once: false,
  async execute(interaction, client) {

    // ── Slash Commands ────────────────────────────────────────────────────────
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;

      const { cooldowns } = client;
      if (!cooldowns.has(command.data.name)) cooldowns.set(command.data.name, new Collection());
      const now        = Date.now();
      const timestamps = cooldowns.get(command.data.name);
      const cooldown   = (command.cooldown??3)*1000;
      if (timestamps.has(interaction.user.id)) {
        const exp = timestamps.get(interaction.user.id)+cooldown;
        if (now<exp) {
          return interaction.reply({ content:`⏱️ Attends **${((exp-now)/1000).toFixed(1)}s** avant de réutiliser cette commande.`, ephemeral:true });
        }
      }
      timestamps.set(interaction.user.id, now);
      setTimeout(()=>timestamps.delete(interaction.user.id), cooldown);

      try { await command.execute(interaction, client); }
      catch(err) {
        console.error(`[CMD ERROR] /${interaction.commandName}:`, err);
        const msg = { content:'❌ Une erreur est survenue lors de l\'exécution.', ephemeral:true };
        if (interaction.replied||interaction.deferred) await interaction.followUp(msg).catch(()=>{});
        else await interaction.reply(msg).catch(()=>{});
      }
      return;
    }

    // ── Boutons ────────────────────────────────────────────────────────────────
    if (!interaction.isButton()) return;
    const { customId } = interaction;

    // ─ Tickets ─────────────────────────────────────────────────────────────
    if (customId.startsWith('open_ticket:')) {
      return handleOpenTicket(interaction, client, customId.slice('open_ticket:'.length));
    }
    if (customId==='close_ticket')  return handleCloseTicket(interaction, client);
    if (customId==='delete_ticket') return handleDeleteTicket(interaction);

    // ─ Giveaways ───────────────────────────────────────────────────────────
    if (customId.startsWith('giveaway_join:')) {
      return handleGiveawayJoin(interaction, customId.split(':')[1]);
    }

    // ─ Reaction Roles ──────────────────────────────────────────────────────
    if (customId.startsWith('rr_toggle:')) {
      return handleRRToggle(interaction, customId.split(':')[1]);
    }

    // ─ Suggestions ─────────────────────────────────────────────────────────
    if (customId.startsWith('suggest_up:')||customId.startsWith('suggest_down:')) {
      return handleSuggestionVote(interaction, customId);
    }

    // ─ Polls ────────────────────────────────────────────────────────────────
    if (customId.startsWith('poll_vote:')) {
      return handlePollVote(interaction, customId);
    }
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// TICKETS
// ─────────────────────────────────────────────────────────────────────────────

async function handleOpenTicket(interaction, client, panelName) {
  const { guild, user } = interaction;
  const config = getGuildConfig(guild.id);
  const panel  = getTicketPanel(guild.id, panelName);
  const safeName = `ticket-${user.username.toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,16)}-${panelName.toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)}`;
  const existing = guild.channels.cache.find(ch=>ch.name===safeName);
  if (existing) return interaction.reply({ content:`❌ Tu as déjà un ticket ouvert : ${existing}`, ephemeral:true });

  await interaction.deferReply({ ephemeral:true });
  try {
    const categoryId = panel?.category_id||config.ticket_category;
    const ticketCh   = await guild.channels.create({
      name: safeName,
      type: ChannelType.GuildText,
      parent: categoryId||null,
      permissionOverwrites: [
        { id:guild.id, deny:[PermissionFlagsBits.ViewChannel] },
        { id:user.id,  allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory] },
        { id:guild.members.me.id, allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ManageChannels,PermissionFlagsBits.AttachFiles] },
        ...(config.mod_role?[{ id:config.mod_role, allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory] }]:[]),
      ],
    });
    createTicket(guild.id, ticketCh.id, user.id, panelName);

    const embed = new EmbedBuilder()
      .setTitle(`🎫 Ticket — ${panelName}`)
      .setDescription(panel?.message||'Bienvenue ! Un membre du staff va vous répondre rapidement.')
      .addFields({ name:'Créé par', value:`${user}`, inline:true })
      .setColor(parseInt(panel?.embed_color||'5865F2',16))
      .setTimestamp().setFooter({ text:`#${ticketCh.name}` });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('close_ticket').setLabel('🔒 Fermer').setStyle(ButtonStyle.Danger)
    );
    await ticketCh.send({ content:`${user}`, embeds:[embed], components:[row] });
    await interaction.editReply({ content:`✅ Ton ticket : ${ticketCh}` });
    await sendLog(client, guild, config, { title:'🎫 Ticket ouvert', color:0x5865f2, fields:[
      { name:'Utilisateur', value:`${user} (${user.id})`, inline:true },
      { name:'Panel', value:panelName, inline:true },
      { name:'Salon', value:`${ticketCh}`, inline:true },
    ]});
  } catch(err) {
    console.error('[TICKET]', err);
    await interaction.editReply({ content:'❌ Erreur lors de la création du ticket.' });
  }
}

async function handleCloseTicket(interaction, client) {
  const ticket = getTicketByChannel(interaction.channel.id);
  if (!ticket||ticket.status==='closed') return interaction.reply({ content:'❌ Ce salon n\'est pas un ticket ouvert.', ephemeral:true });
  closeTicket(interaction.channel.id);
  await interaction.channel.permissionOverwrites.edit(ticket.user_id, { SendMessages:false });

  // Générer un transcript texte
  await saveTranscript(interaction.channel);

  const config = getGuildConfig(interaction.guild.id);
  await sendLog(client, interaction.guild, config, { title:'🔒 Ticket fermé', color:0xed4245, fields:[
    { name:'Salon', value:interaction.channel.name, inline:true },
    { name:'Fermé par', value:`${interaction.user}`, inline:true },
  ]});

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('delete_ticket').setLabel('🗑️ Supprimer').setStyle(ButtonStyle.Danger)
  );
  await interaction.reply({ content:'🔒 Ticket fermé.', components:[row] });
}

async function handleDeleteTicket(interaction) {
  await interaction.reply({ content:'🗑️ Suppression dans 3 secondes...' });
  setTimeout(()=>interaction.channel.delete().catch(()=>{}), 3000);
}

async function saveTranscript(channel) {
  try {
    const messages = await channel.messages.fetch({ limit:100 });
    const lines    = [...messages.values()].reverse().map(m=>
      `[${new Date(m.createdTimestamp).toISOString()}] ${m.author.tag}: ${m.content||'<pièce jointe>'}`
    );
    const dir = path.join(__dirname,'../../data/transcripts');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir,{recursive:true});
    fs.writeFileSync(path.join(dir,`${channel.name}-${Date.now()}.txt`), lines.join('\n'));
  } catch {}
}

// ─────────────────────────────────────────────────────────────────────────────
// GIVEAWAYS
// ─────────────────────────────────────────────────────────────────────────────

async function handleGiveawayJoin(interaction, idStr) {
  const id = parseInt(idStr);
  const gw = getGiveaway(id);
  if (!gw||gw.ended) return interaction.reply({ content:'❌ Ce giveaway est terminé.', ephemeral:true });

  // Vérif rôle requis
  if (gw.required_role) {
    if (!interaction.member.roles.cache.has(gw.required_role)) {
      return interaction.reply({ content:`❌ Tu dois avoir le rôle <@&${gw.required_role}> pour participer.`, ephemeral:true });
    }
  }

  const participants = JSON.parse(gw.participants||'[]');
  if (participants.includes(interaction.user.id)) {
    // Retirer la participation
    const newList = participants.filter(p=>p!==interaction.user.id);
    updateGiveawayParticipants(id, newList);
    return interaction.reply({ content:'❌ Tu t\'es retiré(e) du giveaway.', ephemeral:true });
  }
  participants.push(interaction.user.id);
  updateGiveawayParticipants(id, participants);
  return interaction.reply({ content:`✅ Tu participes au giveaway **${gw.prize}** ! (${participants.length} participant(s))`, ephemeral:true });
}

// ─────────────────────────────────────────────────────────────────────────────
// REACTION ROLES
// ─────────────────────────────────────────────────────────────────────────────

async function handleRRToggle(interaction, roleId) {
  const role = interaction.guild.roles.cache.get(roleId);
  if (!role) return interaction.reply({ content:'❌ Rôle introuvable.', ephemeral:true });
  try {
    if (interaction.member.roles.cache.has(roleId)) {
      await interaction.member.roles.remove(role);
      return interaction.reply({ content:`✅ Rôle **${role.name}** retiré.`, ephemeral:true });
    } else {
      await interaction.member.roles.add(role);
      return interaction.reply({ content:`✅ Rôle **${role.name}** attribué.`, ephemeral:true });
    }
  } catch(err) {
    return interaction.reply({ content:`❌ Impossible de modifier le rôle : ${err.message}`, ephemeral:true });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SUGGESTIONS
// ─────────────────────────────────────────────────────────────────────────────

// Suivi des votes : Map<suggestionId, Set<userId>>
const suggestionVoters = new Map();

async function handleSuggestionVote(interaction, customId) {
  const parts   = customId.split(':');
  const type    = parts[0]; // suggest_up ou suggest_down
  const id      = parseInt(parts[1]);
  const suggestion = getSuggestionByMessage(interaction.message.id);
  if (!suggestion) return interaction.reply({ content:'❌ Suggestion introuvable.', ephemeral:true });

  if (!suggestionVoters.has(id)) suggestionVoters.set(id, new Set());
  const voters = suggestionVoters.get(id);

  if (voters.has(interaction.user.id)) {
    return interaction.reply({ content:'❌ Tu as déjà voté pour cette suggestion.', ephemeral:true });
  }
  voters.add(interaction.user.id);

  const upvotes   = type==='suggest_up'   ? suggestion.upvotes+1   : suggestion.upvotes;
  const downvotes = type==='suggest_down' ? suggestion.downvotes+1 : suggestion.downvotes;
  updateSuggestionVotes(id, upvotes, downvotes);

  // Mettre à jour l'embed
  const embed = EmbedBuilder.from(interaction.message.embeds[0]);
  const fields = embed.data.fields||[];
  const voteField = fields.find(f=>f.name==='Votes');
  if (voteField) voteField.value = `👍 ${upvotes}  |  👎 ${downvotes}`;
  await interaction.message.edit({ embeds:[embed] });
  return interaction.reply({ content:`✅ Vote enregistré ! 👍 ${upvotes} | 👎 ${downvotes}`, ephemeral:true });
}

// ─────────────────────────────────────────────────────────────────────────────
// POLLS
// ─────────────────────────────────────────────────────────────────────────────

// votes: Map<msgId, Map<userId, choiceIndex>>
const pollVotes = new Map();

async function handlePollVote(interaction, customId) {
  const parts       = customId.split(':');
  const choiceIndex = parseInt(parts[1]);
  const msgId       = interaction.message.id;

  if (!pollVotes.has(msgId)) pollVotes.set(msgId, new Map());
  const voters  = pollVotes.get(msgId);
  const prevVote = voters.get(interaction.user.id);

  voters.set(interaction.user.id, choiceIndex);

  // Compter les votes
  const counts = new Map();
  for (const v of voters.values()) counts.set(v, (counts.get(v)||0)+1);

  // Mettre à jour l'embed avec les résultats
  const embed   = EmbedBuilder.from(interaction.message.embeds[0]);
  const emojis  = ['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣'];
  const rows     = interaction.message.components;
  const totalVotes = voters.size;

  // Reconstruire la description
  const lines = embed.data.description?.split('\n')||[];
  const newLines = lines.map((line,i)=>{
    const v     = counts.get(i)||0;
    const pct   = totalVotes>0 ? Math.round((v/totalVotes)*100) : 0;
    const bar   = '█'.repeat(Math.floor(pct/10))+'░'.repeat(10-Math.floor(pct/10));
    return `${emojis[i]||''} ${line.replace(/`.+`|\d+%.*$/,'').trim()}\n\`[${bar}]\` **${pct}%** (${v} vote(s))`;
  });
  embed.setDescription(newLines.join('\n'));
  await interaction.message.edit({ embeds:[embed] });

  const action = prevVote!==undefined ? 'changé ton vote' : 'voté';
  return interaction.reply({ content:`✅ Tu as ${action} !`, ephemeral:true });
}

// ─────────────────────────────────────────────────────────────────────────────
// Utilitaire log
// ─────────────────────────────────────────────────────────────────────────────

async function sendLog(client, guild, config, { title, fields, color }) {
  if (!config.log_channel) return;
  const ch = guild.channels.cache.get(config.log_channel);
  if (!ch) return;
  await ch.send({ embeds:[new EmbedBuilder().setTitle(title).addFields(fields).setColor(color).setTimestamp()] }).catch(()=>{});
}

/**
 * Salons vocaux temporaires
 * Un utilisateur rejoint le salon "source" → un salon privé est créé automatiquement
 * Le salon est supprimé dès qu'il est vide
 */

const { Events, ChannelType, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig } = require('../handlers/database');

// Map des salons temporaires créés : channelId -> ownerId
const tempChannels = new Map();

module.exports = [
  {
    name: Events.VoiceStateUpdate,
    once: false,
    async execute(oldState, newState, client) {
      const guild = newState.guild||oldState.guild;
      if (!guild) return;
      const config = getGuildConfig(guild.id);

      // ── L'utilisateur REJOINT le salon source ────────────────────────────
      if (newState.channelId&&config.temp_voice_channel&&newState.channelId===config.temp_voice_channel) {
        const member = newState.member;
        try {
          const tempCh = await guild.channels.create({
            name: `🔊 ${member.displayName}`,
            type: ChannelType.GuildVoice,
            parent: newState.channel.parentId||null,
            permissionOverwrites: [
              {
                id: member.id,
                allow: [
                  PermissionFlagsBits.ViewChannel,
                  PermissionFlagsBits.Connect,
                  PermissionFlagsBits.Speak,
                  PermissionFlagsBits.ManageChannels,
                  PermissionFlagsBits.MoveMembers,
                ],
              },
              {
                id: guild.id,
                allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect],
              },
            ],
          });

          tempChannels.set(tempCh.id, member.id);

          // Déplacer le membre dans son nouveau salon
          await member.voice.setChannel(tempCh).catch(()=>{});
        } catch(err) {
          console.error('[TEMP VOICE] Erreur création salon:', err.message);
        }
      }

      // ── L'utilisateur QUITTE un salon temporaire ─────────────────────────
      if (oldState.channelId&&tempChannels.has(oldState.channelId)) {
        const ch = guild.channels.cache.get(oldState.channelId);
        if (!ch) { tempChannels.delete(oldState.channelId); return; }
        // Supprimer si vide
        if (ch.members.size===0) {
          tempChannels.delete(oldState.channelId);
          await ch.delete('[Temp Voice] Salon vide').catch(()=>{});
        }
      }
    },
  },
];

/**
 * Événements messages : snipe, auto-mod, XP/niveaux, bienvenue, starboard
 */

const { Events, EmbedBuilder } = require('discord.js');
const { getGuildConfig, addXp, addModLog, getStarboard, upsertStarboard, getRoleRewardForLevel } = require('../handlers/database');

const spamMap = new Map();

module.exports = [
  // ─── messageCreate ─────────────────────────────────────────────────────────
  {
    name: Events.MessageCreate,
    once: false,
    async execute(message, client) {
      if (message.author.bot||!message.guild) return;
      const config = getGuildConfig(message.guild.id);
      const content = message.content.toLowerCase();

      // Anti-spam
      if (config.antispam_enabled) {
        const now = Date.now();
        const key = `${message.guild.id}:${message.author.id}`;
        if (!spamMap.has(key)) spamMap.set(key,[]);
        const times = spamMap.get(key).filter(t=>now-t<5000);
        times.push(now);
        spamMap.set(key,times);
        if (times.length>=5) {
          await message.delete().catch(()=>{});
          const w = await message.channel.send({ content:`⚠️ ${message.author}, arrête le spam !` });
          setTimeout(()=>w.delete().catch(()=>{}),5000);
          spamMap.set(key,[]);
          addModLog(message.guild.id,'AUTO_SPAM',message.author.id,message.client.user.id,'Spam auto-mod',null);
          return;
        }
      }

      // Anti-liens
      if (config.antilinks_enabled) {
        const isStaff = config.mod_role&&message.member.roles.cache.has(config.mod_role);
        if (!isStaff&&/(https?:\/\/|discord\.gg\/|www\.)[^\s]+/i.test(message.content)) {
          await message.delete().catch(()=>{});
          const w = await message.channel.send({ content:`🚫 ${message.author}, les liens ne sont pas autorisés.` });
          setTimeout(()=>w.delete().catch(()=>{}),5000);
          addModLog(message.guild.id,'AUTO_LINK',message.author.id,message.client.user.id,'Lien supprimé',null);
          return;
        }
      }

      // Anti-insultes
      if (config.bad_words) {
        const list = config.bad_words.split(',').map(w=>w.trim().toLowerCase()).filter(Boolean);
        if (list.some(w=>content.includes(w))) {
          await message.delete().catch(()=>{});
          const w = await message.channel.send({ content:`🚫 ${message.author}, ce mot n'est pas autorisé.` });
          setTimeout(()=>w.delete().catch(()=>{}),5000);
          addModLog(message.guild.id,'AUTO_BADWORD',message.author.id,message.client.user.id,'Mot interdit',null);
          return;
        }
      }

      // XP / Niveaux
      const xpGain = Math.floor(Math.random()*10)+5;
      const result = addXp(message.guild.id, message.author.id, xpGain);
      if (result?.leveledUp) {
        // Rôle de récompense
        const reward = getRoleRewardForLevel(message.guild.id, result.newLevel);
        if (reward) {
          const role = message.guild.roles.cache.get(reward.role_id);
          if (role) await message.member.roles.add(role).catch(()=>{});
        }
        const embed = new EmbedBuilder()
          .setDescription(`🎉 ${message.author} atteint le **niveau ${result.newLevel}** !${reward?` 🎭 Rôle **<@&${reward.role_id}>** attribué !`:''}`)
          .setColor(0xffd700);
        const msg = await message.channel.send({ embeds:[embed] }).catch(()=>null);
        if (msg) setTimeout(()=>msg.delete().catch(()=>{}),10000);
      }
    },
  },

  // ─── messageDelete ─────────────────────────────────────────────────────────
  {
    name: Events.MessageDelete,
    once: false,
    async execute(message, client) {
      if (!message.guild||message.author?.bot) return;

      // Cache snipe
      if (!client.snipeCache.has(message.channel.id)) client.snipeCache.set(message.channel.id,new Map());
      client.snipeCache.get(message.channel.id).set(message.author.id, {
        content: message.content||'',
        author: { id:message.author.id, tag:message.author.tag, displayName:message.member?.displayName||message.author.username, avatarURL:message.author.displayAvatarURL({size:256}) },
        deletedAt: Date.now(),
        attachments: message.attachments.map(a=>({ url:a.url, name:a.name, contentType:a.contentType })),
      });

      // Log
      const config = getGuildConfig(message.guild.id);
      if (!config.log_channel) return;
      const logCh = message.guild.channels.cache.get(config.log_channel);
      if (!logCh) return;
      const embed = new EmbedBuilder().setTitle('🗑️ Message supprimé').setColor(0xed4245)
        .addFields(
          { name:'Auteur', value:`${message.author} (${message.author.id})`, inline:true },
          { name:'Salon',  value:`${message.channel}`, inline:true },
          { name:'Contenu', value:message.content?.slice(0,1024)||'*Aucun texte*' },
        ).setTimestamp().setThumbnail(message.author.displayAvatarURL());
      await logCh.send({ embeds:[embed] }).catch(()=>{});
    },
  },

  // ─── messageUpdate ─────────────────────────────────────────────────────────
  {
    name: Events.MessageUpdate,
    once: false,
    async execute(oldMessage, newMessage, client) {
      if (!oldMessage.guild||oldMessage.author?.bot||oldMessage.content===newMessage.content) return;
      const config = getGuildConfig(oldMessage.guild.id);
      if (!config.log_channel) return;
      const logCh = oldMessage.guild.channels.cache.get(config.log_channel);
      if (!logCh) return;
      const embed = new EmbedBuilder().setTitle('✏️ Message modifié').setColor(0xfee75c)
        .addFields(
          { name:'Auteur', value:`${oldMessage.author} (${oldMessage.author.id})`, inline:true },
          { name:'Salon',  value:`${oldMessage.channel}`, inline:true },
          { name:'Avant',  value:oldMessage.content?.slice(0,500)||'*Vide*' },
          { name:'Après',  value:newMessage.content?.slice(0,500)||'*Vide*' },
        ).setURL(newMessage.url).setTimestamp().setThumbnail(oldMessage.author.displayAvatarURL());
      await logCh.send({ embeds:[embed] }).catch(()=>{});
    },
  },

  // ─── messageReactionAdd (Starboard) ────────────────────────────────────────
  {
    name: Events.MessageReactionAdd,
    once: false,
    async execute(reaction, user, client) {
      if (user.bot) return;
      if (reaction.partial) { try { await reaction.fetch(); } catch { return; } }
      if (reaction.message.partial) { try { await reaction.message.fetch(); } catch { return; } }
      if (reaction.emoji.name!=='⭐') return;

      const { message } = reaction;
      if (!message.guild) return;
      const config = getGuildConfig(message.guild.id);
      if (!config.starboard_channel) return;
      const starCh = message.guild.channels.cache.get(config.starboard_channel);
      if (!starCh||message.channel.id===starCh.id) return;

      const threshold  = config.starboard_threshold||3;
      const starReact  = message.reactions.cache.get('⭐');
      const starCount  = starReact?.count||0;
      if (starCount<threshold) return;

      const existing = getStarboard(message.guild.id, message.id);
      const embed    = new EmbedBuilder()
        .setAuthor({ name:message.author.tag, iconURL:message.author.displayAvatarURL() })
        .setDescription(message.content?.slice(0,2000)||null)
        .setColor(0xffd700)
        .addFields({ name:'Source', value:`[Aller au message](${message.url})`, inline:true },{ name:'Salon', value:`${message.channel}`, inline:true })
        .setTimestamp(message.createdAt);
      const img = message.attachments.find(a=>a.contentType?.startsWith('image/'));
      if (img) embed.setImage(img.url);

      if (existing?.starboard_message_id) {
        try {
          const sbMsg = await starCh.messages.fetch(existing.starboard_message_id);
          await sbMsg.edit({ content:`⭐ **${starCount}**`, embeds:[embed] });
          upsertStarboard(message.guild.id,message.id,existing.starboard_message_id,starCount);
        } catch {}
      } else {
        const sbMsg = await starCh.send({ content:`⭐ **${starCount}**`, embeds:[embed] }).catch(()=>null);
        if (sbMsg) upsertStarboard(message.guild.id,message.id,sbMsg.id,starCount);
      }
    },
  },

  // ─── guildMemberAdd ────────────────────────────────────────────────────────
  {
    name: Events.GuildMemberAdd,
    once: false,
    async execute(member, client) {
      const config = getGuildConfig(member.guild.id);

      // Auto-rôle
      if (config.auto_role) {
        const role = member.guild.roles.cache.get(config.auto_role);
        if (role) await member.roles.add(role).catch(()=>{});
      }

      // Bienvenue
      if (config.welcome_channel) {
        const ch = member.guild.channels.cache.get(config.welcome_channel);
        if (ch) {
          const msg = (config.welcome_message||'Bienvenue {user} sur **{server}** !')
            .replace('{user}',`${member}`)
            .replace('{server}',member.guild.name)
            .replace('{memberCount}',String(member.guild.memberCount));
          const embed = new EmbedBuilder().setDescription(msg).setColor(0x57f287)
            .setThumbnail(member.user.displayAvatarURL({size:256})).setTimestamp();
          await ch.send({ embeds:[embed] }).catch(()=>{});
        }
      }

      // Log
      if (config.log_channel) {
        const logCh = member.guild.channels.cache.get(config.log_channel);
        if (logCh) {
          const embed = new EmbedBuilder().setTitle('✅ Membre rejoint').setColor(0x57f287)
            .setThumbnail(member.user.displayAvatarURL())
            .addFields(
              { name:'Membre', value:`${member} (${member.id})`, inline:true },
              { name:'Compte créé', value:`<t:${Math.floor(member.user.createdTimestamp/1000)}:R>`, inline:true },
              { name:'Membres', value:`${member.guild.memberCount}`, inline:true },
            ).setTimestamp();
          await logCh.send({ embeds:[embed] }).catch(()=>{});
        }
      }
    },
  },

  // ─── guildMemberRemove ─────────────────────────────────────────────────────
  {
    name: Events.GuildMemberRemove,
    once: false,
    async execute(member, client) {
      const config = getGuildConfig(member.guild.id);
      if (!config.log_channel) return;
      const logCh = member.guild.channels.cache.get(config.log_channel);
      if (!logCh) return;
      const embed = new EmbedBuilder().setTitle('👋 Membre parti').setColor(0xed4245)
        .setThumbnail(member.user.displayAvatarURL())
        .addFields(
          { name:'Membre', value:`${member.user.tag} (${member.id})`, inline:true },
          { name:'A rejoint le', value:member.joinedAt?`<t:${Math.floor(member.joinedTimestamp/1000)}:R>`:'Inconnu', inline:true },
        ).setTimestamp();
      await logCh.send({ embeds:[embed] }).catch(()=>{});
    },
  },
];

/**
 * Script de déploiement des commandes slash
 * Enregistre toutes les commandes auprès de l'API Discord
 *
 * Usage :
 *   node src/deploy-commands.js           → déploiement global (jusqu'à 1h de propagation)
 *   GUILD_ID=xxx node src/deploy-commands.js  → déploiement immédiat sur un serveur
 */

require('dotenv').config();
const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');

const token = process.env.DISCORD_TOKEN;
const clientId = process.env.DISCORD_CLIENT_ID;
const guildId = process.env.GUILD_ID;

if (!token || !clientId) {
  console.error('[DEPLOY] DISCORD_TOKEN et DISCORD_CLIENT_ID sont requis dans .env');
  process.exit(1);
}

const commands = [];
const commandsPath = path.join(__dirname, 'commands');
const files = fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'));

for (const file of files) {
  const raw = require(path.join(commandsPath, file));
  const cmds = Array.isArray(raw) ? raw : [raw];
  for (const cmd of cmds) {
    if (cmd.data) {
      commands.push(cmd.data.toJSON());
      console.log(`[DEPLOY] Commande préparée : /${cmd.data.name}`);
    }
  }
}

const rest = new REST({ version: '10' }).setToken(token);

(async () => {
  try {
    console.log(`\n[DEPLOY] Déploiement de ${commands.length} commande(s)...`);

    if (guildId) {
      // Déploiement sur un serveur spécifique (instantané)
      await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
      console.log(`[DEPLOY] ✅ Commandes déployées sur le serveur ${guildId} (instantané)`);
    } else {
      // Déploiement global (propagation ~1h)
      await rest.put(Routes.applicationCommands(clientId), { body: commands });
      console.log('[DEPLOY] ✅ Commandes déployées globalement (propagation jusqu\'à 1h)');
    }
  } catch (err) {
    console.error('[DEPLOY] ❌ Erreur lors du déploiement:', err);
  }
})();

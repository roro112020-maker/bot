/**
 * Commandes d'information avancées
 * /banner /permissions /emoji-info /role-list /channel-list
 * /member-count /invite-create /bot-perms /whois /id
 * /server-icon /audit /snowflake /status
 */

const {
  SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, PermissionsBitField,
} = require('discord.js');

// ─── /banner ──────────────────────────────────────────────────────────────────
const bannerCmd = {
  data: new SlashCommandBuilder().setName('banner').setDescription('Voir la bannière d\'un utilisateur ou du serveur')
    .addSubcommand(s => s.setName('user').setDescription('Bannière d\'un utilisateur')
      .addUserOption(o => o.setName('membre').setDescription('Membre (défaut: toi)')))
    .addSubcommand(s => s.setName('server').setDescription('Bannière du serveur')),
  cooldown: 5,
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    if (sub === 'user') {
      const target = await (interaction.options.getUser('membre') || interaction.user).fetch();
      const url    = target.bannerURL({ size: 4096 });
      if (!url) return interaction.reply({ content: `ℹ️ **${target.tag}** n'a pas de bannière.`, ephemeral: true });
      return interaction.reply({ embeds: [new EmbedBuilder().setTitle(`🖼️ Bannière — ${target.tag}`).setImage(url).setColor(target.accentColor || 0x5865f2)] });
    }
    if (sub === 'server') {
      const guild = await interaction.guild.fetch();
      const url   = guild.bannerURL({ size: 4096 });
      if (!url) return interaction.reply({ content: 'ℹ️ Ce serveur n\'a pas de bannière (Boost niveau 2 requis).', ephemeral: true });
      return interaction.reply({ embeds: [new EmbedBuilder().setTitle(`🖼️ Bannière — ${guild.name}`).setImage(url).setColor(0x5865f2)] });
    }
  },
};

// ─── /permissions ─────────────────────────────────────────────────────────────
const permissionsCmd = {
  data: new SlashCommandBuilder().setName('permissions').setDescription('Voir les permissions d\'un membre dans un salon')
    .addUserOption(o => o.setName('membre').setDescription('Membre (défaut: toi)'))
    .addChannelOption(o => o.setName('salon').setDescription('Salon (défaut: actuel)')),
  cooldown: 5,
  async execute(interaction) {
    const member  = interaction.options.getMember('membre') || interaction.member;
    const channel = interaction.options.getChannel('salon') || interaction.channel;
    const perms   = channel.permissionsFor(member);
    if (!perms) return interaction.reply({ content: '❌ Impossible de calculer les permissions.', ephemeral: true });

    const PERM_NAMES = {
      [PermissionFlagsBits.ViewChannel]: 'Voir le salon',
      [PermissionFlagsBits.SendMessages]: 'Envoyer des messages',
      [PermissionFlagsBits.ReadMessageHistory]: 'Lire l\'historique',
      [PermissionFlagsBits.ManageMessages]: 'Gérer les messages',
      [PermissionFlagsBits.AttachFiles]: 'Joindre des fichiers',
      [PermissionFlagsBits.EmbedLinks]: 'Liens embed',
      [PermissionFlagsBits.MentionEveryone]: 'Mentionner @everyone',
      [PermissionFlagsBits.UseApplicationCommands]: 'Commandes slash',
      [PermissionFlagsBits.Connect]: 'Rejoindre vocal',
      [PermissionFlagsBits.Speak]: 'Parler en vocal',
      [PermissionFlagsBits.MuteMembers]: 'Mute membres',
      [PermissionFlagsBits.DeafenMembers]: 'Rendre sourd',
      [PermissionFlagsBits.ManageChannels]: 'Gérer les salons',
      [PermissionFlagsBits.Administrator]: '👑 Administrateur',
    };

    const lines = Object.entries(PERM_NAMES).map(([flag, name]) =>
      `${perms.has(BigInt(flag)) ? '✅' : '❌'} ${name}`
    );

    const embed = new EmbedBuilder()
      .setTitle(`🔐 Permissions — ${member.user.tag}`)
      .setDescription(`Salon : ${channel}\n\n${lines.join('\n')}`)
      .setColor(0x5865f2).setThumbnail(member.user.displayAvatarURL()).setTimestamp();
    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};

// ─── /emoji-info ─────────────────────────────────────────────────────────────
const emojiInfoCmd = {
  data: new SlashCommandBuilder().setName('emoji-info').setDescription('Informations sur un emoji personnalisé du serveur')
    .addStringOption(o => o.setName('emoji').setDescription('Emoji ou ID d\'emoji').setRequired(true)),
  cooldown: 5,
  async execute(interaction) {
    const input = interaction.options.getString('emoji');
    const match = input.match(/<(a)?:(\w+):(\d+)>/);
    if (!match) {
      // Emoji Unicode standard
      const codePoint = [...input].map(c => `U+${c.codePointAt(0).toString(16).toUpperCase().padStart(4,'0')}`).join(' ');
      return interaction.reply({ embeds: [new EmbedBuilder().setTitle('😀 Emoji Unicode').addFields({ name: 'Emoji', value: input, inline: true }, { name: 'Code', value: codePoint, inline: true }).setColor(0xfee75c)] });
    }
    const [, animated, name, id] = match;
    const url = `https://cdn.discordapp.com/emojis/${id}.${animated ? 'gif' : 'png'}?size=512`;
    const emoji = interaction.guild.emojis.cache.get(id);
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle(`${animated ? '✨' : '😀'} Emoji : ${name}`)
      .setThumbnail(url)
      .addFields(
        { name: 'Nom',     value: name,                                              inline: true },
        { name: 'ID',      value: id,                                                inline: true },
        { name: 'Animé',   value: animated ? 'Oui' : 'Non',                         inline: true },
        { name: 'Balise',  value: `\`${input}\``,                                   inline: true },
        { name: 'URL',     value: `[Cliquer](${url})`,                              inline: true },
        { name: 'Créé le', value: emoji ? `<t:${Math.floor(emoji.createdTimestamp/1000)}:R>` : 'Inconnu', inline: true },
      ).setColor(0xfee75c)] });
  },
};

// ─── /role-list ───────────────────────────────────────────────────────────────
const roleListCmd = {
  data: new SlashCommandBuilder().setName('role-list').setDescription('Voir tous les rôles du serveur'),
  cooldown: 10,
  async execute(interaction) {
    const roles = [...interaction.guild.roles.cache.values()]
      .filter(r => r.id !== interaction.guild.id)
      .sort((a, b) => b.position - a.position);

    if (!roles.length) return interaction.reply({ content: 'ℹ️ Aucun rôle.', ephemeral: true });

    const chunks = [];
    for (let i = 0; i < roles.length; i += 20) {
      chunks.push(roles.slice(i, i + 20));
    }

    const embed = new EmbedBuilder().setTitle(`🎭 Rôles — ${interaction.guild.name}`)
      .setColor(0x5865f2)
      .setDescription(chunks[0].map(r => `${r} — **${r.members.size}** membres`).join('\n'))
      .setFooter({ text: `${roles.length} rôle(s) total • Page 1/${chunks.length}` });
    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};

// ─── /channel-list ────────────────────────────────────────────────────────────
const channelListCmd = {
  data: new SlashCommandBuilder().setName('channel-list').setDescription('Voir tous les salons du serveur')
    .addStringOption(o => o.setName('filtre').setDescription('Filtrer par type').addChoices(
      { name: '💬 Textuels', value: 'text' },
      { name: '🔊 Vocaux', value: 'voice' },
      { name: '📁 Catégories', value: 'category' },
    )),
  cooldown: 10,
  async execute(interaction) {
    const { ChannelType } = require('discord.js');
    const filtre  = interaction.options.getString('filtre');
    const typeMap = { text: ChannelType.GuildText, voice: ChannelType.GuildVoice, category: ChannelType.GuildCategory };
    let channels  = [...interaction.guild.channels.cache.values()];
    if (filtre) channels = channels.filter(c => c.type === typeMap[filtre]);
    channels = channels.sort((a, b) => (a.rawPosition || 0) - (b.rawPosition || 0));

    const text  = channels.filter(c => c.type === ChannelType.GuildText).length;
    const voice = channels.filter(c => c.type === ChannelType.GuildVoice).length;
    const cat   = channels.filter(c => c.type === ChannelType.GuildCategory).length;

    const embed = new EmbedBuilder().setTitle(`📋 Salons — ${interaction.guild.name}`).setColor(0x5865f2)
      .setDescription(channels.slice(0, 30).map(c => `${c}`).join('\n') || 'Aucun salon.')
      .addFields({ name: 'Résumé', value: `💬 ${text} text • 🔊 ${voice} vocal • 📁 ${cat} catégories` })
      .setFooter({ text: `${channels.length} salon(s)` });
    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};

// ─── /member-count ────────────────────────────────────────────────────────────
const memberCountCmd = {
  data: new SlashCommandBuilder().setName('member-count').setDescription('Statistiques des membres du serveur'),
  cooldown: 10,
  async execute(interaction) {
    await interaction.deferReply();
    const guild   = interaction.guild;
    const members = await guild.members.fetch();
    const humans  = members.filter(m => !m.user.bot);
    const bots    = members.filter(m => m.user.bot);
    const online  = members.filter(m => m.presence?.status === 'online').size;
    const idle    = members.filter(m => m.presence?.status === 'idle').size;
    const dnd     = members.filter(m => m.presence?.status === 'dnd').size;
    const offline = members.size - online - idle - dnd;

    await interaction.editReply({ embeds: [new EmbedBuilder().setTitle(`👥 Membres — ${guild.name}`).setColor(0x5865f2)
      .addFields(
        { name: '👤 Total',    value: `**${guild.memberCount}**`,  inline: true },
        { name: '🙋 Humains', value: `**${humans.size}**`,         inline: true },
        { name: '🤖 Bots',    value: `**${bots.size}**`,           inline: true },
        { name: '🟢 En ligne',value: `**${online}**`,              inline: true },
        { name: '🟡 Inactif', value: `**${idle}**`,                inline: true },
        { name: '🔴 Ne pas déranger',value: `**${dnd}**`,          inline: true },
        { name: '⚫ Hors ligne',value: `**${offline}**`,           inline: true },
      ).setTimestamp()] });
  },
};

// ─── /bot-perms ───────────────────────────────────────────────────────────────
const botPermsCmd = {
  data: new SlashCommandBuilder().setName('bot-perms').setDescription('Voir les permissions du bot dans ce serveur')
    .addChannelOption(o => o.setName('salon').setDescription('Vérifier dans un salon spécifique')),
  cooldown: 5,
  async execute(interaction) {
    const ch   = interaction.options.getChannel('salon') || interaction.channel;
    const me   = interaction.guild.members.me;
    const perms = ch ? ch.permissionsFor(me) : me.permissions;

    const criticals = {
      [PermissionFlagsBits.Administrator]: '👑 Administrateur',
      [PermissionFlagsBits.ManageGuild]: 'Gérer le serveur',
      [PermissionFlagsBits.ManageChannels]: 'Gérer les salons',
      [PermissionFlagsBits.ManageRoles]: 'Gérer les rôles',
      [PermissionFlagsBits.BanMembers]: 'Bannir',
      [PermissionFlagsBits.KickMembers]: 'Expulser',
      [PermissionFlagsBits.ModerateMembers]: 'Timeout',
      [PermissionFlagsBits.ManageMessages]: 'Gérer messages',
      [PermissionFlagsBits.ViewChannel]: 'Voir le salon',
      [PermissionFlagsBits.SendMessages]: 'Envoyer messages',
      [PermissionFlagsBits.EmbedLinks]: 'Embeds',
      [PermissionFlagsBits.AttachFiles]: 'Fichiers',
    };

    const lines = Object.entries(criticals).map(([flag, name]) =>
      `${perms.has(BigInt(flag)) ? '✅' : '❌'} ${name}`
    );
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('🤖 Permissions du bot').setDescription(lines.join('\n')).setColor(0x5865f2)], ephemeral: true });
  },
};

// ─── /whois ───────────────────────────────────────────────────────────────────
const whoisCmd = {
  data: new SlashCommandBuilder().setName('whois').setDescription('Profil détaillé d\'un membre (alias de /userinfo)')
    .addUserOption(o => o.setName('membre').setDescription('Membre')),
  cooldown: 5,
  async execute(interaction) {
    const { getWarns } = require('../handlers/database');
    const target = interaction.options.getMember('membre') || interaction.member;
    const user   = await target.user.fetch();
    const roles  = target.roles.cache.filter(r => r.id !== interaction.guild.id).sort((a, b) => b.position - a.position);
    const warns  = getWarns(interaction.guild.id, user.id);
    const statuses = { online: '🟢 En ligne', idle: '🟡 Inactif', dnd: '🔴 Ne pas déranger', offline: '⚫ Hors ligne' };
    const flags    = user.flags?.toArray() || [];

    const embed = new EmbedBuilder()
      .setTitle(`👤 ${user.tag}`)
      .setThumbnail(user.displayAvatarURL({ size: 256 }))
      .setColor(user.bannerColor || target.displayHexColor || 0x5865f2)
      .addFields(
        { name: '🪪 ID',         value: user.id,                                                           inline: true },
        { name: '📛 Surnom',     value: target.displayName || 'Aucun',                                    inline: true },
        { name: '🔖 Status',     value: statuses[target.presence?.status || 'offline'] || '⚫',           inline: true },
        { name: '📅 Compte créé',value: `<t:${Math.floor(user.createdTimestamp/1000)}:R>`,               inline: true },
        { name: '📥 A rejoint',  value: target.joinedAt ? `<t:${Math.floor(target.joinedTimestamp/1000)}:R>` : 'Inconnu', inline: true },
        { name: '⚠️ Warns',      value: `**${warns.length}**`,                                            inline: true },
        { name: '🤖 Bot',        value: user.bot ? '✅' : '❌',                                          inline: true },
        { name: '🏅 Badges',     value: flags.length ? flags.join(', ').replace(/_/g, ' ') : 'Aucun',    inline: true },
        { name: `🎭 Rôles (${roles.size})`, value: roles.size ? [...roles.values()].slice(0, 8).join(' ') : 'Aucun' },
      ).setTimestamp();
    if (user.bannerURL?.()) embed.setImage(user.bannerURL({ size: 1024 }));
    await interaction.reply({ embeds: [embed] });
  },
};

// ─── /id ─────────────────────────────────────────────────────────────────────
const idCmd = {
  data: new SlashCommandBuilder().setName('id').setDescription('Obtenir l\'ID de n\'importe quoi')
    .addSubcommand(s => s.setName('user').setDescription('ID d\'un utilisateur').addUserOption(o => o.setName('membre').setDescription('Membre (défaut: toi)')))
    .addSubcommand(s => s.setName('role').setDescription('ID d\'un rôle').addRoleOption(o => o.setName('role').setDescription('Rôle').setRequired(true)))
    .addSubcommand(s => s.setName('channel').setDescription('ID d\'un salon').addChannelOption(o => o.setName('salon').setDescription('Salon (défaut: actuel)')))
    .addSubcommand(s => s.setName('server').setDescription('ID du serveur'))
    .addSubcommand(s => s.setName('bot').setDescription('ID du bot')),
  cooldown: 3,
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    if (sub === 'user')    return interaction.reply({ content: `🪪 ID de ${interaction.options.getUser('membre') || interaction.user} : \`${(interaction.options.getUser('membre') || interaction.user).id}\``, ephemeral: true });
    if (sub === 'role')    return interaction.reply({ content: `🎭 ID de ${interaction.options.getRole('role')} : \`${interaction.options.getRole('role').id}\``, ephemeral: true });
    if (sub === 'channel') return interaction.reply({ content: `📝 ID de ${interaction.options.getChannel('salon') || interaction.channel} : \`${(interaction.options.getChannel('salon') || interaction.channel).id}\``, ephemeral: true });
    if (sub === 'server')  return interaction.reply({ content: `🏠 ID du serveur **${interaction.guild.name}** : \`${interaction.guild.id}\``, ephemeral: true });
    if (sub === 'bot')     return interaction.reply({ content: `🤖 ID du bot : \`${interaction.client.user.id}\``, ephemeral: true });
  },
};

// ─── /server-icon ─────────────────────────────────────────────────────────────
const serverIconCmd = {
  data: new SlashCommandBuilder().setName('server-icon').setDescription('Voir l\'icône du serveur'),
  cooldown: 5,
  async execute(interaction) {
    const url = interaction.guild.iconURL({ size: 4096, extension: 'png' });
    if (!url) return interaction.reply({ content: 'ℹ️ Ce serveur n\'a pas d\'icône.', ephemeral: true });
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle(`🖼️ Icône — ${interaction.guild.name}`)
      .setImage(url).setColor(0x5865f2)
      .addFields({ name: 'Liens', value: `[PNG](${url}) • [WEBP](${interaction.guild.iconURL({ size: 4096, extension: 'webp' })})` })] });
  },
};

// ─── /snowflake ────────────────────────────────────────────────────────────────
const snowflakeCmd = {
  data: new SlashCommandBuilder().setName('snowflake').setDescription('Décoder un Snowflake Discord (timestamp, shard, etc.)')
    .addStringOption(o => o.setName('id').setDescription('ID Discord (Snowflake)').setRequired(true)),
  cooldown: 3,
  async execute(interaction) {
    const id = interaction.options.getString('id');
    if (!/^\d{15,20}$/.test(id)) return interaction.reply({ content: '❌ ID invalide.', ephemeral: true });
    const DISCORD_EPOCH = 1420070400000n;
    const bigId         = BigInt(id);
    const timestamp     = Number((bigId >> 22n) + DISCORD_EPOCH);
    const internalWID   = Number((bigId & 0x3E0000n) >> 17n);
    const internalPID   = Number((bigId & 0x1F000n)  >> 12n);
    const increment     = Number(bigId & 0xFFFn);
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('❄️ Décodage Snowflake').setColor(0x5865f2)
      .addFields(
        { name: '⏱️ Timestamp',     value: `<t:${Math.floor(timestamp/1000)}:F>`, inline: true },
        { name: '🖥️ Worker ID',    value: `${internalWID}`,                       inline: true },
        { name: '⚙️ Process ID',   value: `${internalPID}`,                       inline: true },
        { name: '🔢 Incrément',    value: `${increment}`,                         inline: true },
        { name: '📅 Unix (ms)',    value: `${timestamp}`,                         inline: true },
      )], ephemeral: true });
  },
};

// ─── /audit ───────────────────────────────────────────────────────────────────
const auditCmd = {
  data: new SlashCommandBuilder().setName('audit').setDescription('Voir les dernières entrées du journal d\'audit')
    .addIntegerOption(o => o.setName('limite').setDescription('Nombre d\'entrées (1-25)').setMinValue(1).setMaxValue(25))
    .addUserOption(o => o.setName('membre').setDescription('Filtrer par membre'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ViewAuditLog),
  cooldown: 10,
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const limit  = interaction.options.getInteger('limite') ?? 10;
    const filter = interaction.options.getUser('membre');
    const logs   = await interaction.guild.fetchAuditLogs({ limit, user: filter?.id }).catch(() => null);
    if (!logs) return interaction.editReply({ content: '❌ Impossible de récupérer le journal d\'audit.' });
    const entries = [...logs.entries.values()];
    if (!entries.length) return interaction.editReply({ content: 'ℹ️ Aucune entrée d\'audit trouvée.' });
    const embed = new EmbedBuilder().setTitle('📋 Journal d\'audit').setColor(0x5865f2)
      .setDescription(entries.map(e =>
        `**${e.actionType}** — par ${e.executor?.tag || 'Inconnu'}\n> ${e.reason || 'Aucune raison'} — <t:${Math.floor(e.createdTimestamp/1000)}:R>`
      ).join('\n\n').slice(0, 4000));
    await interaction.editReply({ embeds: [embed] });
  },
};

module.exports = [
  bannerCmd, permissionsCmd, emojiInfoCmd, roleListCmd, channelListCmd,
  memberCountCmd, botPermsCmd, whoisCmd, idCmd, serverIconCmd,
  snowflakeCmd, auditCmd,
];

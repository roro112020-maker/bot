/**
 * Commandes utilitaires : giveaways, polls, suggestions, tags, rappels,
 * économie complète, fun, outils divers
 */

const {
  SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits,
  ButtonBuilder, ButtonStyle, ActionRowBuilder,
} = require('discord.js');
const {
  createGiveaway, setGiveawayMessageId, getGiveaway, getActiveGiveaways, endGiveaway,
  updateGiveawayParticipants, getGuildConfig,
  createTag, getTag, incrementTagUses, deleteTag, listTags, updateTag,
  createSuggestion, setSuggestionMessageId, reviewSuggestion, getSuggestionByMessage,
  createReminder, getUserReminders, deleteReminder,
  getEconomy, addCoins, deductCoins, transferCoins, setLastDaily, setLastWork, getEcoLeaderboard,
} = require('../handlers/database');

// ─── Helpers ──────────────────────────────────────────────────────────────────
function parseDuration(str) {
  const match = str.match(/^(\d+)(s|m|h|d|w)$/i);
  if (!match) return null;
  const mult = { s:1, m:60, h:3600, d:86400, w:604800 };
  return parseInt(match[1])*(mult[match[2].toLowerCase()]||0);
}

// ─────────────────────────────────────────────────────────────────────────────
// GIVEAWAYS
// ─────────────────────────────────────────────────────────────────────────────

function buildGiveawayEmbed(prize, winnersCount, hostId, endsAt, participants, ended, winnerIds) {
  const embed = new EmbedBuilder()
    .setTitle(`🎉 GIVEAWAY — ${prize}`)
    .setColor(ended?0x57f287:0xffd700)
    .addFields(
      { name:'🏆 Gagnant(s)',   value:`${winnersCount}`,          inline:true },
      { name:'👤 Organisé par', value:`<@${hostId}>`,             inline:true },
      { name:'👥 Participants', value:`${participants.length}`,   inline:true },
    ).setTimestamp(new Date(endsAt*1000));
  if (ended) {
    embed.setDescription(winnerIds.length>0
      ? `🎊 **Gagnant(s) :** ${winnerIds.map(id=>`<@${id}>`).join(', ')}`
      : '😔 Aucun gagnant (pas assez de participants).'
    ).setFooter({ text:'Giveaway terminé le' });
  } else {
    embed.setDescription(`Clique sur 🎉 pour participer !\n⏰ Fin : <t:${endsAt}:R>`).setFooter({ text:`ID: • Termine le` });
  }
  return embed;
}

function pickWinners(participants, count) {
  const shuffled = [...participants].sort(()=>Math.random()-0.5);
  return shuffled.slice(0, Math.min(count, shuffled.length));
}

async function finishGiveaway(client, id, channelOverride) {
  const gw = getGiveaway(id);
  if (!gw||gw.ended) return;
  const guild    = client.guilds.cache.get(gw.guild_id);
  if (!guild) return;
  const channel  = channelOverride || guild.channels.cache.get(gw.channel_id);
  if (!channel) return;
  const participants = JSON.parse(gw.participants||'[]');
  const winnerIds    = pickWinners(participants, gw.winners);
  endGiveaway(id, winnerIds);
  const embed = buildGiveawayEmbed(gw.prize, gw.winners, gw.host_id, gw.ends_at, participants, true, winnerIds);
  const disabledRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`giveaway_join:${id}`).setLabel('🎉 Terminé').setStyle(ButtonStyle.Secondary).setDisabled(true)
  );
  if (gw.message_id) {
    try { const msg = await channel.messages.fetch(gw.message_id); await msg.edit({ embeds:[embed], components:[disabledRow] }); } catch {}
  }
  if (winnerIds.length>0) await channel.send({ content:`🎊 Félicitations ${winnerIds.map(id=>`<@${id}>`).join(', ')} ! Vous avez gagné **${gw.prize}** !` });
  else await channel.send({ content:`😔 Le giveaway **${gw.prize}** s'est terminé sans gagnant.` });
}
module.exports.finishGiveaway = finishGiveaway;

const giveawayCmd = {
  data: new SlashCommandBuilder().setName('giveaway').setDescription('Gérer les giveaways')
    .addSubcommand(sub => sub.setName('start').setDescription('Lancer un giveaway')
      .addStringOption(o=>o.setName('prix').setDescription('Prix').setRequired(true))
      .addStringOption(o=>o.setName('duree').setDescription('Durée (1h, 30m, 2d)').setRequired(true))
      .addIntegerOption(o=>o.setName('gagnants').setDescription('Nb gagnants').setMinValue(1).setMaxValue(20))
      .addRoleOption(o=>o.setName('role_requis').setDescription('Rôle requis')))
    .addSubcommand(sub => sub.setName('end').setDescription('Terminer un giveaway').addIntegerOption(o=>o.setName('id').setDescription('ID').setRequired(true)))
    .addSubcommand(sub => sub.setName('reroll').setDescription('Reroll les gagnants').addIntegerOption(o=>o.setName('id').setDescription('ID').setRequired(true)))
    .addSubcommand(sub => sub.setName('list').setDescription('Giveaways en cours'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  cooldown: 5,
  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    if (sub==='start') {
      const prize   = interaction.options.getString('prix');
      const durStr  = interaction.options.getString('duree');
      const winners = interaction.options.getInteger('gagnants')??1;
      const reqRole = interaction.options.getRole('role_requis');
      const durSec  = parseDuration(durStr);
      if (!durSec) return interaction.reply({ content:'❌ Format invalide. Ex: `1h`, `30m`, `2d`', ephemeral:true });
      const endsAt = Math.floor(Date.now()/1000)+durSec;
      const result = createGiveaway(interaction.guild.id, interaction.channel.id, interaction.user.id, prize, winners, reqRole?.id||null, endsAt);
      const id     = result.lastInsertRowid;
      const embed  = buildGiveawayEmbed(prize, winners, interaction.user.id, endsAt, [], false, []);
      embed.setFooter({ text:`ID: ${id} • Termine le` });
      if (reqRole) embed.addFields({ name:'Rôle requis', value:`${reqRole}`, inline:true });
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`giveaway_join:${id}`).setLabel('🎉 Participer').setStyle(ButtonStyle.Primary)
      );
      await interaction.reply({ embeds:[embed], components:[row] });
      const msg = await interaction.fetchReply();
      setGiveawayMessageId(id, msg.id);
      setTimeout(async ()=>{ try { await finishGiveaway(client, id); } catch(e) { console.error('[GW]',e.message); } }, durSec*1000);
    }
    if (sub==='end') {
      const id = interaction.options.getInteger('id');
      await finishGiveaway(client, id, interaction.channel);
      await interaction.reply({ content:`✅ Giveaway **#${id}** terminé.`, ephemeral:true });
    }
    if (sub==='reroll') {
      const id  = interaction.options.getInteger('id');
      const gw  = getGiveaway(id);
      if (!gw) return interaction.reply({ content:'❌ Giveaway introuvable.', ephemeral:true });
      const participants = JSON.parse(gw.participants||'[]');
      if (!participants.length) return interaction.reply({ content:'❌ Aucun participant.', ephemeral:true });
      const newWinners = pickWinners(participants, gw.winners);
      await interaction.reply({ content:`🎊 **Reroll** — Nouveau(x) gagnant(s) : ${newWinners.map(id=>`<@${id}>`).join(', ')}` });
    }
    if (sub==='list') {
      const actives = getActiveGiveaways(interaction.guild.id);
      if (!actives.length) return interaction.reply({ content:'ℹ️ Aucun giveaway en cours.', ephemeral:true });
      const embed = new EmbedBuilder().setTitle('🎉 Giveaways en cours').setColor(0xffd700)
        .setDescription(actives.map(g=>`**#${g.id}** — ${g.prize}\nFin : <t:${g.ends_at}:R> • ${JSON.parse(g.participants||'[]').length} participant(s)`).join('\n\n'));
      await interaction.reply({ embeds:[embed], ephemeral:true });
    }
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// POLLS
// ─────────────────────────────────────────────────────────────────────────────
const pollCmd = {
  data: new SlashCommandBuilder().setName('poll').setDescription('Créer un sondage interactif')
    .addStringOption(o=>o.setName('question').setDescription('Question').setRequired(true))
    .addStringOption(o=>o.setName('choix1').setDescription('Choix 1').setRequired(true))
    .addStringOption(o=>o.setName('choix2').setDescription('Choix 2').setRequired(true))
    .addStringOption(o=>o.setName('choix3').setDescription('Choix 3'))
    .addStringOption(o=>o.setName('choix4').setDescription('Choix 4'))
    .addStringOption(o=>o.setName('choix5').setDescription('Choix 5')),
  cooldown: 10,
  async execute(interaction) {
    const question = interaction.options.getString('question');
    const choices  = ['choix1','choix2','choix3','choix4','choix5'].map(k=>interaction.options.getString(k)).filter(Boolean);
    const emojis   = ['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣'];
    const embed    = new EmbedBuilder()
      .setTitle(`📊 ${question}`)
      .setDescription(choices.map((c,i)=>`${emojis[i]} **${c}**`).join('\n'))
      .setColor(0x5865f2).setFooter({ text:`Sondage par ${interaction.user.tag}` }).setTimestamp();
    const rows  = [];
    const btns  = choices.map((c,i)=>new ButtonBuilder().setCustomId(`poll_vote:${i}:${Date.now()}`).setLabel(`${emojis[i]} ${c.slice(0,50)}`).setStyle(ButtonStyle.Primary));
    for (let i=0;i<btns.length;i+=5) rows.push(new ActionRowBuilder().addComponents(btns.slice(i,i+5)));
    await interaction.reply({ embeds:[embed], components:rows });
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// SUGGESTIONS
// ─────────────────────────────────────────────────────────────────────────────
const suggestCmd = {
  data: new SlashCommandBuilder().setName('suggest').setDescription('Soumettre une suggestion')
    .addStringOption(o=>o.setName('suggestion').setDescription('Ta suggestion').setRequired(true)),
  cooldown: 30,
  async execute(interaction) {
    const content  = interaction.options.getString('suggestion');
    const config   = getGuildConfig(interaction.guild.id);
    const targetCh = config.suggestion_channel ? interaction.guild.channels.cache.get(config.suggestion_channel) : interaction.channel;
    if (!targetCh) return interaction.reply({ content:'❌ Salon de suggestions non configuré.', ephemeral:true });
    const result = createSuggestion(interaction.guild.id, targetCh.id, interaction.user.id, content);
    const id     = result.lastInsertRowid;
    const embed  = new EmbedBuilder().setTitle(`💡 Suggestion #${id}`).setDescription(content).setColor(0xfee75c)
      .addFields({ name:'Auteur',value:`${interaction.user}`,inline:true },{ name:'Statut',value:'⏳ En attente',inline:true },{ name:'Votes',value:'👍 0  |  👎 0',inline:true })
      .setThumbnail(interaction.user.displayAvatarURL()).setTimestamp();
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`suggest_up:${id}`).setLabel('👍 Pour').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`suggest_down:${id}`).setLabel('👎 Contre').setStyle(ButtonStyle.Danger),
    );
    await targetCh.send({ embeds:[embed], components:[row] }).then(async msg=>setSuggestionMessageId(id,msg.id));
    await interaction.reply({ content:`✅ Suggestion soumise dans ${targetCh} !`, ephemeral:true });
  },
};

const suggestionReviewCmd = {
  data: new SlashCommandBuilder().setName('suggestion').setDescription('Gérer les suggestions (staff)')
    .addSubcommand(sub=>sub.setName('accept').setDescription('Accepter')
      .addIntegerOption(o=>o.setName('id').setDescription('ID').setRequired(true))
      .addStringOption(o=>o.setName('raison').setDescription('Raison')))
    .addSubcommand(sub=>sub.setName('deny').setDescription('Refuser')
      .addIntegerOption(o=>o.setName('id').setDescription('ID').setRequired(true))
      .addStringOption(o=>o.setName('raison').setDescription('Raison')))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  cooldown: 5,
  async execute(interaction) {
    const sub    = interaction.options.getSubcommand();
    const id     = interaction.options.getInteger('id');
    const reason = interaction.options.getString('raison')||'Aucune raison';
    reviewSuggestion(id, sub==='accept'?'accepted':'denied', interaction.user.id, reason);
    const icon = sub==='accept'?'✅':'❌';
    await interaction.reply({ embeds:[new EmbedBuilder().setDescription(`${icon} Suggestion **#${id}** ${sub==='accept'?'acceptée':'refusée'}.\n*Raison : ${reason}*`).setColor(sub==='accept'?0x57f287:0xed4245)] });
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// TAGS
// ─────────────────────────────────────────────────────────────────────────────
const tagCmd = {
  data: new SlashCommandBuilder().setName('tag').setDescription('Commandes personnalisées / tags')
    .addSubcommand(sub=>sub.setName('create').setDescription('Créer un tag')
      .addStringOption(o=>o.setName('nom').setDescription('Nom').setRequired(true))
      .addStringOption(o=>o.setName('contenu').setDescription('Contenu').setRequired(true)))
    .addSubcommand(sub=>sub.setName('edit').setDescription('Modifier un tag')
      .addStringOption(o=>o.setName('nom').setDescription('Nom').setRequired(true))
      .addStringOption(o=>o.setName('contenu').setDescription('Nouveau contenu').setRequired(true)))
    .addSubcommand(sub=>sub.setName('delete').setDescription('Supprimer un tag')
      .addStringOption(o=>o.setName('nom').setDescription('Nom').setRequired(true)))
    .addSubcommand(sub=>sub.setName('get').setDescription('Afficher un tag')
      .addStringOption(o=>o.setName('nom').setDescription('Nom').setRequired(true))
      .addUserOption(o=>o.setName('mentionner').setDescription('Mentionner un membre')))
    .addSubcommand(sub=>sub.setName('list').setDescription('Tous les tags')),
  cooldown: 3,
  async execute(interaction) {
    const sub  = interaction.options.getSubcommand();
    const name = interaction.options.getString('nom');
    if (sub==='create') {
      const content = interaction.options.getString('contenu');
      if (getTag(interaction.guild.id, name)) return interaction.reply({ content:'❌ Ce tag existe déjà.', ephemeral:true });
      createTag(interaction.guild.id, name, content, interaction.user.id);
      return interaction.reply({ content:`✅ Tag **${name}** créé.`, ephemeral:true });
    }
    if (sub==='edit') {
      const tag = getTag(interaction.guild.id, name);
      if (!tag) return interaction.reply({ content:'❌ Tag introuvable.', ephemeral:true });
      if (tag.author_id!==interaction.user.id&&!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) return interaction.reply({ content:'❌ Tu ne peux pas modifier ce tag.', ephemeral:true });
      const content = interaction.options.getString('contenu');
      updateTag(interaction.guild.id, name, content);
      return interaction.reply({ content:`✅ Tag **${name}** modifié.`, ephemeral:true });
    }
    if (sub==='delete') {
      const tag = getTag(interaction.guild.id, name);
      if (!tag) return interaction.reply({ content:'❌ Tag introuvable.', ephemeral:true });
      if (tag.author_id!==interaction.user.id&&!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) return interaction.reply({ content:'❌ Tu ne peux pas supprimer ce tag.', ephemeral:true });
      deleteTag(interaction.guild.id, name);
      return interaction.reply({ content:`🗑️ Tag **${name}** supprimé.`, ephemeral:true });
    }
    if (sub==='get') {
      const tag  = getTag(interaction.guild.id, name);
      if (!tag) return interaction.reply({ content:'❌ Tag introuvable.', ephemeral:true });
      incrementTagUses(interaction.guild.id, name);
      const mention = interaction.options.getUser('mentionner');
      return interaction.reply({ content:`${mention?`${mention} `:''}${tag.content}` });
    }
    if (sub==='list') {
      const tags = listTags(interaction.guild.id);
      if (!tags.length) return interaction.reply({ content:'ℹ️ Aucun tag créé.', ephemeral:true });
      const embed = new EmbedBuilder().setTitle(`🏷️ Tags — ${interaction.guild.name}`).setColor(0x5865f2)
        .setDescription(tags.map(t=>`**${t.name}** — ${t.uses} util. *(par <@${t.author_id}>)*`).join('\n'))
        .setFooter({ text:`${tags.length} tag(s)` });
      return interaction.reply({ embeds:[embed], ephemeral:true });
    }
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// RAPPELS
// ─────────────────────────────────────────────────────────────────────────────
const remindCmd = {
  data: new SlashCommandBuilder().setName('remind').setDescription('Gérer tes rappels')
    .addSubcommand(s=>s.setName('set').setDescription('Créer un rappel')
      .addStringOption(o=>o.setName('duree').setDescription('Dans combien de temps ? (10m, 2h, 1d)').setRequired(true))
      .addStringOption(o=>o.setName('message').setDescription('Message du rappel').setRequired(true)))
    .addSubcommand(s=>s.setName('list').setDescription('Voir mes rappels en attente'))
    .addSubcommand(s=>s.setName('cancel').setDescription('Annuler un rappel')
      .addIntegerOption(o=>o.setName('id').setDescription('ID du rappel').setRequired(true))),
  cooldown: 5,
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    if (sub==='set') {
      const durStr  = interaction.options.getString('duree');
      const message = interaction.options.getString('message');
      const durSec  = parseDuration(durStr);
      if (!durSec) return interaction.reply({ content:'❌ Format invalide. Ex: `10m`, `2h`, `1d`', ephemeral:true });
      const remindAt = Math.floor(Date.now()/1000)+durSec;
      createReminder(interaction.user.id, interaction.guild.id, interaction.channel.id, message, remindAt);
      return interaction.reply({ embeds:[new EmbedBuilder().setDescription(`⏰ Rappel créé ! Je te rappellerai <t:${remindAt}:R>.\n> ${message}`).setColor(0x5865f2)], ephemeral:true });
    }
    if (sub==='list') {
      const reminders = getUserReminders(interaction.user.id);
      if (!reminders.length) return interaction.reply({ content:'ℹ️ Aucun rappel en attente.', ephemeral:true });
      const embed = new EmbedBuilder().setTitle('⏰ Mes rappels').setColor(0x5865f2)
        .setDescription(reminders.map(r=>`**#${r.id}** <t:${r.remind_at}:R>\n> ${r.message.slice(0,100)}`).join('\n\n'));
      return interaction.reply({ embeds:[embed], ephemeral:true });
    }
    if (sub==='cancel') {
      const id = interaction.options.getInteger('id');
      deleteReminder(id, interaction.user.id);
      return interaction.reply({ content:`✅ Rappel **#${id}** annulé.`, ephemeral:true });
    }
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// ÉCONOMIE
// ─────────────────────────────────────────────────────────────────────────────
const dailyCmd = {
  data: new SlashCommandBuilder().setName('daily').setDescription('Réclamer ta récompense quotidienne'),
  cooldown: 3,
  async execute(interaction) {
    const eco  = getEconomy(interaction.guild.id, interaction.user.id);
    const now  = Math.floor(Date.now()/1000);
    const next = (eco.last_daily||0)+86400;
    if (now<next) return interaction.reply({ content:`⏳ Tu as déjà réclamé ta récompense. Reviens <t:${next}:R>.`, ephemeral:true });
    const amount = Math.floor(Math.random()*200)+100;
    addCoins(interaction.guild.id, interaction.user.id, amount);
    setLastDaily(interaction.guild.id, interaction.user.id, now);
    const newEco = getEconomy(interaction.guild.id, interaction.user.id);
    await interaction.reply({ embeds:[new EmbedBuilder().setTitle('💰 Récompense quotidienne').setDescription(`Tu as reçu **${amount} 🪙** !\nSolde : **${newEco.balance} 🪙**`).setColor(0xffd700).setTimestamp()] });
  },
};

const workCmd = {
  data: new SlashCommandBuilder().setName('work').setDescription('Travailler pour gagner des 🪙 (cooldown 4h)'),
  cooldown: 3,
  async execute(interaction) {
    const eco  = getEconomy(interaction.guild.id, interaction.user.id);
    const now  = Math.floor(Date.now()/1000);
    const next = (eco.last_work||0)+14400; // 4h
    if (now<next) return interaction.reply({ content:`⏳ Tu as déjà travaillé récemment. Reviens <t:${next}:R>.`, ephemeral:true });
    const JOBS = [
      { job:'développeur',pay:[200,500] },{ job:'boulanger',pay:[80,200] },
      { job:'médecin',pay:[300,700] },{ job:'enseignant',pay:[100,250] },
      { job:'pizzaiolo',pay:[60,160] },{ job:'pompier',pay:[180,400] },
      { job:'streamer',pay:[50,1000] },{ job:'hacker éthique',pay:[250,600] },
    ];
    const pick   = JOBS[Math.floor(Math.random()*JOBS.length)];
    const amount = Math.floor(Math.random()*(pick.pay[1]-pick.pay[0]))+pick.pay[0];
    addCoins(interaction.guild.id, interaction.user.id, amount);
    setLastWork(interaction.guild.id, interaction.user.id, now);
    const newEco = getEconomy(interaction.guild.id, interaction.user.id);
    await interaction.reply({ embeds:[new EmbedBuilder().setTitle('💼 Travail terminé !').setDescription(`Tu as travaillé comme **${pick.job}** et gagné **${amount} 🪙** !\nSolde : **${newEco.balance} 🪙**`).setColor(0x57f287).setTimestamp()] });
  },
};

const balanceCmd = {
  data: new SlashCommandBuilder().setName('balance').setDescription('Voir ton solde ou celui d\'un membre')
    .addUserOption(o=>o.setName('membre').setDescription('Membre')),
  cooldown: 5,
  async execute(interaction) {
    const target = interaction.options.getUser('membre')||interaction.user;
    const eco    = getEconomy(interaction.guild.id, target.id);
    await interaction.reply({ embeds:[new EmbedBuilder().setTitle(`💰 Solde — ${target.username}`)
      .addFields({ name:'Solde',value:`**${eco.balance} 🪙**`,inline:true },{ name:'Total gagné',value:`**${eco.total_earned} 🪙**`,inline:true })
      .setColor(0xffd700).setThumbnail(target.displayAvatarURL())] });
  },
};

const payCmd = {
  data: new SlashCommandBuilder().setName('pay').setDescription('Envoyer des 🪙 à un membre')
    .addUserOption(o=>o.setName('membre').setDescription('Destinataire').setRequired(true))
    .addIntegerOption(o=>o.setName('montant').setDescription('Montant').setRequired(true).setMinValue(1)),
  cooldown: 10,
  async execute(interaction) {
    const target = interaction.options.getUser('membre');
    const amount = interaction.options.getInteger('montant');
    if (target.id===interaction.user.id) return interaction.reply({ content:'❌ Tu ne peux pas te payer toi-même.', ephemeral:true });
    if (target.bot) return interaction.reply({ content:'❌ Tu ne peux pas payer un bot.', ephemeral:true });
    const eco = getEconomy(interaction.guild.id, interaction.user.id);
    if (eco.balance<amount) return interaction.reply({ content:`❌ Solde insuffisant. Tu as **${eco.balance} 🪙**.`, ephemeral:true });
    transferCoins(interaction.guild.id, interaction.user.id, target.id, amount);
    await interaction.reply({ embeds:[new EmbedBuilder().setDescription(`✅ **${interaction.user.username}** a envoyé **${amount} 🪙** à **${target.username}**.`).setColor(0x57f287)] });
  },
};

const ecoLeaderboardCmd = {
  data: new SlashCommandBuilder().setName('richlist').setDescription('Top 10 des membres les plus riches'),
  cooldown: 10,
  async execute(interaction) {
    await interaction.deferReply();
    const data  = getEcoLeaderboard(interaction.guild.id, 10);
    const lines = await Promise.all(data.map(async (row,i)=>{
      const user = await interaction.client.users.fetch(row.user_id).catch(()=>null);
      const m    = i===0?'🥇':i===1?'🥈':i===2?'🥉':`**${i+1}.**`;
      return `${m} ${user?`**${user.username}**`:`<@${row.user_id}>`} — **${row.balance} 🪙**`;
    }));
    await interaction.editReply({ embeds:[new EmbedBuilder().setTitle(`💰 Top richesse — ${interaction.guild.name}`).setColor(0xffd700).setDescription(lines.join('\n')||'Aucune donnée.').setTimestamp()] });
  },
};

const gambleCmd = {
  data: new SlashCommandBuilder().setName('gamble').setDescription('Parier des 🪙 (50% chance de doubler)')
    .addIntegerOption(o=>o.setName('mise').setDescription('Montant à miser').setRequired(true).setMinValue(1)),
  cooldown: 10,
  async execute(interaction) {
    const mise = interaction.options.getInteger('mise');
    const eco  = getEconomy(interaction.guild.id, interaction.user.id);
    if (eco.balance<mise) return interaction.reply({ content:`❌ Solde insuffisant. Tu as **${eco.balance} 🪙**.`, ephemeral:true });
    const win  = Math.random()<0.5;
    if (win) addCoins(interaction.guild.id, interaction.user.id, mise);
    else deductCoins(interaction.guild.id, interaction.user.id, mise);
    const newEco = getEconomy(interaction.guild.id, interaction.user.id);
    await interaction.reply({ embeds:[new EmbedBuilder()
      .setTitle(win?'🎰 Gagné !':'🎰 Perdu !')
      .setDescription(win?`Tu as gagné **${mise} 🪙** ! Nouveau solde : **${newEco.balance} 🪙**`:`Tu as perdu **${mise} 🪙**. Nouveau solde : **${newEco.balance} 🪙**`)
      .setColor(win?0x57f287:0xed4245).setTimestamp()] });
  },
};

const slotsCmd = {
  data: new SlashCommandBuilder().setName('slots').setDescription('Machine à sous !')
    .addIntegerOption(o=>o.setName('mise').setDescription('Montant à miser').setRequired(true).setMinValue(10)),
  cooldown: 10,
  async execute(interaction) {
    const mise   = interaction.options.getInteger('mise');
    const eco    = getEconomy(interaction.guild.id, interaction.user.id);
    if (eco.balance<mise) return interaction.reply({ content:`❌ Solde insuffisant. Tu as **${eco.balance} 🪙**.`, ephemeral:true });
    const SYMBOLS = ['🍒','🍋','🍊','⭐','💎','7️⃣','🎰'];
    const slots   = [0,1,2].map(()=>SYMBOLS[Math.floor(Math.random()*SYMBOLS.length)]);
    const all3    = slots[0]===slots[1]&&slots[1]===slots[2];
    const two     = slots[0]===slots[1]||slots[1]===slots[2]||slots[0]===slots[2];
    let gain=0, msg='';
    if (all3 && slots[0]==='💎') { gain=mise*10; msg=`💎 JACKPOT x10 !`; }
    else if (all3 && slots[0]==='7️⃣') { gain=mise*5; msg=`7️⃣ SUPER x5 !`; }
    else if (all3) { gain=mise*3; msg=`Trois identiques ! x3`; }
    else if (two) { gain=mise; msg=`Deux identiques ! Mise récupérée.`; }
    else { gain=-mise; msg=`Rien... Tu perds ta mise.`; }
    if (gain>0) addCoins(interaction.guild.id, interaction.user.id, gain);
    else if (gain<0) deductCoins(interaction.guild.id, interaction.user.id, mise);
    const newEco = getEconomy(interaction.guild.id, interaction.user.id);
    await interaction.reply({ embeds:[new EmbedBuilder()
      .setTitle('🎰 Machine à sous')
      .setDescription(`**${slots.join(' | ')}**\n\n${msg}\n${gain>0?`+${gain} 🪙`:`${gain} 🪙`}\nSolde : **${newEco.balance} 🪙**`)
      .setColor(gain>0?0xffd700:0xed4245).setTimestamp()] });
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// FUN
// ─────────────────────────────────────────────────────────────────────────────
const EIGHTBALL_RESPONSES = [
  '✅ Oui, absolument.','✅ C\'est certain.','✅ Sans aucun doute.','✅ Très probablement.',
  '🤔 Je ne peux pas le dire.','🤔 Demande plus tard.','🤔 Difficile à dire.',
  '❌ Non.','❌ Absolument pas.','❌ Mes sources disent non.','❌ Ne compte pas dessus.',
];
const eightballCmd = {
  data: new SlashCommandBuilder().setName('8ball').setDescription('Pose une question à la boule magique')
    .addStringOption(o=>o.setName('question').setDescription('Ta question').setRequired(true)),
  cooldown: 3,
  async execute(interaction) {
    const question = interaction.options.getString('question');
    const answer   = EIGHTBALL_RESPONSES[Math.floor(Math.random()*EIGHTBALL_RESPONSES.length)];
    await interaction.reply({ embeds:[new EmbedBuilder().setTitle('🎱 Magic 8-Ball').addFields({name:'❓ Question',value:question},{name:'🎱 Réponse',value:answer}).setColor(0x2b2d31)] });
  },
};

const coinflipCmd = {
  data: new SlashCommandBuilder().setName('coinflip').setDescription('Lancer une pièce'),
  cooldown: 3,
  async execute(interaction) {
    const result = Math.random()<0.5?'🪙 FACE':'🪙 PILE';
    await interaction.reply({ embeds:[new EmbedBuilder().setDescription(`**${result}** !`).setColor(0xffd700)] });
  },
};

const diceCmd = {
  data: new SlashCommandBuilder().setName('dice').setDescription('Lancer un dé')
    .addIntegerOption(o=>o.setName('faces').setDescription('Nb faces (défaut: 6)').setMinValue(2).setMaxValue(10000))
    .addIntegerOption(o=>o.setName('nombre').setDescription('Nb de dés (défaut: 1)').setMinValue(1).setMaxValue(10)),
  cooldown: 3,
  async execute(interaction) {
    const faces  = interaction.options.getInteger('faces')??6;
    const count  = interaction.options.getInteger('nombre')??1;
    const rolls  = Array.from({length:count},()=>Math.floor(Math.random()*faces)+1);
    const total  = rolls.reduce((a,b)=>a+b,0);
    await interaction.reply({ embeds:[new EmbedBuilder()
      .setTitle(`🎲 ${count}D${faces}`)
      .setDescription(`Résultats : **${rolls.join(', ')}**${count>1?`\nTotal : **${total}**`:''}`)
      .setColor(0x5865f2)] });
  },
};

const rpsCmd = {
  data: new SlashCommandBuilder().setName('rps').setDescription('Pierre Feuille Ciseaux contre le bot')
    .addStringOption(o=>o.setName('choix').setDescription('Ton choix').setRequired(true).addChoices(
      { name:'✊ Pierre', value:'pierre' },
      { name:'✋ Feuille', value:'feuille' },
      { name:'✌️ Ciseaux', value:'ciseaux' },
    )),
  cooldown: 3,
  async execute(interaction) {
    const choices = ['pierre','feuille','ciseaux'];
    const emojis  = { pierre:'✊', feuille:'✋', ciseaux:'✌️' };
    const player  = interaction.options.getString('choix');
    const bot     = choices[Math.floor(Math.random()*3)];
    const beats   = { pierre:'ciseaux', feuille:'pierre', ciseaux:'feuille' };
    const result  = player===bot ? 'Égalité !' : beats[player]===bot ? '🎉 Tu gagnes !' : '😔 Le bot gagne !';
    const color   = player===bot?0xfee75c:beats[player]===bot?0x57f287:0xed4245;
    await interaction.reply({ embeds:[new EmbedBuilder().setTitle('✊✋✌️ Pierre Feuille Ciseaux')
      .addFields({name:'Toi',value:`${emojis[player]} ${player}`,inline:true},{name:'Bot',value:`${emojis[bot]} ${bot}`,inline:true},{name:'Résultat',value:result})
      .setColor(color)] });
  },
};

const randomCmd = {
  data: new SlashCommandBuilder().setName('random').setDescription('Nombre aléatoire')
    .addIntegerOption(o=>o.setName('min').setDescription('Minimum (défaut: 1)'))
    .addIntegerOption(o=>o.setName('max').setDescription('Maximum (défaut: 100)').setMaxValue(1000000)),
  cooldown: 3,
  async execute(interaction) {
    const min = interaction.options.getInteger('min')??1;
    const max = interaction.options.getInteger('max')??100;
    if (min>=max) return interaction.reply({ content:'❌ Le minimum doit être inférieur au maximum.', ephemeral:true });
    const result = Math.floor(Math.random()*(max-min+1))+min;
    await interaction.reply({ embeds:[new EmbedBuilder().setDescription(`🎲 Nombre aléatoire entre **${min}** et **${max}** : **${result}**`).setColor(0x5865f2)] });
  },
};

const chooseCmd = {
  data: new SlashCommandBuilder().setName('choose').setDescription('Choisir aléatoirement parmi plusieurs options (séparées par |)')
    .addStringOption(o=>o.setName('options').setDescription('Ex: option1 | option2 | option3').setRequired(true)),
  cooldown: 3,
  async execute(interaction) {
    const opts   = interaction.options.getString('options').split('|').map(s=>s.trim()).filter(Boolean);
    if (opts.length<2) return interaction.reply({ content:'❌ Tu dois fournir au moins 2 options séparées par `|`.', ephemeral:true });
    const chosen = opts[Math.floor(Math.random()*opts.length)];
    await interaction.reply({ embeds:[new EmbedBuilder().setTitle('🎯 Choix aléatoire')
      .addFields({name:'Options',value:opts.map((o,i)=>`${i+1}. ${o}`).join('\n')},{name:'Choix',value:`**${chosen}**`})
      .setColor(0x5865f2)] });
  },
};

const reverseCmd = {
  data: new SlashCommandBuilder().setName('reverse').setDescription('Inverser un texte')
    .addStringOption(o=>o.setName('texte').setDescription('Texte à inverser').setRequired(true)),
  cooldown: 3,
  async execute(interaction) {
    const texte  = interaction.options.getString('texte');
    const result = [...texte].reverse().join('');
    await interaction.reply({ embeds:[new EmbedBuilder().addFields({name:'Original',value:texte.slice(0,500)},{name:'Inversé',value:result.slice(0,500)}).setColor(0x5865f2)] });
  },
};

const mockCmd = {
  data: new SlashCommandBuilder().setName('mock').setDescription('mOcKeR uN tExTe (SpOnGeBoB mEmE)')
    .addStringOption(o=>o.setName('texte').setDescription('Texte').setRequired(true)),
  cooldown: 3,
  async execute(interaction) {
    const texte  = interaction.options.getString('texte');
    const result = [...texte].map((c,i)=>i%2===0?c.toLowerCase():c.toUpperCase()).join('');
    await interaction.reply({ content:`> ${result}` });
  },
};

const jokeCmd = {
  data: new SlashCommandBuilder().setName('joke').setDescription('Une blague aléatoire en français'),
  cooldown: 5,
  async execute(interaction) {
    const JOKES = [
      { q:'Pourquoi le livre de maths est-il triste ?', r:'Parce qu\'il a beaucoup de problèmes.' },
      { q:'Qu\'est-ce qu\'un canif ?', r:'Un petit fien !' },
      { q:'Pourquoi les plongeurs plongent-ils toujours en arrière ?', r:'Parce que sinon ils tomberaient dans le bateau !' },
      { q:'Qu\'est-ce qu\'un chat qui tombe dans un pot de peinture le jour de Noël ?', r:'Un chat-peint de Noël !' },
      { q:'Que dit un escargot quand il croise une limace ?', r:'Oh ! Un nudiste !' },
      { q:'Pourquoi l\'épouvantail a-t-il eu un prix ?', r:'Parce qu\'il était exceptionnel dans son domaine.' },
      { q:'Comment appelle-t-on un chat tombé dans un pot de colle ?', r:'Un chat-collé !' },
      { q:'Qu\'est-ce qu\'un crocodile qui surveille des bagages ?', r:'Un sac-à-dents !' },
      { q:'Pourquoi les poissons nagent-ils dans l\'eau salée ?', r:'Parce que l\'eau poivrée les fait éternuer !' },
      { q:'Qu\'est-ce qu\'un cannibal végétarien ?', r:'Quelqu\'un qui mange des Bouddhistes.' },
      { q:'Comment appelle-t-on un cerf sans yeux ?', r:'Aucune idée, il n\'y a pas d\'œil dedans !' },
      { q:'Que dit un oignon quand il saute d\'une falaise ?', r:'Baguette !' },
      { q:'Pourquoi les fantômes ne mentent-ils jamais ?', r:'Parce qu\'on peut voir à travers eux !' },
    ];
    const joke = JOKES[Math.floor(Math.random()*JOKES.length)];
    await interaction.reply({ embeds:[new EmbedBuilder().setTitle('😂 Blague du jour')
      .addFields({name:'❓',value:joke.q},{name:'💡',value:`||${joke.r}||`})
      .setColor(0xfee75c).setFooter({ text:'Cliquez sur le texte caché pour voir la réponse !' })] });
  },
};

const colorCmd = {
  data: new SlashCommandBuilder().setName('color').setDescription('Afficher une couleur hexadécimale')
    .addStringOption(o=>o.setName('hex').setDescription('Code hex (ex: #FF5733 ou FF5733)').setRequired(true)),
  cooldown: 3,
  async execute(interaction) {
    const raw = interaction.options.getString('hex').replace(/^#/,'');
    if (!/^[0-9a-fA-F]{6}$/.test(raw)) return interaction.reply({ content:'❌ Code hexadécimal invalide. Ex: `#FF5733`', ephemeral:true });
    const int  = parseInt(raw,16);
    const r    = (int>>16)&255, g=(int>>8)&255, b=int&255;
    await interaction.reply({ embeds:[new EmbedBuilder().setTitle(`🎨 #${raw.toUpperCase()}`)
      .addFields({name:'RGB',value:`rgb(${r}, ${g}, ${b})`,inline:true},{name:'Décimal',value:`${int}`,inline:true})
      .setColor(int).setDescription(`Aperçu de la couleur **#${raw.toUpperCase()}**`)] });
  },
};

const timestampCmd = {
  data: new SlashCommandBuilder().setName('timestamp').setDescription('Convertir une date en timestamp Discord')
    .addStringOption(o=>o.setName('date').setDescription('Date (YYYY-MM-DD ou YYYY-MM-DD HH:MM)').setRequired(true)),
  cooldown: 3,
  async execute(interaction) {
    const input = interaction.options.getString('date');
    const date  = new Date(input);
    if (isNaN(date.getTime())) return interaction.reply({ content:'❌ Format de date invalide. Ex: `2025-12-25` ou `2025-12-25 18:00`', ephemeral:true });
    const ts = Math.floor(date.getTime()/1000);
    const embed = new EmbedBuilder().setTitle('🕒 Timestamp Discord').setColor(0x5865f2)
      .setDescription([
        `**Date saisie :** ${input}`,
        `**Unix timestamp :** \`${ts}\``,
        '',
        `**Formats Discord :**`,
        `\`<t:${ts}:F>\` → <t:${ts}:F>`,
        `\`<t:${ts}:R>\` → <t:${ts}:R>`,
        `\`<t:${ts}:D>\` → <t:${ts}:D>`,
        `\`<t:${ts}:T>\` → <t:${ts}:T>`,
      ].join('\n'));
    await interaction.reply({ embeds:[embed], ephemeral:true });
  },
};

const calculateCmd = {
  data: new SlashCommandBuilder().setName('calculate').setDescription('Calculer une expression mathématique')
    .addStringOption(o=>o.setName('expression').setDescription('Ex: 2+2, 15*3, sqrt(144)').setRequired(true)),
  cooldown: 3,
  async execute(interaction) {
    const expr = interaction.options.getString('expression');
    // Sécurisé : uniquement chiffres et opérations basiques
    if (!/^[\d\s\+\-\*\/\(\)\.\^%,sqrtpow]+$/i.test(expr)) {
      return interaction.reply({ content:'❌ Expression non autorisée. Utilise uniquement des chiffres et `+ - * / ( ) . % sqrt pow`', ephemeral:true });
    }
    try {
      const safe  = expr.replace(/sqrt\(([^)]+)\)/g, (m,p)=>`Math.sqrt(${p})`).replace(/pow\(([^,]+),([^)]+)\)/g, (m,a,b)=>`Math.pow(${a},${b})`).replace(/\^/g,'**');
      const result = Function(`"use strict"; return (${safe})`)();
      if (!isFinite(result)) return interaction.reply({ content:'❌ Résultat infini ou invalide.', ephemeral:true });
      await interaction.reply({ embeds:[new EmbedBuilder().setTitle('🧮 Calculatrice').addFields({name:'Expression',value:`\`${expr}\``},{name:'Résultat',value:`**${result}**`}).setColor(0x5865f2)] });
    } catch {
      await interaction.reply({ content:'❌ Erreur dans l\'expression.', ephemeral:true });
    }
  },
};

module.exports = [
  giveawayCmd, pollCmd, suggestCmd, suggestionReviewCmd,
  tagCmd, remindCmd,
  dailyCmd, workCmd, balanceCmd, payCmd, ecoLeaderboardCmd, gambleCmd, slotsCmd,
  eightballCmd, coinflipCmd, diceCmd, rpsCmd, randomCmd, chooseCmd,
  reverseCmd, mockCmd, jokeCmd, colorCmd, timestampCmd, calculateCmd,
];

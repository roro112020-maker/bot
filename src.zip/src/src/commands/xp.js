/**
 * Commandes de gestion de l'XP
 * /xp — add/remove/set/reset/view (admin)
 * /xp-config — toggle/multiplier/cooldown/noxp-channel/level-msg
 * /rank-card — voir sa carte de rang
 * /setlevel — définir le niveau directement
 */

const {
  SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits,
} = require('discord.js');
const {
  getLevel, setUserXp, setUserLevel, resetXp, getLeaderboard,
  getGuildConfig, setGuildConfig,
} = require('../handlers/database');

// ─── /xp ──────────────────────────────────────────────────────────────────────
const xpCmd = {
  data: new SlashCommandBuilder().setName('xp').setDescription('Gérer l\'XP des membres (admin)')
    .addSubcommand(s => s.setName('view').setDescription('Voir l\'XP d\'un membre')
      .addUserOption(o => o.setName('membre').setDescription('Membre (défaut: toi)')))
    .addSubcommand(s => s.setName('add').setDescription('Ajouter de l\'XP à un membre')
      .addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true))
      .addIntegerOption(o => o.setName('montant').setDescription('Montant XP').setRequired(true).setMinValue(1).setMaxValue(1000000)))
    .addSubcommand(s => s.setName('remove').setDescription('Retirer de l\'XP à un membre')
      .addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true))
      .addIntegerOption(o => o.setName('montant').setDescription('Montant XP').setRequired(true).setMinValue(1).setMaxValue(1000000)))
    .addSubcommand(s => s.setName('set').setDescription('Définir l\'XP d\'un membre')
      .addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true))
      .addIntegerOption(o => o.setName('montant').setDescription('XP total').setRequired(true).setMinValue(0)))
    .addSubcommand(s => s.setName('reset').setDescription('Remettre l\'XP à 0')
      .addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true))),
  cooldown: 3,
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'view') {
      const target = interaction.options.getMember('membre') || interaction.member;
      const data   = getLevel(interaction.guild.id, target.id);
      const xpNext = Math.pow((data.level + 1) / 0.1, 2);
      const prog   = Math.floor((data.xp / xpNext) * 20);
      const bar    = '█'.repeat(prog) + '░'.repeat(20 - prog);
      return interaction.reply({ embeds: [new EmbedBuilder().setTitle(`⭐ XP — ${target.user.tag}`)
        .addFields(
          { name: '📊 Niveau',   value: `**${data.level}**`,         inline: true },
          { name: '⭐ XP Total', value: `**${data.xp.toLocaleString()}**`, inline: true },
          { name: '💬 Messages', value: `**${data.messages}**`,      inline: true },
          { name: 'Prochain niveau', value: `\`[${bar}]\` ${data.xp}/${Math.floor(xpNext)} XP` },
        ).setColor(0x5865f2).setThumbnail(target.user.displayAvatarURL())
        .setFooter({ text: `XP requis pour niveau ${data.level + 1}: ${Math.floor(xpNext - data.xp)} XP` })] });
    }

    // Pour les sous-commandes admin, vérifier les permissions
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ content: '❌ Tu dois être administrateur.', ephemeral: true });
    }

    const target = interaction.options.getUser('membre');
    const amount = interaction.options.getInteger('montant') ?? 0;

    if (sub === 'add') {
      const data = getLevel(interaction.guild.id, target.id);
      setUserXp(interaction.guild.id, target.id, data.xp + amount);
      const newData = getLevel(interaction.guild.id, target.id);
      return interaction.reply({ content: `✅ **+${amount} XP** ajouté à **${target.username}** (Niveau ${newData.level}, Total: ${newData.xp} XP).`, ephemeral: true });
    }
    if (sub === 'remove') {
      const data = getLevel(interaction.guild.id, target.id);
      setUserXp(interaction.guild.id, target.id, Math.max(0, data.xp - amount));
      const newData = getLevel(interaction.guild.id, target.id);
      return interaction.reply({ content: `✅ **-${amount} XP** retiré à **${target.username}** (Niveau ${newData.level}, Total: ${newData.xp} XP).`, ephemeral: true });
    }
    if (sub === 'set') {
      setUserXp(interaction.guild.id, target.id, amount);
      const newData = getLevel(interaction.guild.id, target.id);
      return interaction.reply({ content: `✅ XP de **${target.username}** défini à **${amount}** (Niveau ${newData.level}).`, ephemeral: true });
    }
    if (sub === 'reset') {
      resetXp(interaction.guild.id, target.id);
      return interaction.reply({ content: `✅ XP de **${target.username}** remis à zéro.`, ephemeral: true });
    }
  },
};

// ─── /xp-config ───────────────────────────────────────────────────────────────
const xpConfigCmd = {
  data: new SlashCommandBuilder().setName('xp-config').setDescription('Configurer le système XP du serveur')
    .addSubcommand(s => s.setName('toggle').setDescription('Activer/désactiver le système XP')
      .addBooleanOption(o => o.setName('actif').setDescription('Activer (true) ou désactiver (false)').setRequired(true)))
    .addSubcommand(s => s.setName('multiplier').setDescription('Définir le multiplicateur d\'XP')
      .addNumberOption(o => o.setName('valeur').setDescription('Multiplicateur (ex: 2.0 = double XP)').setRequired(true).setMinValue(0.1).setMaxValue(10)))
    .addSubcommand(s => s.setName('cooldown').setDescription('Définir le cooldown entre deux gains d\'XP')
      .addIntegerOption(o => o.setName('secondes').setDescription('Cooldown en secondes (défaut: 60)').setRequired(true).setMinValue(0).setMaxValue(3600)))
    .addSubcommand(s => s.setName('noxp-channel').setDescription('Exclure ou ré-inclure un salon du système XP')
      .addChannelOption(o => o.setName('salon').setDescription('Salon').setRequired(true))
      .addBooleanOption(o => o.setName('exclure').setDescription('Exclure (true) ou ré-inclure (false)').setRequired(true)))
    .addSubcommand(s => s.setName('view').setDescription('Voir la configuration XP actuelle'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  cooldown: 5,
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'toggle') {
      const actif = interaction.options.getBoolean('actif');
      setGuildConfig(interaction.guild.id, 'xp_enabled', actif ? 1 : 0);
      return interaction.reply({ content: `✅ Système XP ${actif ? '**activé**' : '**désactivé**'}.`, ephemeral: true });
    }
    if (sub === 'multiplier') {
      const val = interaction.options.getNumber('valeur');
      setGuildConfig(interaction.guild.id, 'xp_multiplier', val);
      return interaction.reply({ content: `✅ Multiplicateur XP défini à **×${val}**.`, ephemeral: true });
    }
    if (sub === 'cooldown') {
      const sec = interaction.options.getInteger('secondes');
      setGuildConfig(interaction.guild.id, 'xp_cooldown', sec);
      return interaction.reply({ content: `✅ Cooldown XP défini à **${sec} secondes**.`, ephemeral: true });
    }
    if (sub === 'noxp-channel') {
      const ch      = interaction.options.getChannel('salon');
      const exclure = interaction.options.getBoolean('exclure');
      const config  = getGuildConfig(interaction.guild.id);
      let noXp      = (config.no_xp_channels || '').split(',').filter(Boolean);
      if (exclure) {
        if (!noXp.includes(ch.id)) noXp.push(ch.id);
      } else {
        noXp = noXp.filter(id => id !== ch.id);
      }
      setGuildConfig(interaction.guild.id, 'no_xp_channels', noXp.join(','));
      return interaction.reply({ content: `✅ ${ch} est maintenant ${exclure ? '**exclu**' : '**ré-inclus**'} du système XP.`, ephemeral: true });
    }
    if (sub === 'view') {
      const config = getGuildConfig(interaction.guild.id);
      const noXp   = (config.no_xp_channels || '').split(',').filter(Boolean);
      return interaction.reply({ embeds: [new EmbedBuilder().setTitle('⭐ Configuration XP').setColor(0x5865f2)
        .addFields(
          { name: '🟢 Activé',         value: config.xp_enabled ? '✅ Oui' : '❌ Non',    inline: true },
          { name: '✨ Multiplicateur',  value: `×${config.xp_multiplier || 1}`,             inline: true },
          { name: '⏱️ Cooldown',        value: `${config.xp_cooldown || 60} secondes`,      inline: true },
          { name: '🚫 Salons exclus',   value: noXp.length ? noXp.map(id => `<#${id}>`).join(', ') : 'Aucun' },
        )], ephemeral: true });
    }
  },
};

// ─── /setlevel ────────────────────────────────────────────────────────────────
const setlevelCmd = {
  data: new SlashCommandBuilder().setName('setlevel').setDescription('Définir le niveau d\'un membre directement')
    .addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true))
    .addIntegerOption(o => o.setName('niveau').setDescription('Niveau cible').setRequired(true).setMinValue(0).setMaxValue(1000))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  cooldown: 5,
  async execute(interaction) {
    const target = interaction.options.getUser('membre');
    const level  = interaction.options.getInteger('niveau');
    setUserLevel(interaction.guild.id, target.id, level);
    const data = getLevel(interaction.guild.id, target.id);
    return interaction.reply({ content: `✅ Niveau de **${target.username}** défini à **${level}** (${data.xp} XP).`, ephemeral: true });
  },
};

// ─── /resetlb ─────────────────────────────────────────────────────────────────
const resetlbCmd = {
  data: new SlashCommandBuilder().setName('resetlb').setDescription('Réinitialiser le classement XP du serveur (irréversible !)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  cooldown: 10,
  async execute(interaction) {
    const { getDb } = require('../handlers/database');
    const db = getDb();
    db.prepare('DELETE FROM levels WHERE guild_id=?').run(interaction.guild.id);
    return interaction.reply({ content: '🗑️ Classement XP du serveur entièrement réinitialisé.', ephemeral: true });
  },
};

// ─── /top ─────────────────────────────────────────────────────────────────────
const topCmd = {
  data: new SlashCommandBuilder().setName('top').setDescription('Classement XP du serveur')
    .addIntegerOption(o => o.setName('limite').setDescription('Nombre d\'entrées (5-25)').setMinValue(5).setMaxValue(25)),
  cooldown: 10,
  async execute(interaction) {
    await interaction.deferReply();
    const limit = interaction.options.getInteger('limite') ?? 10;
    const data  = getLeaderboard(interaction.guild.id, limit);
    if (!data.length) return interaction.editReply({ content: 'ℹ️ Aucune donnée de classement.' });
    const lines = await Promise.all(data.map(async (row, i) => {
      const user = await interaction.client.users.fetch(row.user_id).catch(() => null);
      const m    = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `**${i + 1}.**`;
      return `${m} ${user ? `**${user.username}**` : `<@${row.user_id}>`} — Niv. **${row.level}** · **${row.xp.toLocaleString()} XP**`;
    }));
    await interaction.editReply({ embeds: [new EmbedBuilder().setTitle(`⭐ Top ${limit} XP — ${interaction.guild.name}`).setColor(0x5865f2).setDescription(lines.join('\n')).setTimestamp()] });
  },
};

module.exports = [xpCmd, xpConfigCmd, setlevelCmd, resetlbCmd, topCmd];

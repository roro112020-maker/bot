/**
 * Commandes d'administration serveur
 * /channel /role /nick /prune /make-invite /mass-mute /mass-move
 * /server-edit /slowmode-all /clone-server-info
 */

const {
  SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType,
} = require('discord.js');
const { addModLog } = require('../handlers/database');

// ─── /channel ─────────────────────────────────────────────────────────────────
const channelCmd = {
  data: new SlashCommandBuilder().setName('channel').setDescription('Gérer les salons')
    .addSubcommand(s => s.setName('create').setDescription('Créer un salon')
      .addStringOption(o => o.setName('nom').setDescription('Nom du salon').setRequired(true))
      .addStringOption(o => o.setName('type').setDescription('Type').addChoices(
        { name: '💬 Textuel', value: 'text' },
        { name: '🔊 Vocal', value: 'voice' },
        { name: '📁 Catégorie', value: 'category' },
        { name: '📢 Annonces', value: 'news' },
        { name: '💬 Forum', value: 'forum' },
      ))
      .addChannelOption(o => o.setName('categorie').setDescription('Catégorie parente'))
      .addBooleanOption(o => o.setName('prive').setDescription('Salon privé (invisible par défaut)')))
    .addSubcommand(s => s.setName('delete').setDescription('Supprimer un salon')
      .addChannelOption(o => o.setName('salon').setDescription('Salon').setRequired(true))
      .addStringOption(o => o.setName('raison').setDescription('Raison')))
    .addSubcommand(s => s.setName('clone').setDescription('Cloner un salon')
      .addChannelOption(o => o.setName('salon').setDescription('Salon à cloner').setRequired(true)))
    .addSubcommand(s => s.setName('rename').setDescription('Renommer un salon')
      .addChannelOption(o => o.setName('salon').setDescription('Salon').setRequired(true))
      .addStringOption(o => o.setName('nom').setDescription('Nouveau nom').setRequired(true)))
    .addSubcommand(s => s.setName('topic').setDescription('Changer le sujet d\'un salon')
      .addChannelOption(o => o.setName('salon').setDescription('Salon').setRequired(true))
      .addStringOption(o => o.setName('sujet').setDescription('Nouveau sujet (vide pour supprimer)')))
    .addSubcommand(s => s.setName('slowmode-all').setDescription('Appliquer slowmode à tous les salons textuels')
      .addIntegerOption(o => o.setName('secondes').setDescription('Délai en secondes (0 = désactiver)').setRequired(true).setMinValue(0).setMaxValue(21600)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  cooldown: 5,
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub === 'create') {
      const nom      = interaction.options.getString('nom');
      const typeStr  = interaction.options.getString('type') || 'text';
      const cat      = interaction.options.getChannel('categorie');
      const prive    = interaction.options.getBoolean('prive') ?? false;
      const typeMap  = { text: ChannelType.GuildText, voice: ChannelType.GuildVoice, category: ChannelType.GuildCategory, news: ChannelType.GuildAnnouncement, forum: ChannelType.GuildForum };
      const overwrites = prive ? [{ id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] }] : [];
      const ch = await interaction.guild.channels.create({ name: nom, type: typeMap[typeStr] || ChannelType.GuildText, parent: cat?.id || null, permissionOverwrites: overwrites });
      return interaction.reply({ embeds: [new EmbedBuilder().setDescription(`✅ Salon ${ch} créé.`).setColor(0x57f287)] });
    }
    if (sub === 'delete') {
      const ch     = interaction.options.getChannel('salon');
      const reason = interaction.options.getString('raison') || 'Suppression admin';
      await ch.delete(reason);
      addModLog(interaction.guild.id, 'CHANNEL_DELETE', ch.id, interaction.user.id, reason);
      return interaction.reply({ content: `🗑️ Salon **${ch.name}** supprimé.`, ephemeral: true });
    }
    if (sub === 'clone') {
      const ch    = interaction.options.getChannel('salon');
      const clone = await ch.clone({ reason: `Clonage par ${interaction.user.tag}` });
      return interaction.reply({ embeds: [new EmbedBuilder().setDescription(`✅ Salon cloné : ${clone}`).setColor(0x57f287)] });
    }
    if (sub === 'rename') {
      const ch  = interaction.options.getChannel('salon');
      const nom = interaction.options.getString('nom');
      await ch.setName(nom);
      return interaction.reply({ content: `✅ Salon renommé en **${nom}**.`, ephemeral: true });
    }
    if (sub === 'topic') {
      const ch    = interaction.options.getChannel('salon');
      const sujet = interaction.options.getString('sujet') || null;
      await ch.setTopic(sujet);
      return interaction.reply({ content: `✅ Sujet mis à jour.`, ephemeral: true });
    }
    if (sub === 'slowmode-all') {
      const delay = interaction.options.getInteger('secondes');
      await interaction.deferReply({ ephemeral: true });
      const texts = interaction.guild.channels.cache.filter(c => c.type === ChannelType.GuildText);
      for (const [, ch] of texts) { await ch.setRateLimitPerUser(delay).catch(() => {}); }
      return interaction.editReply({ content: `✅ Slowmode **${delay}s** appliqué à ${texts.size} salons textuels.` });
    }
  },
};

// ─── /role ────────────────────────────────────────────────────────────────────
const roleCmd = {
  data: new SlashCommandBuilder().setName('role').setDescription('Gérer les rôles')
    .addSubcommand(s => s.setName('create').setDescription('Créer un rôle')
      .addStringOption(o => o.setName('nom').setDescription('Nom du rôle').setRequired(true))
      .addStringOption(o => o.setName('couleur').setDescription('Couleur hex (ex: FF5733)'))
      .addBooleanOption(o => o.setName('hisse').setDescription('Afficher séparément dans la liste'))
      .addBooleanOption(o => o.setName('mentionnable').setDescription('Mentionnable par tous')))
    .addSubcommand(s => s.setName('delete').setDescription('Supprimer un rôle')
      .addRoleOption(o => o.setName('role').setDescription('Rôle').setRequired(true))
      .addStringOption(o => o.setName('raison').setDescription('Raison')))
    .addSubcommand(s => s.setName('give').setDescription('Donner un rôle à un membre')
      .addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true))
      .addRoleOption(o => o.setName('role').setDescription('Rôle').setRequired(true)))
    .addSubcommand(s => s.setName('take').setDescription('Retirer un rôle à un membre')
      .addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true))
      .addRoleOption(o => o.setName('role').setDescription('Rôle').setRequired(true)))
    .addSubcommand(s => s.setName('color').setDescription('Changer la couleur d\'un rôle')
      .addRoleOption(o => o.setName('role').setDescription('Rôle').setRequired(true))
      .addStringOption(o => o.setName('couleur').setDescription('Nouvelle couleur hex').setRequired(true)))
    .addSubcommand(s => s.setName('rename').setDescription('Renommer un rôle')
      .addRoleOption(o => o.setName('role').setDescription('Rôle').setRequired(true))
      .addStringOption(o => o.setName('nom').setDescription('Nouveau nom').setRequired(true)))
    .addSubcommand(s => s.setName('info').setDescription('Informations sur un rôle')
      .addRoleOption(o => o.setName('role').setDescription('Rôle').setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),
  cooldown: 5,
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    if (sub === 'create') {
      const nom   = interaction.options.getString('nom');
      const color = interaction.options.getString('couleur')?.replace('#','') || null;
      const hoist = interaction.options.getBoolean('hisse') ?? false;
      const ment  = interaction.options.getBoolean('mentionnable') ?? false;
      const role  = await interaction.guild.roles.create({ name: nom, color: color ? `#${color}` : null, hoist, mentionable: ment });
      return interaction.reply({ embeds: [new EmbedBuilder().setDescription(`✅ Rôle ${role} créé.`).setColor(role.color||0x57f287)] });
    }
    if (sub === 'delete') {
      const role   = interaction.options.getRole('role');
      const reason = interaction.options.getString('raison') || 'Suppression admin';
      await role.delete(reason);
      return interaction.reply({ content: `🗑️ Rôle **${role.name}** supprimé.`, ephemeral: true });
    }
    if (sub === 'give') {
      const member = interaction.options.getMember('membre');
      const role   = interaction.options.getRole('role');
      await member.roles.add(role);
      return interaction.reply({ embeds: [new EmbedBuilder().setDescription(`✅ Rôle ${role} donné à ${member}.`).setColor(0x57f287)] });
    }
    if (sub === 'take') {
      const member = interaction.options.getMember('membre');
      const role   = interaction.options.getRole('role');
      await member.roles.remove(role);
      return interaction.reply({ embeds: [new EmbedBuilder().setDescription(`✅ Rôle ${role} retiré à ${member}.`).setColor(0xed4245)] });
    }
    if (sub === 'color') {
      const role  = interaction.options.getRole('role');
      const color = interaction.options.getString('couleur').replace('#','');
      await role.setColor(`#${color}`);
      return interaction.reply({ content: `✅ Couleur du rôle **${role.name}** changée en **#${color.toUpperCase()}**.`, ephemeral: true });
    }
    if (sub === 'rename') {
      const role = interaction.options.getRole('role');
      const nom  = interaction.options.getString('nom');
      await role.setName(nom);
      return interaction.reply({ content: `✅ Rôle renommé en **${nom}**.`, ephemeral: true });
    }
    if (sub === 'info') {
      const role    = interaction.options.getRole('role');
      const members = (await interaction.guild.members.fetch()).filter(m => m.roles.cache.has(role.id));
      return interaction.reply({ embeds: [new EmbedBuilder().setTitle(`🎭 ${role.name}`).setColor(role.color || 0x5865f2)
        .addFields(
          { name: 'ID',           value: role.id,                                            inline: true },
          { name: 'Couleur',      value: role.hexColor,                                      inline: true },
          { name: 'Membres',      value: `${members.size}`,                                  inline: true },
          { name: 'Mentionnable', value: role.mentionable ? '✅' : '❌',                     inline: true },
          { name: 'Hissé',        value: role.hoist ? '✅' : '❌',                           inline: true },
          { name: 'Position',     value: `${role.position}`,                                 inline: true },
          { name: 'Créé le',      value: `<t:${Math.floor(role.createdTimestamp/1000)}:R>`,  inline: true },
        ).setTimestamp()], ephemeral: true });
    }
  },
};

// ─── /nick ────────────────────────────────────────────────────────────────────
const nickCmd = {
  data: new SlashCommandBuilder().setName('nick').setDescription('Gérer les surnoms')
    .addSubcommand(s => s.setName('set').setDescription('Changer le surnom d\'un membre')
      .addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true))
      .addStringOption(o => o.setName('surnom').setDescription('Nouveau surnom (vide = réinitialiser)').setMaxLength(32)))
    .addSubcommand(s => s.setName('reset').setDescription('Réinitialiser le surnom d\'un membre')
      .addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true)))
    .addSubcommand(s => s.setName('mass-reset').setDescription('Réinitialiser tous les surnoms (lent !)')
      .addStringOption(o => o.setName('filtre').setDescription('Filtrer les noms contenant ce texte (optionnel)')))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageNicknames),
  cooldown: 3,
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    if (sub === 'set') {
      const member = interaction.options.getMember('membre');
      const nick   = interaction.options.getString('surnom') || null;
      if (!member.manageable) return interaction.reply({ content: '❌ Impossible de modifier ce membre.', ephemeral: true });
      await member.setNickname(nick);
      return interaction.reply({ content: `✅ Surnom ${nick ? `changé en **${nick}**` : 'réinitialisé'} pour ${member}.`, ephemeral: true });
    }
    if (sub === 'reset') {
      const member = interaction.options.getMember('membre');
      if (!member.manageable) return interaction.reply({ content: '❌ Impossible de modifier ce membre.', ephemeral: true });
      await member.setNickname(null);
      return interaction.reply({ content: `✅ Surnom de ${member} réinitialisé.`, ephemeral: true });
    }
    if (sub === 'mass-reset') {
      await interaction.deferReply({ ephemeral: true });
      const filtre  = interaction.options.getString('filtre')?.toLowerCase();
      const members = await interaction.guild.members.fetch();
      let count     = 0;
      for (const [, m] of members) {
        if (!m.nickname) continue;
        if (filtre && !m.nickname.toLowerCase().includes(filtre)) continue;
        if (!m.manageable) continue;
        await m.setNickname(null).catch(() => {});
        count++;
      }
      return interaction.editReply({ content: `✅ ${count} surnom(s) réinitialisé(s).` });
    }
  },
};

// ─── /prune ───────────────────────────────────────────────────────────────────
const pruneCmd = {
  data: new SlashCommandBuilder().setName('prune').setDescription('Expulser les membres inactifs depuis N jours')
    .addIntegerOption(o => o.setName('jours').setDescription('Jours d\'inactivité (1–30)').setRequired(true).setMinValue(1).setMaxValue(30))
    .addBooleanOption(o => o.setName('simulation').setDescription('Simuler sans expulser (défaut: oui)'))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
  cooldown: 15,
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const days = interaction.options.getInteger('jours');
    const dry  = interaction.options.getBoolean('simulation') ?? true;
    const count = await interaction.guild.members.prune({ days, dry }).catch(() => 0);
    const action = dry ? `${count} membre(s) **seraient** expulsés (simulation).` : `${count} membre(s) expulsés.`;
    await interaction.editReply({ content: `🧹 ${action}` });
  },
};

// ─── /make-invite ─────────────────────────────────────────────────────────────
const makeInviteCmd = {
  data: new SlashCommandBuilder().setName('make-invite').setDescription('Créer une invitation')
    .addChannelOption(o => o.setName('salon').setDescription('Salon (défaut: actuel)'))
    .addIntegerOption(o => o.setName('duree').setDescription('Durée en heures (0 = illimité)').setMinValue(0).setMaxValue(168))
    .addIntegerOption(o => o.setName('utilisations').setDescription('Nb utilisations max (0 = illimité)').setMinValue(0).setMaxValue(1000))
    .addBooleanOption(o => o.setName('temporaire').setDescription('Invitation temporaire'))
    .setDefaultMemberPermissions(PermissionFlagsBits.CreateInstantInvite),
  cooldown: 10,
  async execute(interaction) {
    const ch    = interaction.options.getChannel('salon') || interaction.channel;
    const hours = interaction.options.getInteger('duree') ?? 24;
    const uses  = interaction.options.getInteger('utilisations') ?? 0;
    const temp  = interaction.options.getBoolean('temporaire') ?? false;
    const inv   = await ch.createInvite({ maxAge: hours * 3600, maxUses: uses, temporary: temp, reason: `Invitation créée par ${interaction.user.tag}` });
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('📨 Invitation créée').setColor(0x5865f2)
      .addFields(
        { name: 'Lien',        value: `**${inv.url}**` },
        { name: 'Salon',       value: `${ch}`,                            inline: true },
        { name: 'Durée',       value: hours ? `${hours}h` : 'Illimitée',  inline: true },
        { name: 'Utilisations',value: uses  ? `${uses}` : 'Illimitées',   inline: true },
      ).setTimestamp()], ephemeral: true });
  },
};

// ─── /mass-mute ───────────────────────────────────────────────────────────────
const massMuteCmd = {
  data: new SlashCommandBuilder().setName('mass-mute').setDescription('Mettre en sourdine tous les membres d\'un salon vocal')
    .addChannelOption(o => o.setName('salon').setDescription('Salon vocal').setRequired(true))
    .addBooleanOption(o => o.setName('actif').setDescription('Mettre en sourdine (true) ou retirer (false)').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.MuteMembers),
  cooldown: 5,
  async execute(interaction) {
    const ch     = interaction.options.getChannel('salon');
    const mute   = interaction.options.getBoolean('actif');
    if (ch.type !== ChannelType.GuildVoice) return interaction.reply({ content: '❌ Ce salon n\'est pas un salon vocal.', ephemeral: true });
    await interaction.deferReply({ ephemeral: true });
    let count = 0;
    for (const [, m] of ch.members) {
      await m.voice.setMute(mute).catch(() => {});
      count++;
    }
    await interaction.editReply({ content: `✅ ${count} membre(s) ${mute ? 'mis en sourdine' : 'démutés'}.` });
  },
};

// ─── /mass-move ───────────────────────────────────────────────────────────────
const massMoveCmd = {
  data: new SlashCommandBuilder().setName('mass-move').setDescription('Déplacer tous les membres d\'un salon vocal vers un autre')
    .addChannelOption(o => o.setName('source').setDescription('Salon source').setRequired(true))
    .addChannelOption(o => o.setName('destination').setDescription('Salon destination').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.MoveMembers),
  cooldown: 5,
  async execute(interaction) {
    const src  = interaction.options.getChannel('source');
    const dest = interaction.options.getChannel('destination');
    if (src.type !== ChannelType.GuildVoice || dest.type !== ChannelType.GuildVoice) {
      return interaction.reply({ content: '❌ Les deux salons doivent être vocaux.', ephemeral: true });
    }
    await interaction.deferReply({ ephemeral: true });
    let count = 0;
    for (const [, m] of src.members) {
      await m.voice.setChannel(dest).catch(() => {});
      count++;
    }
    await interaction.editReply({ content: `✅ ${count} membre(s) déplacé(s) vers **${dest.name}**.` });
  },
};

// ─── /lockserver ─────────────────────────────────────────────────────────────
const lockserverCmd = {
  data: new SlashCommandBuilder().setName('lockserver').setDescription('Verrouiller/déverrouiller tous les salons textuels')
    .addBooleanOption(o => o.setName('verrou').setDescription('true = verrouiller, false = déverrouiller').setRequired(true))
    .addStringOption(o => o.setName('raison').setDescription('Raison'))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  cooldown: 10,
  async execute(interaction) {
    const lock   = interaction.options.getBoolean('verrou');
    const reason = interaction.options.getString('raison') || 'Commande /lockserver';
    await interaction.deferReply({ ephemeral: true });
    const texts = interaction.guild.channels.cache.filter(c => c.type === ChannelType.GuildText);
    for (const [, ch] of texts) {
      await ch.permissionOverwrites.edit(interaction.guild.roles.everyone, { SendMessages: lock ? false : null }).catch(() => {});
    }
    await interaction.editReply({ content: `${lock ? '🔒 Serveur verrouillé' : '🔓 Serveur déverrouillé'} (${texts.size} salons).` });
  },
};

// ─── /announce ────────────────────────────────────────────────────────────────
const announceCmd = {
  data: new SlashCommandBuilder().setName('announce').setDescription('Envoyer une annonce dans un salon')
    .addStringOption(o => o.setName('message').setDescription('Contenu de l\'annonce').setRequired(true))
    .addChannelOption(o => o.setName('salon').setDescription('Salon cible (défaut: actuel)'))
    .addBooleanOption(o => o.setName('mention-everyone').setDescription('Mentionner @everyone'))
    .addStringOption(o => o.setName('couleur').setDescription('Couleur hex de l\'embed'))
    .addStringOption(o => o.setName('titre').setDescription('Titre de l\'embed'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  cooldown: 10,
  async execute(interaction) {
    const message  = interaction.options.getString('message');
    const ch       = interaction.options.getChannel('salon') || interaction.channel;
    const everyone = interaction.options.getBoolean('mention-everyone') ?? false;
    const color    = interaction.options.getString('couleur')?.replace('#','') || '5865F2';
    const titre    = interaction.options.getString('titre') || '📢 Annonce';

    const embed = new EmbedBuilder()
      .setTitle(titre)
      .setDescription(message)
      .setColor(parseInt(color, 16))
      .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
      .setTimestamp();

    await ch.send({ content: everyone ? '@everyone' : null, embeds: [embed], allowedMentions: { parse: ['everyone'] } });
    await interaction.reply({ content: `✅ Annonce envoyée dans ${ch}.`, ephemeral: true });
  },
};

// ─── /dm ──────────────────────────────────────────────────────────────────────
const dmCmd = {
  data: new SlashCommandBuilder().setName('dm').setDescription('Envoyer un DM à un membre via le bot')
    .addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true))
    .addStringOption(o => o.setName('message').setDescription('Message').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  cooldown: 10,
  async execute(interaction) {
    const target  = interaction.options.getUser('membre');
    const message = interaction.options.getString('message');
    try {
      await target.send({ embeds: [new EmbedBuilder().setDescription(message).setColor(0x5865f2).setFooter({ text: `Envoyé depuis ${interaction.guild.name}` }).setTimestamp()] });
      await interaction.reply({ content: `✅ DM envoyé à **${target.tag}**.`, ephemeral: true });
    } catch {
      await interaction.reply({ content: `❌ Impossible d'envoyer un DM à **${target.tag}** (DMs bloqués).`, ephemeral: true });
    }
  },
};

// ─── /purge ───────────────────────────────────────────────────────────────────
const purgeCmd = {
  data: new SlashCommandBuilder().setName('purge').setDescription('Supprimer des messages selon un filtre')
    .addSubcommand(s => s.setName('bots').setDescription('Supprimer les messages de bots')
      .addIntegerOption(o => o.setName('nombre').setDescription('Nombre max (1-100)').setRequired(true).setMinValue(1).setMaxValue(100)))
    .addSubcommand(s => s.setName('links').setDescription('Supprimer les messages contenant des liens')
      .addIntegerOption(o => o.setName('nombre').setDescription('Messages à analyser (1-100)').setRequired(true).setMinValue(1).setMaxValue(100)))
    .addSubcommand(s => s.setName('images').setDescription('Supprimer les messages avec des images')
      .addIntegerOption(o => o.setName('nombre').setDescription('Messages à analyser').setRequired(true).setMinValue(1).setMaxValue(100)))
    .addSubcommand(s => s.setName('embeds').setDescription('Supprimer les messages avec des embeds')
      .addIntegerOption(o => o.setName('nombre').setDescription('Messages à analyser').setRequired(true).setMinValue(1).setMaxValue(100)))
    .addSubcommand(s => s.setName('contains').setDescription('Supprimer les messages contenant un texte')
      .addStringOption(o => o.setName('texte').setDescription('Texte à chercher').setRequired(true))
      .addIntegerOption(o => o.setName('nombre').setDescription('Messages à analyser').setRequired(true).setMinValue(1).setMaxValue(100)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  cooldown: 5,
  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const sub    = interaction.options.getSubcommand();
    const count  = interaction.options.getInteger('nombre');
    let messages = await interaction.channel.messages.fetch({ limit: 100 });

    let filtered;
    if (sub === 'bots')     filtered = [...messages.values()].filter(m => m.author.bot).slice(0, count);
    if (sub === 'links')    filtered = [...messages.values()].filter(m => /(https?:\/\/|discord\.gg\/)/i.test(m.content)).slice(0, count);
    if (sub === 'images')   filtered = [...messages.values()].filter(m => m.attachments.some(a => a.contentType?.startsWith('image/'))||m.embeds.some(e=>e.image)).slice(0, count);
    if (sub === 'embeds')   filtered = [...messages.values()].filter(m => m.embeds.length > 0).slice(0, count);
    if (sub === 'contains') {
      const texte = interaction.options.getString('texte').toLowerCase();
      filtered = [...messages.values()].filter(m => m.content.toLowerCase().includes(texte)).slice(0, count);
    }

    const deleted = await interaction.channel.bulkDelete(filtered, true).catch(() => null);
    await interaction.editReply({ content: `🧹 **${deleted?.size || 0}** message(s) supprimé(s) (filtre: ${sub}).` });
  },
};

module.exports = [
  channelCmd, roleCmd, nickCmd, pruneCmd, makeInviteCmd,
  massMuteCmd, massMoveCmd, lockserverCmd, announceCmd, dmCmd, purgeCmd,
];

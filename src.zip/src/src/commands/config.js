/**
 * Commandes de configuration serveur
 * /config, /antinuke, /antiraid, /help, /rank, /leaderboard
 */

const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, setGuildConfig, getLevel, getLeaderboard } = require('../handlers/database');

const configCmd = {
  data: new SlashCommandBuilder().setName('config').setDescription('Configurer le bot pour ce serveur')
    .addSubcommand(s=>s.setName('view').setDescription('Voir la configuration'))
    .addSubcommand(s=>s.setName('logs').setDescription('Salon de logs').addChannelOption(o=>o.setName('salon').setDescription('Salon').setRequired(true)))
    .addSubcommand(s=>s.setName('welcome').setDescription('Bienvenue').addChannelOption(o=>o.setName('salon').setDescription('Salon').setRequired(true)).addStringOption(o=>o.setName('message').setDescription('{user} {server} {memberCount}')))
    .addSubcommand(s=>s.setName('autorole').setDescription('Rôle auto à l\'arrivée').addRoleOption(o=>o.setName('role').setDescription('Rôle').setRequired(true)))
    .addSubcommand(s=>s.setName('modrole').setDescription('Rôle modérateur').addRoleOption(o=>o.setName('role').setDescription('Rôle').setRequired(true)))
    .addSubcommand(s=>s.setName('antispam').setDescription('Anti-spam on/off').addBooleanOption(o=>o.setName('actif').setDescription('Activé ?').setRequired(true)))
    .addSubcommand(s=>s.setName('antilinks').setDescription('Anti-liens on/off').addBooleanOption(o=>o.setName('actif').setDescription('Activé ?').setRequired(true)))
    .addSubcommand(s=>s.setName('badwords').setDescription('Mots interdits (séparés par virgule)').addStringOption(o=>o.setName('mots').setDescription('ex: mot1,mot2').setRequired(true)))
    .addSubcommand(s=>s.setName('starboard').setDescription('Configurer le starboard').addChannelOption(o=>o.setName('salon').setDescription('Salon starboard').setRequired(true)).addIntegerOption(o=>o.setName('seuil').setDescription('Nb ⭐ requis (défaut: 3)').setMinValue(1).setMaxValue(50)))
    .addSubcommand(s=>s.setName('suggestions').setDescription('Salon de suggestions').addChannelOption(o=>o.setName('salon').setDescription('Salon').setRequired(true)))
    .addSubcommand(s=>s.setName('tempvoice').setDescription('Salon vocal "Créer un salon" pour les salons temporaires').addChannelOption(o=>o.setName('salon').setDescription('Salon vocal source').setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  cooldown: 3,
  async execute(interaction) {
    const sub     = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const config  = getGuildConfig(guildId);

    if (sub==='view') {
      const embed = new EmbedBuilder().setTitle(`⚙️ Configuration — ${interaction.guild.name}`).setColor(0x5865f2)
        .setThumbnail(interaction.guild.iconURL())
        .addFields(
          { name:'📋 Logs',           value: config.log_channel?`<#${config.log_channel}>`:'*Non défini*', inline:true },
          { name:'👋 Bienvenue',       value: config.welcome_channel?`<#${config.welcome_channel}>`:'*Non défini*', inline:true },
          { name:'🎭 Auto-rôle',       value: config.auto_role?`<@&${config.auto_role}>`:'*Non défini*', inline:true },
          { name:'🛡️ Rôle mod',        value: config.mod_role?`<@&${config.mod_role}>`:'*Non défini*', inline:true },
          { name:'🚫 Anti-spam',       value: config.antispam_enabled?'✅':'❌', inline:true },
          { name:'🔗 Anti-liens',      value: config.antilinks_enabled?'✅':'❌', inline:true },
          { name:'🛡️ Anti-Nuke',       value: config.antinuke_enabled?`✅ (seuil ${config.antinuke_threshold}/${config.antinuke_window}s)`:'❌', inline:true },
          { name:'🚨 Anti-Raid',       value: config.antiraid_enabled?`✅ (${config.antiraid_joins} joins/${config.antiraid_window}s)`:'❌', inline:true },
          { name:'⭐ Starboard',       value: config.starboard_channel?`<#${config.starboard_channel}> (${config.starboard_threshold}⭐)`:'❌', inline:true },
          { name:'💡 Suggestions',     value: config.suggestion_channel?`<#${config.suggestion_channel}>`:'*Salon actuel*', inline:true },
          { name:'🔊 Temp Voice',      value: config.temp_voice_channel?`<#${config.temp_voice_channel}>`:'❌', inline:true },
          { name:'🤬 Mots interdits',  value: config.bad_words||'*Aucun*' },
        ).setTimestamp();
      return interaction.reply({ embeds:[embed], ephemeral:true });
    }
    if (sub==='logs') { const ch=interaction.options.getChannel('salon'); setGuildConfig(guildId,'log_channel',ch.id); return interaction.reply({ content:`✅ Logs → ${ch}`, ephemeral:true }); }
    if (sub==='welcome') {
      const ch=interaction.options.getChannel('salon'); const msg=interaction.options.getString('message');
      setGuildConfig(guildId,'welcome_channel',ch.id);
      if (msg) setGuildConfig(guildId,'welcome_message',msg);
      return interaction.reply({ content:`✅ Bienvenue configuré dans ${ch}.`, ephemeral:true });
    }
    if (sub==='autorole') { const r=interaction.options.getRole('role'); setGuildConfig(guildId,'auto_role',r.id); return interaction.reply({ content:`✅ Auto-rôle : ${r}`, ephemeral:true }); }
    if (sub==='modrole')  { const r=interaction.options.getRole('role'); setGuildConfig(guildId,'mod_role',r.id); return interaction.reply({ content:`✅ Rôle mod : ${r}`, ephemeral:true }); }
    if (sub==='antispam') { const v=interaction.options.getBoolean('actif')?1:0; setGuildConfig(guildId,'antispam_enabled',v); return interaction.reply({ content:`✅ Anti-spam : ${v?'**activé**':'**désactivé**'}`, ephemeral:true }); }
    if (sub==='antilinks'){ const v=interaction.options.getBoolean('actif')?1:0; setGuildConfig(guildId,'antilinks_enabled',v); return interaction.reply({ content:`✅ Anti-liens : ${v?'**activé**':'**désactivé**'}`, ephemeral:true }); }
    if (sub==='badwords')  { const w=interaction.options.getString('mots'); setGuildConfig(guildId,'bad_words',w); return interaction.reply({ content:'✅ Mots interdits mis à jour.', ephemeral:true }); }
    if (sub==='starboard') {
      const ch=interaction.options.getChannel('salon'); const seuil=interaction.options.getInteger('seuil')??3;
      setGuildConfig(guildId,'starboard_channel',ch.id); setGuildConfig(guildId,'starboard_threshold',seuil);
      return interaction.reply({ content:`✅ Starboard → ${ch} (seuil: ${seuil}⭐)`, ephemeral:true });
    }
    if (sub==='suggestions') { const ch=interaction.options.getChannel('salon'); setGuildConfig(guildId,'suggestion_channel',ch.id); return interaction.reply({ content:`✅ Suggestions → ${ch}`, ephemeral:true }); }
    if (sub==='tempvoice')  { const ch=interaction.options.getChannel('salon'); setGuildConfig(guildId,'temp_voice_channel',ch.id); return interaction.reply({ content:`✅ Salons vocaux temporaires activés. Rejoins <#${ch.id}> pour créer ton salon.`, ephemeral:true }); }
  },
};

const antinukeCmd = {
  data: new SlashCommandBuilder().setName('antinuke').setDescription('Configurer l\'anti-nuke')
    .addBooleanOption(o=>o.setName('actif').setDescription('Activer / désactiver').setRequired(true))
    .addIntegerOption(o=>o.setName('seuil').setDescription('Nb d\'actions avant sanction (défaut: 5)').setMinValue(2).setMaxValue(20))
    .addIntegerOption(o=>o.setName('fenetre').setDescription('Fenêtre de temps en secondes (défaut: 10)').setMinValue(3).setMaxValue(60))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  cooldown: 5,
  async execute(interaction) {
    const enabled=interaction.options.getBoolean('actif')?1:0;
    const threshold=interaction.options.getInteger('seuil')??5;
    const window=interaction.options.getInteger('fenetre')??10;
    setGuildConfig(interaction.guild.id,'antinuke_enabled',enabled);
    setGuildConfig(interaction.guild.id,'antinuke_threshold',threshold);
    setGuildConfig(interaction.guild.id,'antinuke_window',window);
    const embed = new EmbedBuilder().setTitle('🛡️ Anti-Nuke').setColor(enabled?0x57f287:0xed4245)
      .addFields({ name:'Statut',value:enabled?'✅ Activé':'❌ Désactivé',inline:true },{ name:'Seuil',value:`${threshold} actions`,inline:true },{ name:'Fenêtre',value:`${window}s`,inline:true });
    await interaction.reply({ embeds:[embed], ephemeral:true });
  },
};

const antiraidCmd = {
  data: new SlashCommandBuilder().setName('antiraid').setDescription('Configurer l\'anti-raid (protection contre les mass-joins)')
    .addBooleanOption(o=>o.setName('actif').setDescription('Activer / désactiver').setRequired(true))
    .addIntegerOption(o=>o.setName('joins').setDescription('Nb de joins avant lockdown (défaut: 10)').setMinValue(2).setMaxValue(50))
    .addIntegerOption(o=>o.setName('fenetre').setDescription('Fenêtre en secondes (défaut: 10)').setMinValue(3).setMaxValue(60))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  cooldown: 5,
  async execute(interaction) {
    const enabled=interaction.options.getBoolean('actif')?1:0;
    const joins=interaction.options.getInteger('joins')??10;
    const window=interaction.options.getInteger('fenetre')??10;
    setGuildConfig(interaction.guild.id,'antiraid_enabled',enabled);
    setGuildConfig(interaction.guild.id,'antiraid_joins',joins);
    setGuildConfig(interaction.guild.id,'antiraid_window',window);
    const embed = new EmbedBuilder().setTitle('🚨 Anti-Raid').setColor(enabled?0x57f287:0xed4245)
      .addFields({ name:'Statut',value:enabled?'✅ Activé':'❌ Désactivé',inline:true },{ name:'Seuil',value:`${joins} joins`,inline:true },{ name:'Fenêtre',value:`${window}s`,inline:true })
      .setDescription(enabled?'Le serveur sera automatiquement verrouillé lors d\'un raid détecté.':'');
    await interaction.reply({ embeds:[embed], ephemeral:true });
  },
};

const helpCmd = {
  data: new SlashCommandBuilder().setName('help').setDescription('Afficher toutes les commandes disponibles'),
  cooldown: 5,
  async execute(interaction) {
    const embed = new EmbedBuilder().setTitle('📖 Toutes les commandes').setColor(0x5865f2)
      .setThumbnail(interaction.client.user.displayAvatarURL())
      .addFields(
        { name:'🛡️ Modération', value:'`/ban` `/kick` `/mute` `/unmute` `/warn` `/warns` `/clearwarns` `/clear` `/snipe` `/slowmode` `/lockdown` `/unlockdown`' },
        { name:'ℹ️ Informations', value:'`/userinfo` `/serverinfo` `/avatar` `/roleinfo`' },
        { name:'🎫 Tickets', value:'`/ticket-panel` `/ticket-panels` `/ticket-add` `/ticket-remove` `/ticket-close`' },
        { name:'🎭 Reaction Roles', value:'`/reactionrole create` `/reactionrole addrole` `/reactionrole send` `/reactionrole list`' },
        { name:'🏆 Niveaux & Rôles', value:'`/rank` `/leaderboard` `/rolereward add` `/rolereward remove` `/rolereward list`' },
        { name:'🎉 Giveaways', value:'`/giveaway start` `/giveaway end` `/giveaway reroll` `/giveaway list`' },
        { name:'📊 Sondages & Suggestions', value:'`/poll` `/suggest` `/suggestion accept` `/suggestion deny`' },
        { name:'🏷️ Tags', value:'`/tag create` `/tag get` `/tag delete` `/tag list`' },
        { name:'💰 Économie', value:'`/daily` `/balance` `/richlist`' },
        { name:'⏰ Rappels', value:'`/remind` (durée: 10m, 2h, 1d…)' },
        { name:'🎲 Fun', value:'`/8ball` `/coinflip` `/dice`' },
        { name:'⚙️ Configuration', value:'`/config view` `/config logs` `/config welcome` `/config autorole` `/config modrole` `/config antispam` `/config antilinks` `/config badwords` `/config starboard` `/config suggestions` `/config tempvoice` `/antinuke` `/antiraid`' },
      )
      .setFooter({ text:'Bot Discord Pro • Slash commands uniquement' }).setTimestamp();
    await interaction.reply({ embeds:[embed], ephemeral:true });
  },
};

const rankCmd = {
  data: new SlashCommandBuilder().setName('rank').setDescription('Voir ton niveau et XP')
    .addUserOption(o=>o.setName('membre').setDescription('Membre')),
  cooldown: 5,
  async execute(interaction) {
    const target = interaction.options.getUser('membre')||interaction.user;
    const data   = getLevel(interaction.guild.id, target.id);
    const nextXp = Math.pow((data.level+1)/0.1,2);
    const pct    = Math.min(Math.floor((data.xp/nextXp)*100),100);
    const bar    = '█'.repeat(Math.floor(pct/10))+'░'.repeat(10-Math.floor(pct/10));
    const embed  = new EmbedBuilder().setTitle(`📊 Niveau — ${target.username}`)
      .setThumbnail(target.displayAvatarURL())
      .setColor(0x5865f2)
      .addFields(
        { name:'🏆 Niveau', value:`**${data.level}**`, inline:true },
        { name:'⭐ XP', value:`**${data.xp}** / ${Math.floor(nextXp)}`, inline:true },
        { name:'💬 Messages', value:`**${data.messages}**`, inline:true },
        { name:`Progression ${pct}%`, value:`\`[${bar}]\`` },
      ).setTimestamp();
    await interaction.reply({ embeds:[embed] });
  },
};

const leaderboardCmd = {
  data: new SlashCommandBuilder().setName('leaderboard').setDescription('Top 10 membres les plus actifs'),
  cooldown: 10,
  async execute(interaction) {
    await interaction.deferReply();
    const data  = getLeaderboard(interaction.guild.id, 10);
    const lines = await Promise.all(data.map(async (row,i)=>{
      const user = await interaction.client.users.fetch(row.user_id).catch(()=>null);
      const m    = i===0?'🥇':i===1?'🥈':i===2?'🥉':`**${i+1}.**`;
      return `${m} ${user?`**${user.username}**`:`<@${row.user_id}>`} — Niv.**${row.level}** | **${row.xp}** XP`;
    }));
    const embed = new EmbedBuilder().setTitle(`🏆 Leaderboard — ${interaction.guild.name}`).setColor(0xffd700)
      .setDescription(lines.join('\n')||'Aucune donnée.').setThumbnail(interaction.guild.iconURL()).setTimestamp();
    await interaction.editReply({ embeds:[embed] });
  },
};

module.exports = [configCmd, antinukeCmd, antiraidCmd, helpCmd, rankCmd, leaderboardCmd];

/**
 * Commandes de modération complètes
 * /ban /softban /tempban /unban /kick /mute /unmute
 * /warn /warns /clearwarns /note /modlogs
 * /clear /snipe /slowmode /lockdown /unlockdown
 * /nuke /hide /unhide /move /deafen /undeafen
 * /userinfo /serverinfo /avatar /roleinfo /channelinfo
 * /ping /botinfo /uptime
 */

const {
  SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType,
} = require('discord.js');
const {
  addWarn, getWarns, clearWarns, addModLog, getModLogs,
  addNote, getNotes, deleteNote,
  getGuildConfig, createTempban,
} = require('../handlers/database');

const BOT_START = Date.now();

async function sendModLog(client, guild, action, target, moderator, reason, extra) {
  const config = getGuildConfig(guild.id);
  addModLog(guild.id, action, target.id||target, moderator.id, reason, extra);
  if (!config.log_channel) return;
  const ch = guild.channels.cache.get(config.log_channel);
  if (!ch) return;
  const colors = { BAN:0xed4245, SOFTBAN:0xed4245, TEMPBAN:0xffa500, UNBAN:0x57f287, KICK:0xfee75c, MUTE:0xffa500, WARN:0xff7f00, UNMUTE:0x57f287, CLEAR:0x5865f2, LOCKDOWN:0xff0000, UNLOCK:0x57f287, NUKE:0xff0000, HIDE:0x99aab5, UNHIDE:0x57f287, MOVE:0x5865f2, DEAFEN:0xffa500, UNDEAFEN:0x57f287 };
  const icons  = { BAN:'🔨', SOFTBAN:'🔨', TEMPBAN:'⏱️🔨', UNBAN:'✅', KICK:'👢', MUTE:'🔇', WARN:'⚠️', UNMUTE:'🔊', CLEAR:'🧹', LOCKDOWN:'🔒', UNLOCK:'🔓', NUKE:'💣', HIDE:'🙈', UNHIDE:'👁️', MOVE:'📤', DEAFEN:'🔇', UNDEAFEN:'🔊' };
  const embed = new EmbedBuilder()
    .setTitle(`${icons[action]||'🛡️'} ${action}`)
    .addFields(
      { name:'Cible',      value:`${target.tag||target.user?.tag||target} (${target.id||target})`, inline:true },
      { name:'Modérateur', value:`${moderator.tag||moderator} (${moderator.id})`, inline:true },
      { name:'Raison',     value:reason||'Aucune raison' },
    )
    .setColor(colors[action]||0x5865f2).setTimestamp();
  if (extra) embed.addFields({ name:'Détails', value:String(extra) });
  await ch.send({ embeds:[embed] }).catch(()=>{});
}

// ────────────────── BAN ────────────────────────────────────────────────────────
const banCmd = {
  data: new SlashCommandBuilder().setName('ban').setDescription('Bannir un membre définitivement')
    .addUserOption(o=>o.setName('membre').setDescription('Membre').setRequired(true))
    .addStringOption(o=>o.setName('raison').setDescription('Raison'))
    .addIntegerOption(o=>o.setName('jours').setDescription('Supprimer messages (0-7j)').setMinValue(0).setMaxValue(7))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  cooldown: 5,
  async execute(interaction, client) {
    const target = interaction.options.getMember('membre');
    const reason = interaction.options.getString('raison')||'Aucune raison';
    const days   = interaction.options.getInteger('jours')??0;
    if (!target) return interaction.reply({ content:'❌ Membre introuvable.', ephemeral:true });
    if (target.id===interaction.user.id) return interaction.reply({ content:'❌ Tu ne peux pas te bannir.', ephemeral:true });
    if (!target.bannable) return interaction.reply({ content:'❌ Je ne peux pas bannir ce membre.', ephemeral:true });
    await target.ban({ deleteMessageSeconds:days*86400, reason });
    await sendModLog(client, interaction.guild, 'BAN', target.user, interaction.user, reason, `Suppr. ${days}j`);
    await interaction.reply({ embeds:[new EmbedBuilder().setTitle('🔨 Membre banni').addFields({name:'Membre',value:target.user.tag,inline:true},{name:'Raison',value:reason,inline:true}).setColor(0xed4245).setTimestamp()] });
  },
};

// ────────────────── SOFTBAN ─────────────────────────────────────────────────────
const softbanCmd = {
  data: new SlashCommandBuilder().setName('softban').setDescription('Bannir puis débannir immédiatement (purge les messages)')
    .addUserOption(o=>o.setName('membre').setDescription('Membre').setRequired(true))
    .addStringOption(o=>o.setName('raison').setDescription('Raison'))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  cooldown: 5,
  async execute(interaction, client) {
    const target = interaction.options.getMember('membre');
    const reason = interaction.options.getString('raison')||'Softban';
    if (!target||!target.bannable) return interaction.reply({ content:'❌ Impossible de softban ce membre.', ephemeral:true });
    await target.ban({ deleteMessageSeconds:7*86400, reason });
    await interaction.guild.members.unban(target.id, 'Softban — débannissement automatique').catch(()=>{});
    await sendModLog(client, interaction.guild, 'SOFTBAN', target.user, interaction.user, reason);
    await interaction.reply({ embeds:[new EmbedBuilder().setDescription(`🔨 **${target.user.tag}** a été softban (messages supprimés).`).setColor(0xed4245)] });
  },
};

// ────────────────── TEMPBAN ─────────────────────────────────────────────────────
const tempbanCmd = {
  data: new SlashCommandBuilder().setName('tempban').setDescription('Bannir temporairement un membre')
    .addUserOption(o=>o.setName('membre').setDescription('Membre').setRequired(true))
    .addStringOption(o=>o.setName('duree').setDescription('Durée (ex: 1h, 2d, 7d)').setRequired(true))
    .addStringOption(o=>o.setName('raison').setDescription('Raison'))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  cooldown: 5,
  async execute(interaction, client) {
    const target  = interaction.options.getMember('membre');
    const durStr  = interaction.options.getString('duree');
    const reason  = interaction.options.getString('raison')||'Tempban';
    const durSec  = parseDuration(durStr);
    if (!durSec) return interaction.reply({ content:'❌ Format invalide. Ex: `1h`, `2d`, `7d`', ephemeral:true });
    if (!target||!target.bannable) return interaction.reply({ content:'❌ Impossible de bannir ce membre.', ephemeral:true });
    const unbanAt = Math.floor(Date.now()/1000)+durSec;
    await target.ban({ reason:`[Tempban ${durStr}] ${reason}` });
    createTempban(interaction.guild.id, target.id, interaction.user.id, reason, unbanAt);
    await sendModLog(client, interaction.guild, 'TEMPBAN', target.user, interaction.user, reason, `Fin : <t:${unbanAt}:R>`);
    await interaction.reply({ embeds:[new EmbedBuilder().setTitle(`⏱️ Tempban — ${target.user.tag}`).addFields({name:'Durée',value:durStr,inline:true},{name:'Fin',value:`<t:${unbanAt}:R>`,inline:true},{name:'Raison',value:reason}).setColor(0xffa500).setTimestamp()] });
  },
};

// ────────────────── UNBAN ──────────────────────────────────────────────────────
const unbanCmd = {
  data: new SlashCommandBuilder().setName('unban').setDescription('Débannir un utilisateur')
    .addStringOption(o=>o.setName('userid').setDescription('ID Discord de l\'utilisateur').setRequired(true))
    .addStringOption(o=>o.setName('raison').setDescription('Raison'))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  cooldown: 5,
  async execute(interaction, client) {
    const userId  = interaction.options.getString('userid');
    const reason  = interaction.options.getString('raison')||'Déban manuel';
    try {
      await interaction.guild.members.unban(userId, reason);
      addModLog(interaction.guild.id,'UNBAN',userId,interaction.user.id,reason);
      await interaction.reply({ embeds:[new EmbedBuilder().setDescription(`✅ Utilisateur \`${userId}\` débanni.`).setColor(0x57f287)] });
    } catch {
      await interaction.reply({ content:'❌ Utilisateur introuvable dans les bans.', ephemeral:true });
    }
  },
};

// ────────────────── KICK ───────────────────────────────────────────────────────
const kickCmd = {
  data: new SlashCommandBuilder().setName('kick').setDescription('Expulser un membre')
    .addUserOption(o=>o.setName('membre').setDescription('Membre').setRequired(true))
    .addStringOption(o=>o.setName('raison').setDescription('Raison'))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
  cooldown: 5,
  async execute(interaction, client) {
    const target = interaction.options.getMember('membre');
    const reason = interaction.options.getString('raison')||'Aucune raison';
    if (!target||!target.kickable) return interaction.reply({ content:'❌ Impossible d\'expulser ce membre.', ephemeral:true });
    await target.kick(reason);
    await sendModLog(client, interaction.guild, 'KICK', target.user, interaction.user, reason);
    await interaction.reply({ embeds:[new EmbedBuilder().setTitle('👢 Membre expulsé').addFields({name:'Membre',value:target.user.tag,inline:true},{name:'Raison',value:reason,inline:true}).setColor(0xfee75c).setTimestamp()] });
  },
};

// ────────────────── MUTE / UNMUTE ─────────────────────────────────────────────
const muteCmd = {
  data: new SlashCommandBuilder().setName('mute').setDescription('Mettre en timeout un membre')
    .addUserOption(o=>o.setName('membre').setDescription('Membre').setRequired(true))
    .addIntegerOption(o=>o.setName('duree').setDescription('Durée en minutes (max 40320)').setRequired(true).setMinValue(1).setMaxValue(40320))
    .addStringOption(o=>o.setName('raison').setDescription('Raison'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  cooldown: 3,
  async execute(interaction, client) {
    const target   = interaction.options.getMember('membre');
    const duration = interaction.options.getInteger('duree');
    const reason   = interaction.options.getString('raison')||'Aucune raison';
    if (!target||!target.moderatable) return interaction.reply({ content:'❌ Impossible de mute.', ephemeral:true });
    await target.timeout(duration*60*1000, reason);
    await sendModLog(client, interaction.guild, 'MUTE', target.user, interaction.user, reason, `${duration} min`);
    await interaction.reply({ embeds:[new EmbedBuilder().setTitle('🔇 Membre muté').addFields({name:'Membre',value:target.user.tag,inline:true},{name:'Durée',value:`${duration} min`,inline:true},{name:'Raison',value:reason}).setColor(0xffa500).setTimestamp()] });
  },
};

const unmuteCmd = {
  data: new SlashCommandBuilder().setName('unmute').setDescription('Retirer le timeout d\'un membre')
    .addUserOption(o=>o.setName('membre').setDescription('Membre').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  cooldown: 3,
  async execute(interaction, client) {
    const target = interaction.options.getMember('membre');
    if (!target) return interaction.reply({ content:'❌ Membre introuvable.', ephemeral:true });
    await target.timeout(null);
    await sendModLog(client, interaction.guild, 'UNMUTE', target.user, interaction.user, 'Timeout retiré');
    await interaction.reply({ embeds:[new EmbedBuilder().setDescription(`🔊 **${target.user.tag}** n'est plus muté.`).setColor(0x57f287)] });
  },
};

// ────────────────── WARNS ─────────────────────────────────────────────────────
const warnCmd = {
  data: new SlashCommandBuilder().setName('warn').setDescription('Avertir un membre')
    .addUserOption(o=>o.setName('membre').setDescription('Membre').setRequired(true))
    .addStringOption(o=>o.setName('raison').setDescription('Raison').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  cooldown: 3,
  async execute(interaction, client) {
    const target = interaction.options.getMember('membre');
    const reason = interaction.options.getString('raison');
    if (!target) return interaction.reply({ content:'❌ Membre introuvable.', ephemeral:true });
    addWarn(interaction.guild.id, target.id, interaction.user.id, reason);
    const warns = getWarns(interaction.guild.id, target.id);
    await sendModLog(client, interaction.guild, 'WARN', target.user, interaction.user, reason, `Total: ${warns.length}`);
    await interaction.reply({ embeds:[new EmbedBuilder().setTitle('⚠️ Avertissement').addFields({name:'Membre',value:target.user.tag,inline:true},{name:'Warns',value:`${warns.length}`,inline:true},{name:'Raison',value:reason}).setColor(0xff7f00).setTimestamp()] });
  },
};

const warnsCmd = {
  data: new SlashCommandBuilder().setName('warns').setDescription('Voir les avertissements d\'un membre')
    .addUserOption(o=>o.setName('membre').setDescription('Membre').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  cooldown: 3,
  async execute(interaction) {
    const target = interaction.options.getUser('membre');
    const warns  = getWarns(interaction.guild.id, target.id);
    if (!warns.length) return interaction.reply({ content:`✅ **${target.tag}** n'a aucun avertissement.`, ephemeral:true });
    const embed = new EmbedBuilder().setTitle(`⚠️ Warns — ${target.tag}`).setColor(0xff7f00).setThumbnail(target.displayAvatarURL())
      .setDescription(warns.map((w,i)=>`**#${i+1}** — <t:${w.created_at}:f>\n> ${w.reason} *(par <@${w.moderator_id}>)*`).join('\n\n'))
      .setFooter({ text:`${warns.length} warn(s)` });
    await interaction.reply({ embeds:[embed], ephemeral:true });
  },
};

const clearwarnsCmd = {
  data: new SlashCommandBuilder().setName('clearwarns').setDescription('Effacer tous les warns d\'un membre')
    .addUserOption(o=>o.setName('membre').setDescription('Membre').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  cooldown: 5,
  async execute(interaction) {
    const target = interaction.options.getUser('membre');
    clearWarns(interaction.guild.id, target.id);
    await interaction.reply({ embeds:[new EmbedBuilder().setDescription(`🧹 Warns de **${target.tag}** effacés.`).setColor(0x57f287)] });
  },
};

// ────────────────── NOTES MODÉRATEUR ──────────────────────────────────────────
const noteCmd = {
  data: new SlashCommandBuilder().setName('note').setDescription('Notes privées de modération sur un membre')
    .addSubcommand(s=>s.setName('add').setDescription('Ajouter une note')
      .addUserOption(o=>o.setName('membre').setDescription('Membre').setRequired(true))
      .addStringOption(o=>o.setName('contenu').setDescription('Contenu de la note').setRequired(true)))
    .addSubcommand(s=>s.setName('list').setDescription('Voir les notes d\'un membre')
      .addUserOption(o=>o.setName('membre').setDescription('Membre').setRequired(true)))
    .addSubcommand(s=>s.setName('delete').setDescription('Supprimer une note')
      .addIntegerOption(o=>o.setName('id').setDescription('ID de la note').setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  cooldown: 3,
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    if (sub==='add') {
      const target  = interaction.options.getUser('membre');
      const content = interaction.options.getString('contenu');
      const res = addNote(interaction.guild.id, target.id, interaction.user.id, content);
      return interaction.reply({ content:`📝 Note **#${res.lastInsertRowid}** ajoutée pour **${target.tag}**.`, ephemeral:true });
    }
    if (sub==='list') {
      const target = interaction.options.getUser('membre');
      const notes  = getNotes(interaction.guild.id, target.id);
      if (!notes.length) return interaction.reply({ content:`ℹ️ Aucune note pour **${target.tag}**.`, ephemeral:true });
      const embed = new EmbedBuilder().setTitle(`📝 Notes — ${target.tag}`).setColor(0x5865f2).setThumbnail(target.displayAvatarURL())
        .setDescription(notes.map(n=>`**#${n.id}** <t:${n.created_at}:f> *(par <@${n.moderator_id}>)*\n> ${n.content}`).join('\n\n'));
      return interaction.reply({ embeds:[embed], ephemeral:true });
    }
    if (sub==='delete') {
      const id = interaction.options.getInteger('id');
      deleteNote(id);
      return interaction.reply({ content:`🗑️ Note **#${id}** supprimée.`, ephemeral:true });
    }
  },
};

// ────────────────── MOD LOGS ──────────────────────────────────────────────────
const modlogsCmd = {
  data: new SlashCommandBuilder().setName('modlogs').setDescription('Historique de modération d\'un membre')
    .addUserOption(o=>o.setName('membre').setDescription('Membre').setRequired(true))
    .addIntegerOption(o=>o.setName('limite').setDescription('Nombre d\'entrées (défaut: 10)').setMinValue(1).setMaxValue(25))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  cooldown: 5,
  async execute(interaction) {
    const target = interaction.options.getUser('membre');
    const limit  = interaction.options.getInteger('limite')??10;
    const logs   = getModLogs(interaction.guild.id, target.id, limit);
    if (!logs.length) return interaction.reply({ content:`✅ Aucun historique pour **${target.tag}**.`, ephemeral:true });
    const icons  = { BAN:'🔨',SOFTBAN:'🔨',TEMPBAN:'⏱️🔨',UNBAN:'✅',KICK:'👢',MUTE:'🔇',WARN:'⚠️',UNMUTE:'🔊',CLEAR:'🧹',LOCKDOWN:'🔒' };
    const embed  = new EmbedBuilder().setTitle(`📋 Historique mod — ${target.tag}`).setColor(0x5865f2).setThumbnail(target.displayAvatarURL())
      .setDescription(logs.map(l=>`${icons[l.action]||'🛡️'} **${l.action}** — <t:${l.created_at}:f>\n> ${l.reason||'Aucune raison'} *(par <@${l.moderator_id}>)*`).join('\n\n'))
      .setFooter({ text:`${logs.length} entrée(s)` });
    await interaction.reply({ embeds:[embed], ephemeral:true });
  },
};

// ────────────────── CLEAR ─────────────────────────────────────────────────────
const clearCmd = {
  data: new SlashCommandBuilder().setName('clear').setDescription('Supprimer des messages en masse')
    .addIntegerOption(o=>o.setName('nombre').setDescription('Nombre (1-100)').setRequired(true).setMinValue(1).setMaxValue(100))
    .addUserOption(o=>o.setName('membre').setDescription('Filtrer par membre'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  cooldown: 5,
  async execute(interaction) {
    await interaction.deferReply({ ephemeral:true });
    const amount = interaction.options.getInteger('nombre');
    const filter = interaction.options.getUser('membre');
    let messages = await interaction.channel.messages.fetch({ limit:100 });
    if (filter) messages = messages.filter(m=>m.author.id===filter.id);
    const toDelete = [...messages.values()].slice(0,amount);
    const deleted  = await interaction.channel.bulkDelete(toDelete,true).catch(()=>null);
    addModLog(interaction.guild.id,'CLEAR',interaction.channel.id,interaction.user.id,`${deleted?.size||0} messages`,filter?.id||null);
    await interaction.editReply({ content:`🧹 **${deleted?.size||0}** message(s) supprimé(s).` });
  },
};

// ────────────────── SNIPE ─────────────────────────────────────────────────────
const snipeCmd = {
  data: new SlashCommandBuilder().setName('snipe').setDescription('Voir le dernier message supprimé')
    .addUserOption(o=>o.setName('utilisateur').setDescription('Utilisateur').setRequired(true)),
  cooldown: 5,
  async execute(interaction, client) {
    const targetUser  = interaction.options.getUser('utilisateur');
    const channelCache = client.snipeCache.get(interaction.channel.id);
    if (!channelCache||!channelCache.has(targetUser.id)) {
      return interaction.reply({ content:`🔍 Aucun message supprimé récemment pour **${targetUser.tag}** dans ce salon.`, ephemeral:true });
    }
    const snipe = channelCache.get(targetUser.id);
    const embed = new EmbedBuilder()
      .setAuthor({ name:snipe.author.displayName, iconURL:snipe.author.avatarURL })
      .setDescription(snipe.content||'*Aucun texte*')
      .setColor(0x5865f2).setFooter({ text:'Supprimé le' }).setTimestamp(new Date(snipe.deletedAt));
    if (snipe.attachments.length>0) {
      const img = snipe.attachments.find(a=>a.contentType?.startsWith('image/'));
      if (img) embed.setImage(img.url);
    }
    await interaction.reply({ embeds:[embed] });
  },
};

// ────────────────── SLOWMODE ──────────────────────────────────────────────────
const slowmodeCmd = {
  data: new SlashCommandBuilder().setName('slowmode').setDescription('Définir le slowmode d\'un salon')
    .addIntegerOption(o=>o.setName('secondes').setDescription('Délai (0 = désactiver)').setRequired(true).setMinValue(0).setMaxValue(21600))
    .addChannelOption(o=>o.setName('salon').setDescription('Salon (défaut: actuel)'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  cooldown: 3,
  async execute(interaction) {
    const delay = interaction.options.getInteger('secondes');
    const ch    = interaction.options.getChannel('salon')||interaction.channel;
    await ch.setRateLimitPerUser(delay);
    await interaction.reply({ content:delay===0?`⏱️ Slowmode désactivé dans ${ch}.`:`⏱️ Slowmode **${delay}s** activé dans ${ch}.` });
  },
};

// ────────────────── LOCKDOWN / UNLOCKDOWN ─────────────────────────────────────
const lockdownCmd = {
  data: new SlashCommandBuilder().setName('lockdown').setDescription('Verrouiller un salon')
    .addChannelOption(o=>o.setName('salon').setDescription('Salon (défaut: actuel)'))
    .addStringOption(o=>o.setName('raison').setDescription('Raison'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  cooldown: 5,
  async execute(interaction) {
    const ch     = interaction.options.getChannel('salon')||interaction.channel;
    const reason = interaction.options.getString('raison')||'Lockdown';
    await ch.permissionOverwrites.edit(interaction.guild.roles.everyone, { SendMessages:false });
    addModLog(interaction.guild.id,'LOCKDOWN',ch.id,interaction.user.id,reason);
    await interaction.reply({ embeds:[new EmbedBuilder().setDescription(`🔒 **${ch.name}** verrouillé.\n*Raison : ${reason}*`).setColor(0xff0000)] });
  },
};

const unlockdownCmd = {
  data: new SlashCommandBuilder().setName('unlockdown').setDescription('Déverrouiller un salon')
    .addChannelOption(o=>o.setName('salon').setDescription('Salon (défaut: actuel)'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  cooldown: 5,
  async execute(interaction) {
    const ch = interaction.options.getChannel('salon')||interaction.channel;
    await ch.permissionOverwrites.edit(interaction.guild.roles.everyone, { SendMessages:null });
    await interaction.reply({ embeds:[new EmbedBuilder().setDescription(`🔓 **${ch.name}** déverrouillé.`).setColor(0x57f287)] });
  },
};

// ────────────────── NUKE ──────────────────────────────────────────────────────
const nukeCmd = {
  data: new SlashCommandBuilder().setName('nuke').setDescription('Supprimer et recréer un salon (vide total)')
    .addChannelOption(o=>o.setName('salon').setDescription('Salon (défaut: actuel)'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  cooldown: 10,
  async execute(interaction) {
    const ch = interaction.options.getChannel('salon')||interaction.channel;
    await interaction.deferReply({ ephemeral:true });
    try {
      const clone = await ch.clone({ reason:`Nuke par ${interaction.user.tag}` });
      await ch.delete();
      await clone.send({ embeds:[new EmbedBuilder().setDescription('💣 Salon nuké par un administrateur.').setColor(0xff0000).setTimestamp()] });
      addModLog(interaction.guild.id,'NUKE',ch.id,interaction.user.id,'Salon nuké');
      await interaction.editReply({ content:`✅ Salon nuké → ${clone}` });
    } catch(e) {
      await interaction.editReply({ content:`❌ Erreur : ${e.message}` });
    }
  },
};

// ────────────────── HIDE / UNHIDE ─────────────────────────────────────────────
const hideCmd = {
  data: new SlashCommandBuilder().setName('hide').setDescription('Masquer un salon à @everyone')
    .addChannelOption(o=>o.setName('salon').setDescription('Salon (défaut: actuel)'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  cooldown: 3,
  async execute(interaction) {
    const ch = interaction.options.getChannel('salon')||interaction.channel;
    await ch.permissionOverwrites.edit(interaction.guild.roles.everyone, { ViewChannel:false });
    await interaction.reply({ content:`🙈 **${ch.name}** masqué.`, ephemeral:true });
  },
};

const unhideCmd = {
  data: new SlashCommandBuilder().setName('unhide').setDescription('Révéler un salon à @everyone')
    .addChannelOption(o=>o.setName('salon').setDescription('Salon (défaut: actuel)'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  cooldown: 3,
  async execute(interaction) {
    const ch = interaction.options.getChannel('salon')||interaction.channel;
    await ch.permissionOverwrites.edit(interaction.guild.roles.everyone, { ViewChannel:null });
    await interaction.reply({ content:`👁️ **${ch.name}** visible.`, ephemeral:true });
  },
};

// ────────────────── MOVE ──────────────────────────────────────────────────────
const moveCmd = {
  data: new SlashCommandBuilder().setName('move').setDescription('Déplacer un membre vers un salon vocal')
    .addUserOption(o=>o.setName('membre').setDescription('Membre').setRequired(true))
    .addChannelOption(o=>o.setName('salon').setDescription('Salon vocal destination').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.MoveMembers),
  cooldown: 3,
  async execute(interaction) {
    const target = interaction.options.getMember('membre');
    const ch     = interaction.options.getChannel('salon');
    if (!target.voice.channelId) return interaction.reply({ content:'❌ Ce membre n\'est pas dans un salon vocal.', ephemeral:true });
    if (ch.type!==2) return interaction.reply({ content:'❌ Ce salon n\'est pas un salon vocal.', ephemeral:true });
    await target.voice.setChannel(ch);
    await interaction.reply({ content:`📤 **${target.user.tag}** déplacé vers **${ch.name}**.`, ephemeral:true });
  },
};

// ────────────────── DEAFEN / UNDEAFEN ─────────────────────────────────────────
const deafenCmd = {
  data: new SlashCommandBuilder().setName('deafen').setDescription('Couper le son d\'un membre en vocal')
    .addUserOption(o=>o.setName('membre').setDescription('Membre').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.DeafenMembers),
  cooldown: 3,
  async execute(interaction, client) {
    const target = interaction.options.getMember('membre');
    if (!target.voice.channelId) return interaction.reply({ content:'❌ Ce membre n\'est pas en vocal.', ephemeral:true });
    await target.voice.setDeaf(true);
    await sendModLog(client, interaction.guild, 'DEAFEN', target.user, interaction.user, 'Deafen manuel');
    await interaction.reply({ content:`🔇 **${target.user.tag}** sourdine activée.`, ephemeral:true });
  },
};

const undeafenCmd = {
  data: new SlashCommandBuilder().setName('undeafen').setDescription('Rétablir le son d\'un membre en vocal')
    .addUserOption(o=>o.setName('membre').setDescription('Membre').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.DeafenMembers),
  cooldown: 3,
  async execute(interaction, client) {
    const target = interaction.options.getMember('membre');
    if (!target.voice.channelId) return interaction.reply({ content:'❌ Ce membre n\'est pas en vocal.', ephemeral:true });
    await target.voice.setDeaf(false);
    await sendModLog(client, interaction.guild, 'UNDEAFEN', target.user, interaction.user, 'Undeafen');
    await interaction.reply({ content:`🔊 **${target.user.tag}** sourdine retirée.`, ephemeral:true });
  },
};

// ────────────────── INFO ──────────────────────────────────────────────────────
const userinfoCmd = {
  data: new SlashCommandBuilder().setName('userinfo').setDescription('Informations sur un utilisateur')
    .addUserOption(o=>o.setName('membre').setDescription('Membre (défaut: toi)')),
  cooldown: 5,
  async execute(interaction) {
    const target = interaction.options.getMember('membre')||interaction.member;
    const user   = target.user;
    const roles  = target.roles.cache.filter(r=>r.id!==interaction.guild.id).sort((a,b)=>b.position-a.position);
    const warns  = getWarns(interaction.guild.id, user.id);
    const embed  = new EmbedBuilder()
      .setTitle(`👤 ${user.tag}`)
      .setThumbnail(user.displayAvatarURL({ size:256 }))
      .setColor(target.displayHexColor||0x5865f2)
      .addFields(
        { name:'ID',             value:user.id,                                                              inline:true },
        { name:'Surnom',         value:target.displayName||'Aucun',                                         inline:true },
        { name:'Compte créé',    value:`<t:${Math.floor(user.createdTimestamp/1000)}:R>`,                  inline:true },
        { name:'A rejoint',      value:target.joinedAt?`<t:${Math.floor(target.joinedTimestamp/1000)}:R>`:'Inconnu', inline:true },
        { name:'⚠️ Warns',       value:`${warns.length}`,                                                  inline:true },
        { name:'Bot',            value:user.bot?'✅ Oui':'❌ Non',                                         inline:true },
        { name:`Rôles (${roles.size})`, value:roles.size>0?[...roles.values()].slice(0,10).join(' '):'Aucun' },
      )
      .setTimestamp();
    await interaction.reply({ embeds:[embed] });
  },
};

const serverinfoCmd = {
  data: new SlashCommandBuilder().setName('serverinfo').setDescription('Informations sur le serveur'),
  cooldown: 10,
  async execute(interaction) {
    const guild = interaction.guild;
    await guild.fetch();
    const channels   = guild.channels.cache;
    const embed = new EmbedBuilder()
      .setTitle(`🏠 ${guild.name}`).setThumbnail(guild.iconURL({ size:256 })).setColor(0x5865f2)
      .addFields(
        { name:'ID',           value:guild.id,                                                inline:true },
        { name:'Propriétaire', value:`<@${guild.ownerId}>`,                                   inline:true },
        { name:'Créé le',      value:`<t:${Math.floor(guild.createdTimestamp/1000)}:R>`,     inline:true },
        { name:'Membres',      value:`**${guild.memberCount}**`,                              inline:true },
        { name:'Rôles',        value:`**${guild.roles.cache.size}**`,                        inline:true },
        { name:'Boosts',       value:`Niveau **${guild.premiumTier}** (${guild.premiumSubscriptionCount||0})`, inline:true },
        { name:'Salons',       value:`📝 ${channels.filter(c=>c.type===0).size} • 🔊 ${channels.filter(c=>c.type===2).size} • 📁 ${channels.filter(c=>c.type===4).size}` },
        { name:'Vérification', value:guild.verificationLevel.toString(), inline:true },
      )
      .setImage(guild.bannerURL({ size:1024 })||null).setTimestamp();
    await interaction.reply({ embeds:[embed] });
  },
};

const avatarCmd = {
  data: new SlashCommandBuilder().setName('avatar').setDescription('Voir l\'avatar d\'un utilisateur')
    .addUserOption(o=>o.setName('membre').setDescription('Membre (défaut: toi)')),
  cooldown: 3,
  async execute(interaction) {
    const user = interaction.options.getUser('membre')||interaction.user;
    const url  = user.displayAvatarURL({ size:4096, extension:'png' });
    await interaction.reply({ embeds:[new EmbedBuilder().setTitle(`🖼️ Avatar — ${user.tag}`).setImage(url).setColor(0x5865f2).addFields({ name:'Liens', value:`[PNG](${user.displayAvatarURL({size:4096,extension:'png'})}) • [WEBP](${user.displayAvatarURL({size:4096,extension:'webp'})})` })] });
  },
};

const roleinfoCmd = {
  data: new SlashCommandBuilder().setName('roleinfo').setDescription('Informations sur un rôle')
    .addRoleOption(o=>o.setName('role').setDescription('Rôle').setRequired(true)),
  cooldown: 5,
  async execute(interaction) {
    const role    = interaction.options.getRole('role');
    const members = (await interaction.guild.members.fetch()).filter(m=>m.roles.cache.has(role.id));
    await interaction.reply({ embeds:[new EmbedBuilder().setTitle(`🎭 ${role.name}`).setColor(role.color||0x5865f2)
      .addFields(
        { name:'ID',          value:role.id,                                           inline:true },
        { name:'Couleur',     value:role.hexColor,                                     inline:true },
        { name:'Membres',     value:`${members.size}`,                                 inline:true },
        { name:'Mentionnable',value:role.mentionable?'✅ Oui':'❌ Non',               inline:true },
        { name:'Hissé',       value:role.hoist?'✅ Oui':'❌ Non',                     inline:true },
        { name:'Position',    value:`${role.position}`,                                inline:true },
        { name:'Créé le',     value:`<t:${Math.floor(role.createdTimestamp/1000)}:R>`, inline:true },
      ).setTimestamp()] });
  },
};

const channelinfoCmd = {
  data: new SlashCommandBuilder().setName('channelinfo').setDescription('Informations sur un salon')
    .addChannelOption(o=>o.setName('salon').setDescription('Salon (défaut: actuel)')),
  cooldown: 5,
  async execute(interaction) {
    const ch    = interaction.options.getChannel('salon')||interaction.channel;
    const types = { 0:'📝 Textuel',2:'🔊 Vocal',4:'📁 Catégorie',5:'📢 Annonces',13:'🎤 Stage',15:'💬 Forum' };
    const embed = new EmbedBuilder().setTitle(`#${ch.name}`).setColor(0x5865f2)
      .addFields(
        { name:'ID',       value:ch.id,                                                  inline:true },
        { name:'Type',     value:types[ch.type]||`Type ${ch.type}`,                      inline:true },
        { name:'Catégorie',value:ch.parent?.name||'Aucune',                              inline:true },
        { name:'Créé le',  value:`<t:${Math.floor(ch.createdTimestamp/1000)}:R>`,       inline:true },
        { name:'NSFW',     value:ch.nsfw?'✅ Oui':'❌ Non',                              inline:true },
        { name:'Slowmode', value:ch.rateLimitPerUser?`${ch.rateLimitPerUser}s`:'Aucun',  inline:true },
      );
    if (ch.topic) embed.setDescription(`> ${ch.topic}`);
    await interaction.reply({ embeds:[embed] });
  },
};

// ────────────────── PING / BOTINFO / UPTIME ───────────────────────────────────
const pingCmd = {
  data: new SlashCommandBuilder().setName('ping').setDescription('Latence du bot et de l\'API Discord'),
  cooldown: 5,
  async execute(interaction, client) {
    const sent = await interaction.reply({ content:'📡 Calcul...', fetchReply:true });
    const diff = sent.createdTimestamp-interaction.createdTimestamp;
    await interaction.editReply({ embeds:[new EmbedBuilder()
      .setTitle('🏓 Pong !')
      .addFields(
        { name:'⏱️ Latence message', value:`\`${diff}ms\``,             inline:true },
        { name:'💓 API WebSocket',   value:`\`${client.ws.ping}ms\``,   inline:true },
      ).setColor(diff<150?0x57f287:diff<300?0xfee75c:0xed4245).setTimestamp()], content:'' });
  },
};

const botinfoCmd = {
  data: new SlashCommandBuilder().setName('botinfo').setDescription('Informations sur le bot'),
  cooldown: 10,
  async execute(interaction, client) {
    const uptime  = formatUptime(Date.now()-BOT_START);
    const mem     = (process.memoryUsage().rss/1024/1024).toFixed(1);
    const embed   = new EmbedBuilder()
      .setTitle(`🤖 ${client.user.tag}`)
      .setThumbnail(client.user.displayAvatarURL({ size:256 }))
      .setColor(0x5865f2)
      .addFields(
        { name:'📌 Version discord.js', value:'v14',                              inline:true },
        { name:'🟢 Node.js',            value:process.version,                    inline:true },
        { name:'⏱️ Uptime',             value:uptime,                             inline:true },
        { name:'🌐 Serveurs',           value:`${client.guilds.cache.size}`,      inline:true },
        { name:'👥 Utilisateurs',       value:`${client.users.cache.size}`,       inline:true },
        { name:'💾 Mémoire (RSS)',      value:`${mem} MB`,                        inline:true },
        { name:'🤖 Commandes',          value:`${client.commands.size}`,          inline:true },
        { name:'📡 Ping WebSocket',     value:`${client.ws.ping}ms`,              inline:true },
      ).setTimestamp();
    await interaction.reply({ embeds:[embed] });
  },
};

const uptimeCmd = {
  data: new SlashCommandBuilder().setName('uptime').setDescription('Temps de fonctionnement du bot'),
  cooldown: 5,
  async execute(interaction) {
    await interaction.reply({ embeds:[new EmbedBuilder().setDescription(`⏱️ Le bot tourne depuis **${formatUptime(Date.now()-BOT_START)}**.`).setColor(0x57f287)] });
  },
};

// ─── Helpers ──────────────────────────────────────────────────────────────────
function parseDuration(str) {
  const match = str.match(/^(\d+)(s|m|h|d|w)$/i);
  if (!match) return null;
  const n = parseInt(match[1]);
  const mult = { s:1, m:60, h:3600, d:86400, w:604800 };
  return n*(mult[match[2].toLowerCase()]||0);
}

function formatUptime(ms) {
  const s = Math.floor(ms/1000);
  const d = Math.floor(s/86400), h = Math.floor((s%86400)/3600), m = Math.floor((s%3600)/60), sec = s%60;
  return [d&&`${d}j`,h&&`${h}h`,m&&`${m}m`,`${sec}s`].filter(Boolean).join(' ');
}

module.exports = [
  banCmd, softbanCmd, tempbanCmd, unbanCmd,
  kickCmd, muteCmd, unmuteCmd,
  warnCmd, warnsCmd, clearwarnsCmd,
  noteCmd, modlogsCmd,
  clearCmd, snipeCmd, slowmodeCmd,
  lockdownCmd, unlockdownCmd, nukeCmd,
  hideCmd, unhideCmd, moveCmd,
  deafenCmd, undeafenCmd,
  userinfoCmd, serverinfoCmd, avatarCmd, roleinfoCmd, channelinfoCmd,
  pingCmd, botinfoCmd, uptimeCmd,
];

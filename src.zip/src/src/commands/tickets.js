/**
 * Système de tickets complet avec menu déroulant + transcripts HTML
 * /ticket-panel  /ticket-setup  /ticket-add  /ticket-remove
 * /ticket-close  /ticket-rename /ticket-panels /ticket-claim /ticket-unclaim
 */

const {
  SlashCommandBuilder, EmbedBuilder, ActionRowBuilder,
  ButtonBuilder, ButtonStyle, StringSelectMenuBuilder,
  PermissionFlagsBits, ChannelType,
} = require('discord.js');
const {
  upsertTicketPanel, getAllPanels, getTicketByChannel,
  closeTicket, addModLog, getGuildConfig,
} = require('../handlers/database');

// ─────────────────────────────────────────────────────────────────────────────
// /ticket-panel — panel simple (bouton)
// ─────────────────────────────────────────────────────────────────────────────
const ticketPanelCmd = {
  data: new SlashCommandBuilder()
    .setName('ticket-panel')
    .setDescription('Créer un panel ticket avec un bouton')
    .addStringOption(o => o.setName('nom').setDescription('Nom du panel').setRequired(true))
    .addStringOption(o => o.setName('message').setDescription('Message affiché'))
    .addChannelOption(o => o.setName('categorie').setDescription('Catégorie où créer les tickets'))
    .addStringOption(o => o.setName('couleur').setDescription('Couleur hex (ex: FF5733)'))
    .addStringOption(o => o.setName('emoji').setDescription('Emoji du bouton (ex: 🎫)'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  cooldown: 5,
  async execute(interaction) {
    const panelName = interaction.options.getString('nom');
    const message   = interaction.options.getString('message') || 'Cliquez sur le bouton pour ouvrir un ticket.';
    const category  = interaction.options.getChannel('categorie');
    const color     = interaction.options.getString('couleur')?.replace('#','') || '5865F2';
    const emoji     = interaction.options.getString('emoji') || '📩';

    upsertTicketPanel(interaction.guild.id, panelName, category?.id||null, message, color);

    const embed = new EmbedBuilder()
      .setTitle(`🎫 ${panelName}`)
      .setDescription(message)
      .setColor(parseInt(color, 16))
      .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`open_ticket:${panelName}`)
        .setLabel('Ouvrir un ticket')
        .setEmoji(emoji)
        .setStyle(ButtonStyle.Primary)
    );

    await interaction.reply({ content: '✅ Panel créé.', ephemeral: true });
    await interaction.channel.send({ embeds: [embed], components: [row] });
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// /ticket-setup — panel avancé avec menu déroulant (plusieurs catégories)
// ─────────────────────────────────────────────────────────────────────────────
const ticketSetupCmd = {
  data: new SlashCommandBuilder()
    .setName('ticket-setup')
    .setDescription('Créer un panel ticket avancé avec menu déroulant multi-catégories')
    .addStringOption(o => o.setName('titre').setDescription('Titre du panel').setRequired(true))
    .addStringOption(o => o.setName('description').setDescription('Description'))
    .addStringOption(o => o.setName('categories').setDescription('Catégories: Support:🛠️,Commande:🛒,Partenariat:🤝').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  cooldown: 5,
  async execute(interaction) {
    const titre  = interaction.options.getString('titre');
    const desc   = interaction.options.getString('description') || 'Sélectionne le type de ticket ci-dessous.';
    const catRaw = interaction.options.getString('categories');

    // Parsing: "Support:🛠️,Commande:🛒"
    const cats = catRaw.split(',').map(s => {
      const [label, emoji] = s.trim().split(':');
      return { label: label?.trim(), emoji: emoji?.trim() || '🎫', value: label?.trim().toLowerCase().replace(/\s+/g,'_') };
    }).filter(c => c.label);

    if (cats.length < 1 || cats.length > 25) {
      return interaction.reply({ content: '❌ Entre 1 et 25 catégories, séparées par des virgules.', ephemeral: true });
    }

    // Enregistrer chaque catégorie comme panel
    for (const cat of cats) {
      upsertTicketPanel(interaction.guild.id, cat.label, null, `Ticket de type **${cat.label}**.`, '5865F2');
    }

    const embed = new EmbedBuilder()
      .setTitle(`🎫 ${titre}`)
      .setDescription(desc)
      .setColor(0x5865f2)
      .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
      .setTimestamp();

    const menu = new ActionRowBuilder().addComponents(
      new StringSelectMenuBuilder()
        .setCustomId('ticket_select')
        .setPlaceholder('📩 Choisis une catégorie...')
        .addOptions(cats.map(c => ({
          label: c.label,
          value: c.value,
          emoji: c.emoji,
        })))
    );

    await interaction.reply({ content: '✅ Panel multi-catégories envoyé.', ephemeral: true });
    await interaction.channel.send({ embeds: [embed], components: [menu] });
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// /ticket-add
// ─────────────────────────────────────────────────────────────────────────────
const ticketAddCmd = {
  data: new SlashCommandBuilder()
    .setName('ticket-add')
    .setDescription('Ajouter un membre au ticket actuel')
    .addUserOption(o => o.setName('membre').setDescription('Membre à ajouter').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  cooldown: 3,
  async execute(interaction) {
    const ticket = getTicketByChannel(interaction.channel.id);
    if (!ticket) return interaction.reply({ content: '❌ Ce salon n\'est pas un ticket.', ephemeral: true });
    const member = interaction.options.getMember('membre');
    if (!member) return interaction.reply({ content: '❌ Membre introuvable.', ephemeral: true });
    await interaction.channel.permissionOverwrites.edit(member.id, {
      ViewChannel: true, SendMessages: true, ReadMessageHistory: true,
    });
    await interaction.reply({ embeds: [new EmbedBuilder().setDescription(`✅ ${member} ajouté au ticket.`).setColor(0x57f287)] });
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// /ticket-remove
// ─────────────────────────────────────────────────────────────────────────────
const ticketRemoveCmd = {
  data: new SlashCommandBuilder()
    .setName('ticket-remove')
    .setDescription('Retirer un membre du ticket actuel')
    .addUserOption(o => o.setName('membre').setDescription('Membre à retirer').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  cooldown: 3,
  async execute(interaction) {
    const ticket = getTicketByChannel(interaction.channel.id);
    if (!ticket) return interaction.reply({ content: '❌ Ce salon n\'est pas un ticket.', ephemeral: true });
    const member = interaction.options.getMember('membre');
    if (!member) return interaction.reply({ content: '❌ Membre introuvable.', ephemeral: true });
    if (member.id === ticket.user_id) return interaction.reply({ content: '❌ Impossible de retirer le créateur du ticket.', ephemeral: true });
    await interaction.channel.permissionOverwrites.delete(member.id).catch(() => {});
    await interaction.reply({ embeds: [new EmbedBuilder().setDescription(`✅ ${member} retiré du ticket.`).setColor(0xed4245)] });
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// /ticket-close
// ─────────────────────────────────────────────────────────────────────────────
const ticketCloseCmd = {
  data: new SlashCommandBuilder()
    .setName('ticket-close')
    .setDescription('Fermer le ticket actuel (génère un transcript)')
    .addStringOption(o => o.setName('raison').setDescription('Raison de fermeture'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  cooldown: 3,
  async execute(interaction) {
    const ticket = getTicketByChannel(interaction.channel.id);
    if (!ticket) return interaction.reply({ content: '❌ Ce salon n\'est pas un ticket.', ephemeral: true });
    if (ticket.status === 'closed') return interaction.reply({ content: '❌ Ticket déjà fermé.', ephemeral: true });
    const reason = interaction.options.getString('raison') || 'Fermeture manuelle';
    closeTicket(interaction.channel.id);
    addModLog(interaction.guild.id, 'TICKET_CLOSE', ticket.user_id, interaction.user.id, reason);

    // Transcript HTML
    await sendTranscript(interaction, ticket);

    await interaction.channel.permissionOverwrites.edit(ticket.user_id, { SendMessages: false }).catch(() => {});

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('delete_ticket').setLabel('🗑️ Supprimer').setStyle(ButtonStyle.Danger)
    );
    await interaction.reply({
      embeds: [new EmbedBuilder()
        .setTitle('🔒 Ticket fermé')
        .addFields({ name: 'Fermé par', value: `${interaction.user}`, inline: true }, { name: 'Raison', value: reason, inline: true })
        .setColor(0xed4245).setTimestamp()],
      components: [row],
    });
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// /ticket-rename
// ─────────────────────────────────────────────────────────────────────────────
const ticketRenameCmd = {
  data: new SlashCommandBuilder()
    .setName('ticket-rename')
    .setDescription('Renommer le salon du ticket actuel')
    .addStringOption(o => o.setName('nom').setDescription('Nouveau nom').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  cooldown: 5,
  async execute(interaction) {
    const ticket = getTicketByChannel(interaction.channel.id);
    if (!ticket) return interaction.reply({ content: '❌ Ce salon n\'est pas un ticket.', ephemeral: true });
    const name = interaction.options.getString('nom').toLowerCase().replace(/\s+/g, '-').slice(0, 100);
    await interaction.channel.setName(name);
    await interaction.reply({ content: `✅ Ticket renommé en **${name}**.`, ephemeral: true });
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// /ticket-claim
// ─────────────────────────────────────────────────────────────────────────────
const ticketClaimCmd = {
  data: new SlashCommandBuilder()
    .setName('ticket-claim')
    .setDescription('Prendre en charge ce ticket (affiche votre nom dans le sujet)')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  cooldown: 3,
  async execute(interaction) {
    const ticket = getTicketByChannel(interaction.channel.id);
    if (!ticket) return interaction.reply({ content: '❌ Ce salon n\'est pas un ticket.', ephemeral: true });
    await interaction.channel.setTopic(`✋ Pris en charge par ${interaction.user.tag}`).catch(() => {});
    await interaction.reply({ embeds: [new EmbedBuilder().setDescription(`✅ **${interaction.user.tag}** a pris en charge ce ticket.`).setColor(0x57f287)] });
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// /ticket-unclaim
// ─────────────────────────────────────────────────────────────────────────────
const ticketUnclaimCmd = {
  data: new SlashCommandBuilder()
    .setName('ticket-unclaim')
    .setDescription('Libérer la prise en charge du ticket')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  cooldown: 3,
  async execute(interaction) {
    const ticket = getTicketByChannel(interaction.channel.id);
    if (!ticket) return interaction.reply({ content: '❌ Ce salon n\'est pas un ticket.', ephemeral: true });
    await interaction.channel.setTopic('').catch(() => {});
    await interaction.reply({ embeds: [new EmbedBuilder().setDescription('✅ Ticket libéré.').setColor(0xfee75c)] });
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// /ticket-panels
// ─────────────────────────────────────────────────────────────────────────────
const ticketPanelsCmd = {
  data: new SlashCommandBuilder()
    .setName('ticket-panels')
    .setDescription('Lister tous les panels de tickets')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  cooldown: 5,
  async execute(interaction) {
    const panels = getAllPanels(interaction.guild.id);
    if (!panels.length) return interaction.reply({ content: '❌ Aucun panel configuré.', ephemeral: true });
    const embed = new EmbedBuilder().setTitle('🎫 Panels de tickets').setColor(0x5865f2)
      .setDescription(panels.map(p =>
        `**${p.panel_name}** — Catégorie : ${p.category_id ? `<#${p.category_id}>` : '*Aucune*'} — Couleur: #${p.embed_color}`
      ).join('\n'));
    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// Utilitaire : transcript HTML
// ─────────────────────────────────────────────────────────────────────────────
async function sendTranscript(interaction, ticket) {
  try {
    const { createTranscript } = require('discord-html-transcripts');
    const attachment = await createTranscript(interaction.channel, {
      limit: -1,
      filename: `transcript-${interaction.channel.name}-${Date.now()}.html`,
      saveImages: false,
      footerText: `Exporté le {date}`,
    });

    // Envoyer le transcript à l'utilisateur via DM
    try {
      const user = await interaction.client.users.fetch(ticket.user_id);
      await user.send({ content: `📄 Transcript du ticket **${interaction.channel.name}**`, files: [attachment] });
    } catch {}

    // Envoyer dans le canal de logs si configuré
    const config = getGuildConfig(interaction.guild.id);
    if (config.log_channel) {
      const logCh = interaction.guild.channels.cache.get(config.log_channel);
      if (logCh) {
        await logCh.send({
          content: `📄 Transcript ticket fermé par ${interaction.user}`,
          files: [attachment],
        }).catch(() => {});
      }
    }
  } catch (err) {
    // Fallback : transcript texte simple
    try {
      const path = require('path');
      const fs   = require('fs');
      const messages = await interaction.channel.messages.fetch({ limit: 100 });
      const lines = [...messages.values()].reverse().map(m =>
        `[${new Date(m.createdTimestamp).toISOString()}] ${m.author.tag}: ${m.content || '<média>'}`
      );
      const dir = path.join(__dirname, '../../data/transcripts');
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      const filePath = path.join(dir, `${interaction.channel.name}-${Date.now()}.txt`);
      fs.writeFileSync(filePath, lines.join('\n'));
    } catch {}
  }
}

module.exports = {
  commands: [
    ticketPanelCmd, ticketSetupCmd,
    ticketAddCmd, ticketRemoveCmd, ticketCloseCmd,
    ticketRenameCmd, ticketClaimCmd, ticketUnclaimCmd,
    ticketPanelsCmd,
  ],
  sendTranscript,
};

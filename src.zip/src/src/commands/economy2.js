/**
 * Économie avancée
 * /rob /mine /fish /hunt /crime /beg /highlow /blackjack
 * /lottery /eco-admin /hourly /weekly /streak /leaderboard-work
 */

const {
  SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder,
  PermissionFlagsBits,
} = require('discord.js');
const {
  getEconomy, addCoins, deductCoins, getEcoLeaderboard,
} = require('../handlers/database');

const { DatabaseSync } = require('node:sqlite');
const path = require('path');

function getDb() {
  const db = new DatabaseSync(path.join(__dirname, '../../data/bot.db'));
  return db;
}

// ─── Cooldown helper ─────────────────────────────────────────────────────────
const cooldowns = new Map(); // key: `${userId}:${action}` -> timestamp
function checkCooldown(userId, action, seconds) {
  const key  = `${userId}:${action}`;
  const now  = Date.now();
  const last = cooldowns.get(key) || 0;
  if (now - last < seconds * 1000) return Math.ceil((last + seconds * 1000 - now) / 1000);
  cooldowns.set(key, now);
  return 0;
}

// ─── /rob ─────────────────────────────────────────────────────────────────────
const robCmd = {
  data: new SlashCommandBuilder().setName('rob').setDescription('Tenter de voler des 🪙 à un membre (risqué !)')
    .addUserOption(o => o.setName('cible').setDescription('Victime').setRequired(true)),
  cooldown: 3,
  async execute(interaction) {
    const wait = checkCooldown(interaction.user.id, 'rob', 3600);
    if (wait) return interaction.reply({ content: `⏳ Tu dois attendre encore **${formatTime(wait)}** avant de voler à nouveau.`, ephemeral: true });

    const target = interaction.options.getUser('cible');
    if (target.id === interaction.user.id) return interaction.reply({ content: '❌ Tu ne peux pas te voler toi-même.', ephemeral: true });
    if (target.bot) return interaction.reply({ content: '❌ Tu ne peux pas voler un bot.', ephemeral: true });

    const targetEco = getEconomy(interaction.guild.id, target.id);
    if (targetEco.balance < 50) return interaction.reply({ content: `❌ **${target.username}** n'a pas assez de 🪙 (minimum 50 🪙 requis).`, ephemeral: true });

    const myEco   = getEconomy(interaction.guild.id, interaction.user.id);
    const success = Math.random() < 0.45; // 45% de chance de réussite

    if (success) {
      const stolen = Math.floor(targetEco.balance * (0.05 + Math.random() * 0.2)); // 5-25%
      deductCoins(interaction.guild.id, target.id, stolen);
      addCoins(interaction.guild.id, interaction.user.id, stolen);
      await interaction.reply({ embeds: [new EmbedBuilder().setTitle('💰 Vol réussi !')
        .setDescription(`Tu as volé **${stolen} 🪙** à **${target.username}** !`)
        .setColor(0xffd700).setTimestamp()] });
    } else {
      const fine = Math.floor(Math.min(myEco.balance, 100 + Math.random() * 200));
      deductCoins(interaction.guild.id, interaction.user.id, fine);
      await interaction.reply({ embeds: [new EmbedBuilder().setTitle('🚨 Vol raté !')
        .setDescription(`Tu t'es fait attraper ! Tu as payé une amende de **${fine} 🪙**.`)
        .setColor(0xed4245).setTimestamp()] });
    }
  },
};

// ─── /mine ────────────────────────────────────────────────────────────────────
const mineCmd = {
  data: new SlashCommandBuilder().setName('mine').setDescription('Creuser des mines pour trouver des 🪙 (cooldown 2h)'),
  cooldown: 3,
  async execute(interaction) {
    const wait = checkCooldown(interaction.user.id, 'mine', 7200);
    if (wait) return interaction.reply({ content: `⏳ Tu dois te reposer encore **${formatTime(wait)}** avant de reminer.`, ephemeral: true });

    const MINE_OUTCOMES = [
      { item: '💎 Diamant',    gain: 500, chance: 0.05 },
      { item: '🥇 Or',         gain: 200, chance: 0.15 },
      { item: '🪙 Argent',     gain: 100, chance: 0.25 },
      { item: '🪨 Pierre',     gain: 30,  chance: 0.35 },
      { item: '💀 Rien',       gain: 0,   chance: 0.20 },
    ];
    const rand    = Math.random();
    let cumul     = 0;
    let outcome   = MINE_OUTCOMES[MINE_OUTCOMES.length - 1];
    for (const o of MINE_OUTCOMES) { cumul += o.chance; if (rand < cumul) { outcome = o; break; } }

    if (outcome.gain > 0) addCoins(interaction.guild.id, interaction.user.id, outcome.gain);
    const eco = getEconomy(interaction.guild.id, interaction.user.id);
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('⛏️ Mine')
      .setDescription(`Tu as trouvé **${outcome.item}**${outcome.gain > 0 ? ` ! +**${outcome.gain} 🪙**` : '...'}`)
      .addFields({ name: 'Solde', value: `**${eco.balance} 🪙**`, inline: true })
      .setColor(outcome.gain >= 200 ? 0xffd700 : outcome.gain > 0 ? 0x57f287 : 0x99aab5).setTimestamp()] });
  },
};

// ─── /fish ────────────────────────────────────────────────────────────────────
const fishCmd = {
  data: new SlashCommandBuilder().setName('fish').setDescription('Aller à la pêche ! (cooldown 1h30)'),
  cooldown: 3,
  async execute(interaction) {
    const wait = checkCooldown(interaction.user.id, 'fish', 5400);
    if (wait) return interaction.reply({ content: `⏳ Tu dois attendre **${formatTime(wait)}** avant de repêcher.`, ephemeral: true });

    const FISH_OUTCOMES = [
      { item: '🐙 Poulpe légendaire', gain: 400, chance: 0.03 },
      { item: '🦈 Requin',            gain: 250, chance: 0.08 },
      { item: '🐟 Gros poisson',      gain: 120, chance: 0.20 },
      { item: '🐠 Petit poisson',     gain: 50,  chance: 0.35 },
      { item: '👟 Vieille chaussure', gain: 5,   chance: 0.20 },
      { item: '🚫 Rien',             gain: 0,   chance: 0.14 },
    ];
    const rand    = Math.random();
    let cumul     = 0;
    let outcome   = FISH_OUTCOMES[FISH_OUTCOMES.length - 1];
    for (const o of FISH_OUTCOMES) { cumul += o.chance; if (rand < cumul) { outcome = o; break; } }

    if (outcome.gain > 0) addCoins(interaction.guild.id, interaction.user.id, outcome.gain);
    const eco = getEconomy(interaction.guild.id, interaction.user.id);
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('🎣 Pêche')
      .setDescription(`Tu as pêché **${outcome.item}**${outcome.gain > 0 ? ` ! +**${outcome.gain} 🪙**` : '...'}`)
      .addFields({ name: 'Solde', value: `**${eco.balance} 🪙**`, inline: true })
      .setColor(outcome.gain >= 200 ? 0xffd700 : outcome.gain > 0 ? 0x57f287 : 0x99aab5).setTimestamp()] });
  },
};

// ─── /hunt ────────────────────────────────────────────────────────────────────
const huntCmd = {
  data: new SlashCommandBuilder().setName('hunt').setDescription('Chasser dans la forêt ! (cooldown 2h)'),
  cooldown: 3,
  async execute(interaction) {
    const wait = checkCooldown(interaction.user.id, 'hunt', 7200);
    if (wait) return interaction.reply({ content: `⏳ Repose-toi encore **${formatTime(wait)}** avant de repartir chasser.`, ephemeral: true });

    const HUNT_OUTCOMES = [
      { item: '🦁 Lion sauvage',  gain: 600, chance: 0.02 },
      { item: '🐗 Sanglier',      gain: 200, chance: 0.10 },
      { item: '🦌 Cerf',          gain: 150, chance: 0.20 },
      { item: '🐇 Lapin',         gain: 60,  chance: 0.40 },
      { item: '🍂 Rien',          gain: 0,   chance: 0.28 },
    ];
    const rand    = Math.random();
    let cumul     = 0;
    let outcome   = HUNT_OUTCOMES[HUNT_OUTCOMES.length - 1];
    for (const o of HUNT_OUTCOMES) { cumul += o.chance; if (rand < cumul) { outcome = o; break; } }

    if (outcome.gain > 0) addCoins(interaction.guild.id, interaction.user.id, outcome.gain);
    const eco = getEconomy(interaction.guild.id, interaction.user.id);
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('🏹 Chasse')
      .setDescription(`Tu as chassé **${outcome.item}**${outcome.gain > 0 ? ` ! +**${outcome.gain} 🪙**` : '...'}`)
      .addFields({ name: 'Solde', value: `**${eco.balance} 🪙**`, inline: true })
      .setColor(outcome.gain >= 200 ? 0xffd700 : outcome.gain > 0 ? 0x57f287 : 0x99aab5).setTimestamp()] });
  },
};

// ─── /crime ───────────────────────────────────────────────────────────────────
const crimeCmd = {
  data: new SlashCommandBuilder().setName('crime').setDescription('Commettre un crime (risque élevé, gain élevé) (cooldown 6h)'),
  cooldown: 3,
  async execute(interaction) {
    const wait = checkCooldown(interaction.user.id, 'crime', 21600);
    if (wait) return interaction.reply({ content: `⏳ Tu dois attendre encore **${formatTime(wait)}** avant de récidiver.`, ephemeral: true });

    const CRIMES = [
      { action: 'braqué une banque',       gain: 1500, risk: 0.40 },
      { action: 'hacké un serveur',         gain: 800,  risk: 0.35 },
      { action: 'pickpocketé un touriste',  gain: 300,  risk: 0.25 },
      { action: 'arnaqué un marchand',      gain: 500,  risk: 0.30 },
    ];
    const crime   = CRIMES[Math.floor(Math.random() * CRIMES.length)];
    const caught  = Math.random() < crime.risk;
    const eco     = getEconomy(interaction.guild.id, interaction.user.id);

    if (!caught) {
      addCoins(interaction.guild.id, interaction.user.id, crime.gain);
      await interaction.reply({ embeds: [new EmbedBuilder().setTitle('🦹 Crime réussi !')
        .setDescription(`Tu as **${crime.action}** et gagné **${crime.gain} 🪙** !`)
        .setColor(0x57f287).setTimestamp()] });
    } else {
      const fine = Math.floor(Math.min(eco.balance, crime.gain * 0.8));
      deductCoins(interaction.guild.id, interaction.user.id, fine);
      await interaction.reply({ embeds: [new EmbedBuilder().setTitle('🚔 Tu t\'es fait attraper !')
        .setDescription(`Tu as tenté de **${crime.action}** mais la police t'a chopé ! Amende : **${fine} 🪙**.`)
        .setColor(0xed4245).setTimestamp()] });
    }
  },
};

// ─── /beg ─────────────────────────────────────────────────────────────────────
const begCmd = {
  data: new SlashCommandBuilder().setName('beg').setDescription('Mendier des 🪙 (peu efficace, cooldown 30min)'),
  cooldown: 3,
  async execute(interaction) {
    const wait = checkCooldown(interaction.user.id, 'beg', 1800);
    if (wait) return interaction.reply({ content: `⏳ Attends encore **${formatTime(wait)}** avant de remendier.`, ephemeral: true });

    const success = Math.random() < 0.7;
    const BEGS = [
      'Un passant inconnu te donne',
      'Un chien te donne',
      'Un riche entrepreneur te donne',
      'Un enfant te donne',
      'Une vieille dame te donne',
    ];
    if (success) {
      const amount = Math.floor(Math.random() * 50) + 1;
      addCoins(interaction.guild.id, interaction.user.id, amount);
      const who = BEGS[Math.floor(Math.random() * BEGS.length)];
      await interaction.reply({ embeds: [new EmbedBuilder().setDescription(`🙏 ${who} **${amount} 🪙** par pitié.`).setColor(0xffd700)] });
    } else {
      await interaction.reply({ embeds: [new EmbedBuilder().setDescription('😔 Personne ne t\'a donné quoi que ce soit...').setColor(0x99aab5)] });
    }
  },
};

// ─── /highlow ─────────────────────────────────────────────────────────────────
const highlowCmd = {
  data: new SlashCommandBuilder().setName('highlow').setDescription('Devines si le prochain nombre est plus haut ou plus bas')
    .addIntegerOption(o => o.setName('mise').setDescription('Mise en 🪙').setRequired(true).setMinValue(10)),
  cooldown: 5,
  async execute(interaction) {
    const mise   = interaction.options.getInteger('mise');
    const eco    = getEconomy(interaction.guild.id, interaction.user.id);
    if (eco.balance < mise) return interaction.reply({ content: `❌ Solde insuffisant (**${eco.balance} 🪙**).`, ephemeral: true });

    const first   = Math.floor(Math.random() * 100) + 1;
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`hl_high:${mise}:${first}:${interaction.user.id}`).setLabel('⬆️ Plus haut').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId(`hl_low:${mise}:${first}:${interaction.user.id}`).setLabel('⬇️ Plus bas').setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId(`hl_same:${mise}:${first}:${interaction.user.id}`).setLabel('↔️ Égal').setStyle(ButtonStyle.Secondary),
    );
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('🎮 High or Low ?')
      .setDescription(`Le nombre actuel est **${first}**.\nLe prochain sera-t-il plus haut, plus bas ou égal ?\nMise : **${mise} 🪙**`)
      .setColor(0x5865f2)], components: [row] });
  },
};

// ─── /blackjack ───────────────────────────────────────────────────────────────
const CARDS      = ['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
const CARD_SUITS = ['♠️','♥️','♦️','♣️'];
const CARD_EMOJIS = { A:'🇦', '2':'2️⃣', '3':'3️⃣', '4':'4️⃣', '5':'5️⃣', '6':'6️⃣', '7':'7️⃣', '8':'8️⃣', '9':'9️⃣', '10':'🔟', J:'🎴', Q:'👸', K:'🤴' };

function drawCard() { return { val: CARDS[Math.floor(Math.random()*CARDS.length)], suit: CARD_SUITS[Math.floor(Math.random()*4)] }; }
function handValue(hand) {
  let v = 0, aces = 0;
  for (const c of hand) {
    if (['J','Q','K'].includes(c.val)) v += 10;
    else if (c.val === 'A') { aces++; v += 11; }
    else v += parseInt(c.val);
  }
  while (v > 21 && aces > 0) { v -= 10; aces--; }
  return v;
}
function displayHand(hand) { return hand.map(c => `${CARD_EMOJIS[c.val]||c.val}${c.suit}`).join(' '); }

const blackjackCmd = {
  data: new SlashCommandBuilder().setName('blackjack').setDescription('Jouer au Blackjack contre le bot !')
    .addIntegerOption(o => o.setName('mise').setDescription('Mise en 🪙').setRequired(true).setMinValue(10)),
  cooldown: 10,
  async execute(interaction) {
    const mise = interaction.options.getInteger('mise');
    const eco  = getEconomy(interaction.guild.id, interaction.user.id);
    if (eco.balance < mise) return interaction.reply({ content: `❌ Solde insuffisant (**${eco.balance} 🪙**).`, ephemeral: true });

    const pHand  = [drawCard(), drawCard()];
    const dHand  = [drawCard(), drawCard()];
    const pScore = handValue(pHand);

    const gameId = `bj_${interaction.user.id}_${Date.now()}`;

    // Blackjack immédiat ?
    if (pScore === 21) {
      const gain = Math.floor(mise * 1.5);
      addCoins(interaction.guild.id, interaction.user.id, gain);
      return interaction.reply({ embeds: [new EmbedBuilder().setTitle('🃏 BLACKJACK ! 🎉')
        .setDescription(`Tu as un Blackjack naturel !\n\n**Toi :** ${displayHand(pHand)} = **21**\n**Bot :** ${displayHand(dHand)} = **${handValue(dHand)}**\n\n+**${gain} 🪙** !`)
        .setColor(0xffd700)] });
    }

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`bj_hit:${interaction.user.id}:${mise}`).setLabel('🃏 Tirer').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId(`bj_stand:${interaction.user.id}:${mise}`).setLabel('✋ Rester').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`bj_double:${interaction.user.id}:${mise}`).setLabel('⬆️ Doubler').setStyle(ButtonStyle.Success).setDisabled(eco.balance < mise * 2),
    );

    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('🃏 Blackjack')
      .setDescription(`**Toi :** ${displayHand(pHand)} = **${pScore}**\n**Bot :** ${dHand[0].val}${dHand[0].suit} 🂠 = **${handValue([dHand[0]])}+?**\n\nMise : **${mise} 🪙**`)
      .setColor(0x5865f2)], components: [row] });

    // Stocker l'état du jeu
    const stateKey = `bj:${interaction.user.id}`;
    const client = interaction.client;
    client.bjGames = client.bjGames || new Map();
    client.bjGames.set(stateKey, { pHand, dHand, mise, guildId: interaction.guild.id });
  },
};

// ─── /lottery ────────────────────────────────────────────────────────────────
const lotteryData = new Map(); // guildId -> { pot, tickets: Map<userId, count> }

const lotteryCmd = {
  data: new SlashCommandBuilder().setName('lottery').setDescription('Système de loterie communautaire')
    .addSubcommand(s => s.setName('buy').setDescription('Acheter des billets de loterie')
      .addIntegerOption(o => o.setName('nombre').setDescription('Nombre de billets (1-10)').setRequired(true).setMinValue(1).setMaxValue(10)))
    .addSubcommand(s => s.setName('status').setDescription('Voir l\'état de la loterie'))
    .addSubcommand(s => s.setName('draw').setDescription('Tirer le gagnant (admin)').setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)),
  cooldown: 5,
  async execute(interaction) {
    const sub     = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;

    if (!lotteryData.has(guildId)) lotteryData.set(guildId, { pot: 0, tickets: new Map() });
    const lottery = lotteryData.get(guildId);

    if (sub === 'buy') {
      const nombre = interaction.options.getInteger('nombre');
      const cost   = nombre * 50;
      const eco    = getEconomy(guildId, interaction.user.id);
      if (eco.balance < cost) return interaction.reply({ content: `❌ Il te faut **${cost} 🪙** (${nombre} billets × 50 🪙).`, ephemeral: true });
      deductCoins(guildId, interaction.user.id, cost);
      lottery.pot += cost;
      const cur = lottery.tickets.get(interaction.user.id) || 0;
      lottery.tickets.set(interaction.user.id, cur + nombre);
      return interaction.reply({ embeds: [new EmbedBuilder().setDescription(`🎫 Tu as acheté **${nombre}** billet(s) pour **${cost} 🪙** !\nCagnotte actuelle : **${lottery.pot} 🪙**`).setColor(0xffd700)] });
    }

    if (sub === 'status') {
      const totalTickets = [...lottery.tickets.values()].reduce((a, b) => a + b, 0);
      const embed = new EmbedBuilder().setTitle('🎰 Loterie en cours').setColor(0xffd700)
        .addFields({ name: '💰 Cagnotte', value: `**${lottery.pot} 🪙**`, inline: true }, { name: '🎫 Billets', value: `**${totalTickets}**`, inline: true }, { name: '👥 Participants', value: `**${lottery.tickets.size}**`, inline: true });
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'draw') {
      if (!lottery.tickets.size) return interaction.reply({ content: '❌ Aucun participant !', ephemeral: true });
      const pool = [];
      for (const [uid, count] of lottery.tickets) { for (let i = 0; i < count; i++) pool.push(uid); }
      const winner = pool[Math.floor(Math.random() * pool.length)];
      const prize  = lottery.pot;
      addCoins(guildId, winner, prize);
      lotteryData.set(guildId, { pot: 0, tickets: new Map() });
      return interaction.reply({ embeds: [new EmbedBuilder().setTitle('🎰 Résultat de la Loterie')
        .setDescription(`🎊 Le gagnant est <@${winner}> !\n\nPrix : **${prize} 🪙**`)
        .setColor(0xffd700).setTimestamp()] });
    }
  },
};

// ─── /hourly ─────────────────────────────────────────────────────────────────
const hourlyCmd = {
  data: new SlashCommandBuilder().setName('hourly').setDescription('Bonus horaire (cooldown 1h)'),
  cooldown: 3,
  async execute(interaction) {
    const wait = checkCooldown(interaction.user.id, 'hourly', 3600);
    if (wait) return interaction.reply({ content: `⏳ Reviens dans **${formatTime(wait)}** pour ton bonus horaire.`, ephemeral: true });
    const amount = Math.floor(Math.random() * 30) + 20;
    addCoins(interaction.guild.id, interaction.user.id, amount);
    const eco = getEconomy(interaction.guild.id, interaction.user.id);
    await interaction.reply({ embeds: [new EmbedBuilder().setDescription(`⏰ Bonus horaire : **+${amount} 🪙** !\nSolde : **${eco.balance} 🪙**`).setColor(0x57f287)] });
  },
};

// ─── /weekly ─────────────────────────────────────────────────────────────────
const weeklyCmd = {
  data: new SlashCommandBuilder().setName('weekly').setDescription('Bonus hebdomadaire (cooldown 7j)'),
  cooldown: 3,
  async execute(interaction) {
    const wait = checkCooldown(interaction.user.id, 'weekly', 604800);
    if (wait) return interaction.reply({ content: `⏳ Reviens dans **${formatTime(wait)}** pour ton bonus hebdo.`, ephemeral: true });
    const amount = Math.floor(Math.random() * 500) + 500;
    addCoins(interaction.guild.id, interaction.user.id, amount);
    const eco = getEconomy(interaction.guild.id, interaction.user.id);
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('🗓️ Bonus hebdomadaire').setDescription(`Tu as reçu **${amount} 🪙** !\nSolde : **${eco.balance} 🪙**`).setColor(0xffd700)] });
  },
};

// ─── /eco-admin ───────────────────────────────────────────────────────────────
const ecoAdminCmd = {
  data: new SlashCommandBuilder().setName('eco-admin').setDescription('Administrer l\'économie du serveur')
    .addSubcommand(s => s.setName('add').setDescription('Ajouter des 🪙 à un membre')
      .addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true))
      .addIntegerOption(o => o.setName('montant').setDescription('Montant').setRequired(true).setMinValue(1)))
    .addSubcommand(s => s.setName('remove').setDescription('Retirer des 🪙 à un membre')
      .addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true))
      .addIntegerOption(o => o.setName('montant').setDescription('Montant').setRequired(true).setMinValue(1)))
    .addSubcommand(s => s.setName('set').setDescription('Définir le solde d\'un membre')
      .addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true))
      .addIntegerOption(o => o.setName('montant').setDescription('Solde').setRequired(true).setMinValue(0)))
    .addSubcommand(s => s.setName('reset').setDescription('Remettre le solde à 0')
      .addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true)))
    .addSubcommand(s => s.setName('view').setDescription('Voir le solde d\'un membre')
      .addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  cooldown: 3,
  async execute(interaction) {
    const sub    = interaction.options.getSubcommand();
    const target = interaction.options.getUser('membre');
    const amount = interaction.options.getInteger('montant') ?? 0;

    if (sub === 'add') {
      addCoins(interaction.guild.id, target.id, amount);
      return interaction.reply({ content: `✅ **+${amount} 🪙** ajouté à **${target.username}**.`, ephemeral: true });
    }
    if (sub === 'remove') {
      deductCoins(interaction.guild.id, target.id, amount);
      return interaction.reply({ content: `✅ **-${amount} 🪙** retiré à **${target.username}**.`, ephemeral: true });
    }
    if (sub === 'set') {
      const db = getDb();
      getEconomy(interaction.guild.id, target.id);
      db.prepare('UPDATE economy SET balance=? WHERE guild_id=? AND user_id=?').run(amount, interaction.guild.id, target.id);
      db.close();
      return interaction.reply({ content: `✅ Solde de **${target.username}** défini à **${amount} 🪙**.`, ephemeral: true });
    }
    if (sub === 'reset') {
      const db = getDb();
      getEconomy(interaction.guild.id, target.id);
      db.prepare('UPDATE economy SET balance=0,total_earned=0,last_daily=0,last_work=0 WHERE guild_id=? AND user_id=?').run(interaction.guild.id, target.id);
      db.close();
      return interaction.reply({ content: `✅ Économie de **${target.username}** réinitialisée.`, ephemeral: true });
    }
    if (sub === 'view') {
      const eco = getEconomy(interaction.guild.id, target.id);
      return interaction.reply({ embeds: [new EmbedBuilder().setTitle(`💰 Solde de ${target.username}`)
        .addFields({ name: 'Solde', value: `**${eco.balance} 🪙**`, inline: true }, { name: 'Total gagné', value: `**${eco.total_earned} 🪙**`, inline: true })
        .setColor(0xffd700).setThumbnail(target.displayAvatarURL())], ephemeral: true });
    }
  },
};

// ─── /leaderboard-eco ─────────────────────────────────────────────────────────
const leaderboardEcoCmd = {
  data: new SlashCommandBuilder().setName('leaderboard-eco').setDescription('Classement de l\'économie du serveur')
    .addIntegerOption(o => o.setName('top').setDescription('Nombre d\'entrées (5-20)').setMinValue(5).setMaxValue(20)),
  cooldown: 10,
  async execute(interaction) {
    await interaction.deferReply();
    const top  = interaction.options.getInteger('top') ?? 10;
    const data = getEcoLeaderboard(interaction.guild.id, top);
    const lines = await Promise.all(data.map(async (row, i) => {
      const user = await interaction.client.users.fetch(row.user_id).catch(() => null);
      const m = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `**${i + 1}.**`;
      return `${m} ${user ? `**${user.username}**` : `<@${row.user_id}>`} — **${row.balance} 🪙** (total gagné: ${row.total_earned} 🪙)`;
    }));
    await interaction.editReply({ embeds: [new EmbedBuilder().setTitle(`💰 Top ${top} — Économie`).setColor(0xffd700).setDescription(lines.join('\n') || 'Aucune donnée.').setTimestamp()] });
  },
};

// ─── Helper ───────────────────────────────────────────────────────────────────
function formatTime(seconds) {
  const h = Math.floor(seconds / 3600), m = Math.floor((seconds % 3600) / 60), s = seconds % 60;
  return [h && `${h}h`, m && `${m}m`, s && `${s}s`].filter(Boolean).join(' ');
}

module.exports = [
  robCmd, mineCmd, fishCmd, huntCmd, crimeCmd, begCmd,
  highlowCmd, blackjackCmd, lotteryCmd,
  hourlyCmd, weeklyCmd, ecoAdminCmd, leaderboardEcoCmd,
];

/**
 * Commandes fun avancées
 * /roast /compliment /rate /ship /action /fact /quote /riddle
 * /truth /dare /wyr /text /password /lorem /word-count
 * /say /embed-custom /afk /uuid /trivia /base64 /number-fact
 * /poll-end /fortune /would-you-rather /tictactoe
 */

const {
  SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, PermissionFlagsBits,
} = require('discord.js');

// ─── AFK ──────────────────────────────────────────────────────────────────────
// Map de session en mémoire (pas en DB, réinitialisé au restart)
const afkUsers = new Map(); // userId -> { reason, since }

// ─── Données fun ──────────────────────────────────────────────────────────────
const ROASTS = [
  'Tu es la raison pour laquelle les shampooings ont des instructions.',
  'Tu es comme un nuage : quand tu disparais, c\'est une belle journée.',
  'Si l\'intelligence était un jeu de société, tu te retrouverais à jouer aux dés seul.',
  'Tu prouves qu\'on peut survivre sans cerveau.',
  'Même Google ne peut pas trouver ta logique.',
  'Tu es tellement lent que même une tortue te dépasserait en ligne droite.',
  'Tu confonds qualité et quantité — et tu rates les deux.',
  'Merci d\'exister, ça me donne de la matière pour mes blagues.',
];

const COMPLIMENTS = [
  'Tu illumines chaque pièce dans laquelle tu entres.',
  'Tu as un talent incroyable pour faire sourire les gens autour de toi.',
  'Tu es l\'une des personnes les plus inspirantes que je connaisse.',
  'Ta créativité est vraiment sans limites.',
  'Le monde est meilleur avec toi dedans.',
  'Tu as un cœur en or pur.',
  'Tu réussis tout ce que tu entreprends avec style.',
  'Tu es une combinaison rare de brillance et de gentillesse.',
];

const FACTS = [
  'Les pieuvres ont trois cœurs et leur sang est bleu.',
  'Les bananes sont légèrement radioactives.',
  'Un groupe de flamants roses s\'appelle un "flamboyance".',
  'Les éléphants sont les seuls animaux qui ne peuvent pas sauter.',
  'La Grande Muraille de Chine n\'est pas visible à l\'œil nu depuis l\'espace.',
  'Les chats dorment entre 12 et 16 heures par jour.',
  'Les fourmis peuvent soulever 50 fois leur propre poids.',
  'Le miel ne périme jamais — on en a trouvé dans des tombes égyptiennes.',
  'Les crevettes ont le cœur dans la tête.',
  'Un seul éclair contient assez d\'énergie pour cuire 100 000 toasts.',
  'Les humains et les girafes ont le même nombre de vertèbres cervicales : 7.',
  'Les pandas sont techniquement des carnivores qui ont évolué pour manger du bambou.',
];

const QUOTES = [
  { q: 'La vie est un mystère qu\'il faut vivre, et non un problème à résoudre.', a: 'Gandhi' },
  { q: 'Le succès c\'est tomber sept fois et se relever huit.', a: 'Proverbe japonais' },
  { q: 'Soyez vous-même, les autres sont déjà pris.', a: 'Oscar Wilde' },
  { q: 'L\'imagination est plus importante que la connaissance.', a: 'Albert Einstein' },
  { q: 'La vie est courte, souriez pendant qu\'il vous reste des dents.', a: 'Proverbe' },
  { q: 'Agis comme si ce que tu fais faisait une différence. Ça en fait une.', a: 'William James' },
  { q: 'Ce n\'est pas parce que les choses sont difficiles que nous n\'osons pas, c\'est parce que nous n\'osons pas qu\'elles sont difficiles.', a: 'Sénèque' },
  { q: 'La seule façon de faire du bon travail est d\'aimer ce que vous faites.', a: 'Steve Jobs' },
];

const RIDDLES = [
  { q: 'Je parle sans bouche et j\'entends sans oreilles. Je n\'ai pas de corps mais je prends vie avec le vent. Qu\'est-ce que je suis ?', a: 'Un écho' },
  { q: 'Je suis léger comme une plume, mais même l\'homme le plus fort ne peut me tenir plus d\'une minute. Qu\'est-ce que je suis ?', a: 'Le souffle' },
  { q: 'Plus tu m\'enlèves, plus je suis grande. Qu\'est-ce que je suis ?', a: 'Un trou' },
  { q: 'Je suis toujours devant toi mais on ne peut jamais me voir. Qu\'est-ce que je suis ?', a: 'L\'avenir' },
  { q: 'Je commence la nuit et finis le matin. Qu\'est-ce que je suis ?', a: 'La lettre N' },
  { q: 'Qu\'est-ce qui a des dents mais ne peut pas mordre ?', a: 'Un peigne' },
  { q: 'Je suis plein de trous mais je retiens de l\'eau. Qu\'est-ce que je suis ?', a: 'Une éponge' },
];

const TRUTHS = [
  'Quel est ton souvenir le plus embarrassant ?',
  'Quelle est la chose la plus stupide que tu aies faite par amour ?',
  'Quel est ton pire défaut selon toi ?',
  'Quelle est la pire note que tu aies eue à l\'école ?',
  'As-tu déjà menti à ton meilleur ami ? Sur quoi ?',
  'Quelle est la chose dont tu as le plus honte sur Internet ?',
  'Quel est le secret que tu gardes depuis le plus longtemps ?',
];

const DARES = [
  'Fais 20 pompes maintenant.',
  'Poste une photo embarrassante de toi dans le chat.',
  'Chante le premier couplet de ta chanson préférée.',
  'Écris un poème sur le dernier membre qui a parlé.',
  'Envoie un message "Je t\'aime ❤️" à ton/ta meilleur(e) ami(e).',
  'Imite un personnage connu pendant 1 minute.',
  'Écris ton prochain message en utilisant uniquement des emojis.',
];

const WYR_QUESTIONS = [
  'Préfères-tu pouvoir voler ou être invisible ?',
  'Préfères-tu ne plus jamais manger ta nourriture préférée ou l\'entendre tous les jours sans pouvoir y toucher ?',
  'Préfères-tu voyager dans le futur ou dans le passé ?',
  'Préfères-tu avoir la mémoire parfaite ou être incroyablement rapide ?',
  'Préfères-tu ne plus jamais utiliser Internet ou ne plus jamais utiliser de téléphone ?',
  'Préfères-tu parler à tous les animaux ou parler toutes les langues humaines ?',
  'Préfères-tu savoir comment tu vas mourir ou quand tu vas mourir ?',
];

const TRIVIA_QUESTIONS = [
  { q: 'Quelle est la capitale de l\'Australie ?', choices: ['Sydney', 'Melbourne', 'Canberra', 'Brisbane'], correct: 2 },
  { q: 'Combien d\'os a le corps humain adulte ?', choices: ['186', '206', '226', '246'], correct: 1 },
  { q: 'Quel est le plus grand pays du monde par superficie ?', choices: ['Canada', 'États-Unis', 'Chine', 'Russie'], correct: 3 },
  { q: 'En quelle année a été fondée Amazon ?', choices: ['1993', '1994', '1995', '1996'], correct: 1 },
  { q: 'Quel élément chimique a le symbole "Au" ?', choices: ['Argent', 'Aluminium', 'Or', 'Cuivre'], correct: 2 },
  { q: 'Combien de planètes compte le système solaire ?', choices: ['7', '8', '9', '10'], correct: 1 },
  { q: 'Qui a peint la Joconde ?', choices: ['Michel-Ange', 'Raphaël', 'Botticelli', 'Léonard de Vinci'], correct: 3 },
  { q: 'Quel sport se joue à Wimbledon ?', choices: ['Golf', 'Tennis', 'Cricket', 'Squash'], correct: 1 },
];

const FORTUNE_COOKIES = [
  'Une surprise agréable vous attend bientôt.',
  'Votre persévérance sera récompensée.',
  'Un ami inattendu vous apportera de la joie.',
  'La chance est de votre côté ce mois-ci.',
  'Un changement positif est sur le point de se produire.',
  'Votre créativité est votre plus grande force.',
  'Quelqu\'un pense à vous en ce moment même.',
  'Le succès vient à ceux qui osent.',
];

// ─── /roast ───────────────────────────────────────────────────────────────────
const roastCmd = {
  data: new SlashCommandBuilder().setName('roast').setDescription('Vanner quelqu\'un avec amour 😈')
    .addUserOption(o => o.setName('membre').setDescription('Victime').setRequired(true)),
  cooldown: 5,
  async execute(interaction) {
    const target = interaction.options.getUser('membre');
    const roast  = ROASTS[Math.floor(Math.random() * ROASTS.length)];
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle(`🔥 Roast — ${target.username}`).setDescription(roast).setThumbnail(target.displayAvatarURL()).setColor(0xed4245).setFooter({ text: `Demandé par ${interaction.user.tag}` })] });
  },
};

// ─── /compliment ─────────────────────────────────────────────────────────────
const complimentCmd = {
  data: new SlashCommandBuilder().setName('compliment').setDescription('Complimenter un membre 💖')
    .addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true)),
  cooldown: 5,
  async execute(interaction) {
    const target     = interaction.options.getUser('membre');
    const compliment = COMPLIMENTS[Math.floor(Math.random() * COMPLIMENTS.length)];
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle(`💖 Compliment — ${target.username}`).setDescription(compliment).setThumbnail(target.displayAvatarURL()).setColor(0xff69b4).setFooter({ text: `Envoyé par ${interaction.user.tag}` })] });
  },
};

// ─── /rate ────────────────────────────────────────────────────────────────────
const rateCmd = {
  data: new SlashCommandBuilder().setName('rate').setDescription('Évaluer quelque chose sur 10')
    .addStringOption(o => o.setName('chose').setDescription('Qu\'est-ce qu\'on évalue ?').setRequired(true)),
  cooldown: 3,
  async execute(interaction) {
    const chose = interaction.options.getString('chose');
    const score = Math.floor(Math.random() * 11);
    const bar   = '⭐'.repeat(score) + '☆'.repeat(10 - score);
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('⭐ Évaluateur impartial').addFields({ name: chose, value: `${bar}\n**${score}/10**` }).setColor(0xffd700)] });
  },
};

// ─── /ship ────────────────────────────────────────────────────────────────────
const shipCmd = {
  data: new SlashCommandBuilder().setName('ship').setDescription('Calculer la compatibilité amoureuse 💕')
    .addUserOption(o => o.setName('personne1').setDescription('Première personne').setRequired(true))
    .addUserOption(o => o.setName('personne2').setDescription('Deuxième personne').setRequired(true)),
  cooldown: 5,
  async execute(interaction) {
    const p1    = interaction.options.getUser('personne1');
    const p2    = interaction.options.getUser('personne2');
    const score = Math.floor(Math.random() * 101);
    const bar   = '❤️'.repeat(Math.floor(score / 10)) + '🖤'.repeat(10 - Math.floor(score / 10));
    let msg     = score >= 80 ? '💍 Un amour légendaire !' : score >= 60 ? '💕 Ça matche bien !' : score >= 40 ? '🤔 Peut mieux faire...' : '😬 Bonne chance...';
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('💕 Compatibilité amoureuse')
      .setDescription(`**${p1.username}** + **${p2.username}** = **${score}%**\n${bar}\n\n*${msg}*`)
      .setColor(0xff69b4).setThumbnail(p1.displayAvatarURL())] });
  },
};

// ─── /action ─────────────────────────────────────────────────────────────────
const actionCmd = {
  data: new SlashCommandBuilder().setName('action').setDescription('Actions sociales animées')
    .addSubcommand(s => s.setName('hug').setDescription('Faire un câlin').addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true)))
    .addSubcommand(s => s.setName('pat').setDescription('Tapoter la tête').addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true)))
    .addSubcommand(s => s.setName('kiss').setDescription('Faire un bisou').addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true)))
    .addSubcommand(s => s.setName('slap').setDescription('Donner une gifle').addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true)))
    .addSubcommand(s => s.setName('punch').setDescription('Donner un coup de poing').addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true)))
    .addSubcommand(s => s.setName('wave').setDescription('Faire un signe de la main').addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true)))
    .addSubcommand(s => s.setName('highfive').setDescription('Taper dans la main').addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true)))
    .addSubcommand(s => s.setName('poke').setDescription('Donner un coup de doigt').addUserOption(o => o.setName('membre').setDescription('Membre').setRequired(true))),
  cooldown: 3,
  async execute(interaction) {
    const sub    = interaction.options.getSubcommand();
    const target = interaction.options.getUser('membre');
    const verbs  = { hug: { text: `**${interaction.user.username}** serre **${target.username}** dans ses bras 🤗`, color: 0xff69b4, emoji: '🤗' }, pat: { text: `**${interaction.user.username}** tapote la tête de **${target.username}** 👋`, color: 0xffd700, emoji: '🐾' }, kiss: { text: `**${interaction.user.username}** embrasse **${target.username}** 💋`, color: 0xff1493, emoji: '💋' }, slap: { text: `**${interaction.user.username}** gifle **${target.username}** 👋`, color: 0xed4245, emoji: '💥' }, punch: { text: `**${interaction.user.username}** frappe **${target.username}** 🥊`, color: 0xff6600, emoji: '🥊' }, wave: { text: `**${interaction.user.username}** salue **${target.username}** 👋`, color: 0x57f287, emoji: '👋' }, highfive: { text: `**${interaction.user.username}** fait un high-five à **${target.username}** ✋`, color: 0x5865f2, emoji: '✋' }, poke: { text: `**${interaction.user.username}** donne un coup de doigt à **${target.username}** 👉`, color: 0xfee75c, emoji: '👉' } };
    const v = verbs[sub];
    await interaction.reply({ embeds: [new EmbedBuilder().setDescription(v.text).setColor(v.color).setThumbnail(target.displayAvatarURL())] });
  },
};

// ─── /fact ────────────────────────────────────────────────────────────────────
const factCmd = {
  data: new SlashCommandBuilder().setName('fact').setDescription('Un fait aléatoire et surprenant'),
  cooldown: 5,
  async execute(interaction) {
    const fact = FACTS[Math.floor(Math.random() * FACTS.length)];
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('🧠 Le saviez-vous ?').setDescription(fact).setColor(0x5865f2).setTimestamp()] });
  },
};

// ─── /quote ───────────────────────────────────────────────────────────────────
const quoteCmd = {
  data: new SlashCommandBuilder().setName('quote').setDescription('Citation inspirante'),
  cooldown: 5,
  async execute(interaction) {
    const q = QUOTES[Math.floor(Math.random() * QUOTES.length)];
    await interaction.reply({ embeds: [new EmbedBuilder().setDescription(`*"${q.q}"*`).setFooter({ text: `— ${q.a}` }).setColor(0x5865f2).setTimestamp()] });
  },
};

// ─── /riddle ─────────────────────────────────────────────────────────────────
const riddleCmd = {
  data: new SlashCommandBuilder().setName('riddle').setDescription('Une devinette à résoudre'),
  cooldown: 10,
  async execute(interaction) {
    const r = RIDDLES[Math.floor(Math.random() * RIDDLES.length)];
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('🔎 Devinette').setDescription(`${r.q}\n\n||**Réponse :** ${r.a}||`).setColor(0x5865f2).setFooter({ text: 'Cliquez sur le texte pour voir la réponse !' })] });
  },
};

// ─── /truth ───────────────────────────────────────────────────────────────────
const truthCmd = {
  data: new SlashCommandBuilder().setName('truth').setDescription('Question vérité aléatoire')
    .addUserOption(o => o.setName('membre').setDescription('Membre visé (optionnel)')),
  cooldown: 5,
  async execute(interaction) {
    const target = interaction.options.getUser('membre');
    const t = TRUTHS[Math.floor(Math.random() * TRUTHS.length)];
    const desc = target ? `${target}, ${t.charAt(0).toLowerCase() + t.slice(1)}` : t;
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('🎭 Vérité !').setDescription(desc).setColor(0x5865f2)] });
  },
};

// ─── /dare ────────────────────────────────────────────────────────────────────
const dareCmd = {
  data: new SlashCommandBuilder().setName('dare').setDescription('Défi aléatoire')
    .addUserOption(o => o.setName('membre').setDescription('Membre visé (optionnel)')),
  cooldown: 5,
  async execute(interaction) {
    const target = interaction.options.getUser('membre');
    const d = DARES[Math.floor(Math.random() * DARES.length)];
    const desc = target ? `${target} : ${d.charAt(0).toLowerCase() + d.slice(1)}` : d;
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('🔥 Défi !').setDescription(desc).setColor(0xed4245)] });
  },
};

// ─── /wyr ─────────────────────────────────────────────────────────────────────
const wyrCmd = {
  data: new SlashCommandBuilder().setName('wyr').setDescription('Préfères-tu... ? (Would You Rather)'),
  cooldown: 5,
  async execute(interaction) {
    const q = WYR_QUESTIONS[Math.floor(Math.random() * WYR_QUESTIONS.length)];
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('🤔 Préfères-tu...').setDescription(q).setColor(0xfee75c)] });
  },
};

// ─── /trivia ─────────────────────────────────────────────────────────────────
const triviaCmd = {
  data: new SlashCommandBuilder().setName('trivia').setDescription('Question de culture générale'),
  cooldown: 10,
  async execute(interaction) {
    const q      = TRIVIA_QUESTIONS[Math.floor(Math.random() * TRIVIA_QUESTIONS.length)];
    const emojis = ['🇦', '🇧', '🇨', '🇩'];
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('🎓 Trivia !').setDescription(`**${q.q}**\n\n${q.choices.map((c, i) => `${emojis[i]} ${c}`).join('\n')}\n\n||✅ Bonne réponse : **${emojis[q.correct]} ${q.choices[q.correct]}**||`).setColor(0x5865f2).setFooter({ text: 'Cliquez sur le texte caché pour voir la réponse !' })] });
  },
};

// ─── /fortune ─────────────────────────────────────────────────────────────────
const fortuneCmd = {
  data: new SlashCommandBuilder().setName('fortune').setDescription('Fortune cookie du jour 🥠'),
  cooldown: 5,
  async execute(interaction) {
    const f = FORTUNE_COOKIES[Math.floor(Math.random() * FORTUNE_COOKIES.length)];
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('🥠 Fortune Cookie').setDescription(`*"${f}"*`).setColor(0xffd700).setTimestamp()] });
  },
};

// ─── /text ────────────────────────────────────────────────────────────────────
const MORSE_MAP = {
  a:'.-',b:'-...',c:'-.-.',d:'-..',e:'.',f:'..-.',g:'--.',h:'....',
  i:'..',j:'.---',k:'-.-',l:'.-..',m:'--',n:'-.',o:'---',p:'.--.',
  q:'--.-',r:'.-.',s:'...',t:'-',u:'..-',v:'...-',w:'.--',x:'-..-',
  y:'-.--',z:'--..',0:'-----',1:'.----',2:'..---',3:'...--',4:'....-',
  5:'.....',6:'-....',7:'--...',8:'---..',9:'----.',
};
const LEET_MAP = { a:'4',e:'3',i:'1',o:'0',s:'5',t:'7',b:'8',g:'9',l:'1' };
const NATO_MAP = { a:'Alpha',b:'Bravo',c:'Charlie',d:'Delta',e:'Echo',f:'Foxtrot',g:'Golf',h:'Hotel',i:'India',j:'Juliet',k:'Kilo',l:'Lima',m:'Mike',n:'November',o:'Oscar',p:'Papa',q:'Quebec',r:'Romeo',s:'Sierra',t:'Tango',u:'Uniform',v:'Victor',w:'Whiskey',x:'X-ray',y:'Yankee',z:'Zulu' };

const textCmd = {
  data: new SlashCommandBuilder().setName('text').setDescription('Transformer du texte de toutes les façons')
    .addSubcommand(s => s.setName('reverse').setDescription('Inverser').addStringOption(o => o.setName('texte').setDescription('Texte').setRequired(true)))
    .addSubcommand(s => s.setName('mock').setDescription('SpOnGeBoB mOcKiNg').addStringOption(o => o.setName('texte').setDescription('Texte').setRequired(true)))
    .addSubcommand(s => s.setName('emojify').setDescription('Transformer en emojis lettres').addStringOption(o => o.setName('texte').setDescription('Texte').setRequired(true).setMaxLength(50)))
    .addSubcommand(s => s.setName('clap').setDescription('Ajouter 👏 entre chaque mot').addStringOption(o => o.setName('texte').setDescription('Texte').setRequired(true)))
    .addSubcommand(s => s.setName('leet').setDescription('Traduction Leet Speak').addStringOption(o => o.setName('texte').setDescription('Texte').setRequired(true)))
    .addSubcommand(s => s.setName('morse').setDescription('Convertir en code morse').addStringOption(o => o.setName('texte').setDescription('Texte').setRequired(true)))
    .addSubcommand(s => s.setName('nato').setDescription('Alphabet OTAN').addStringOption(o => o.setName('texte').setDescription('Texte').setRequired(true).setMaxLength(30)))
    .addSubcommand(s => s.setName('binary').setDescription('Texte vers binaire').addStringOption(o => o.setName('texte').setDescription('Texte').setRequired(true).setMaxLength(100)))
    .addSubcommand(s => s.setName('upper').setDescription('MAJUSCULES').addStringOption(o => o.setName('texte').setDescription('Texte').setRequired(true)))
    .addSubcommand(s => s.setName('lower').setDescription('minuscules').addStringOption(o => o.setName('texte').setDescription('Texte').setRequired(true)))
    .addSubcommand(s => s.setName('spoiler').setDescription('||Mettre en spoiler||').addStringOption(o => o.setName('texte').setDescription('Texte').setRequired(true))),
  cooldown: 3,
  async execute(interaction) {
    const sub   = interaction.options.getSubcommand();
    const texte = interaction.options.getString('texte');
    let result  = '';

    if (sub === 'reverse')  result = [...texte].reverse().join('');
    if (sub === 'mock')     result = [...texte].map((c,i)=>i%2?c.toUpperCase():c.toLowerCase()).join('');
    if (sub === 'emojify')  result = [...texte].map(c=>c===' '?'   ':(/[a-z]/i.test(c)?`:regional_indicator_${c.toLowerCase()}:`:c)).join('');
    if (sub === 'clap')     result = texte.split(' ').join(' 👏 ');
    if (sub === 'leet')     result = texte.toLowerCase().split('').map(c=>LEET_MAP[c]||c).join('');
    if (sub === 'morse')    result = texte.toLowerCase().split('').map(c=>MORSE_MAP[c]||'/').join(' ');
    if (sub === 'nato')     result = texte.toLowerCase().split('').map(c=>NATO_MAP[c]||(c===' '?'[espace]':c)).join(', ');
    if (sub === 'binary')   result = texte.split('').map(c=>c.charCodeAt(0).toString(2).padStart(8,'0')).join(' ');
    if (sub === 'upper')    result = texte.toUpperCase();
    if (sub === 'lower')    result = texte.toLowerCase();
    if (sub === 'spoiler')  return interaction.reply({ content: `||${texte}||` });

    await interaction.reply({ embeds: [new EmbedBuilder().addFields({ name: 'Original', value: texte.slice(0,500) }, { name: 'Résultat', value: result.slice(0,1000) || '*Vide*' }).setColor(0x5865f2)] });
  },
};

// ─── /base64 ─────────────────────────────────────────────────────────────────
const base64Cmd = {
  data: new SlashCommandBuilder().setName('base64').setDescription('Encoder ou décoder en Base64')
    .addSubcommand(s => s.setName('encode').setDescription('Encoder du texte en Base64').addStringOption(o => o.setName('texte').setDescription('Texte à encoder').setRequired(true)))
    .addSubcommand(s => s.setName('decode').setDescription('Décoder du Base64').addStringOption(o => o.setName('texte').setDescription('Base64 à décoder').setRequired(true))),
  cooldown: 3,
  async execute(interaction) {
    const sub   = interaction.options.getSubcommand();
    const texte = interaction.options.getString('texte');
    let result  = '';
    try {
      result = sub === 'encode' ? Buffer.from(texte).toString('base64') : Buffer.from(texte, 'base64').toString('utf-8');
    } catch { return interaction.reply({ content: '❌ Texte Base64 invalide.', ephemeral: true }); }
    await interaction.reply({ embeds: [new EmbedBuilder().addFields({ name: sub === 'encode' ? 'Original' : 'Base64', value: texte.slice(0,500) }, { name: sub === 'encode' ? 'Base64' : 'Décodé', value: result.slice(0,1000) }).setColor(0x5865f2)] });
  },
};

// ─── /password ───────────────────────────────────────────────────────────────
const passwordCmd = {
  data: new SlashCommandBuilder().setName('password').setDescription('Générer un mot de passe sécurisé')
    .addIntegerOption(o => o.setName('longueur').setDescription('Longueur (8-64)').setMinValue(8).setMaxValue(64))
    .addBooleanOption(o => o.setName('symbols').setDescription('Inclure des symboles'))
    .addBooleanOption(o => o.setName('chiffres').setDescription('Inclure des chiffres (défaut: oui)'))
    .addIntegerOption(o => o.setName('nombre').setDescription('Combien de mots de passe (1-5)').setMinValue(1).setMaxValue(5)),
  cooldown: 3,
  async execute(interaction) {
    const len     = interaction.options.getInteger('longueur') ?? 16;
    const symbols = interaction.options.getBoolean('symbols') ?? true;
    const digits  = interaction.options.getBoolean('chiffres') ?? true;
    const count   = interaction.options.getInteger('nombre') ?? 1;

    let charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (digits)  charset += '0123456789';
    if (symbols) charset += '!@#$%^&*()-_=+[]{}|;:,.<>?';

    const passwords = Array.from({ length: count }, () =>
      Array.from({ length: len }, () => charset[Math.floor(Math.random() * charset.length)]).join('')
    );

    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('🔐 Mots de passe générés').setDescription(passwords.map(p => `\`${p}\``).join('\n')).setColor(0x57f287).setFooter({ text: 'Ne partagez jamais vos mots de passe !' })], ephemeral: true });
  },
};

// ─── /uuid ────────────────────────────────────────────────────────────────────
const uuidCmd = {
  data: new SlashCommandBuilder().setName('uuid').setDescription('Générer des UUID v4 aléatoires')
    .addIntegerOption(o => o.setName('nombre').setDescription('Nombre à générer (1-10)').setMinValue(1).setMaxValue(10)),
  cooldown: 3,
  async execute(interaction) {
    const count = interaction.options.getInteger('nombre') ?? 1;
    const uuids = Array.from({ length: count }, () => {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
        const r = Math.random() * 16 | 0;
        return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
      });
    });
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('🔑 UUID v4').setDescription(uuids.map(u => `\`${u}\``).join('\n')).setColor(0x5865f2)], ephemeral: true });
  },
};

// ─── /lorem ───────────────────────────────────────────────────────────────────
const loremCmd = {
  data: new SlashCommandBuilder().setName('lorem').setDescription('Générer du texte Lorem Ipsum')
    .addIntegerOption(o => o.setName('paragraphes').setDescription('Nombre de paragraphes (1-5)').setMinValue(1).setMaxValue(5)),
  cooldown: 3,
  async execute(interaction) {
    const n = interaction.options.getInteger('paragraphes') ?? 1;
    const BASE = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.';
    const text = Array(n).fill(BASE).join('\n\n');
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('📝 Lorem Ipsum').setDescription(text.slice(0, 2000)).setColor(0x5865f2)], ephemeral: true });
  },
};

// ─── /word-count ─────────────────────────────────────────────────────────────
const wordCountCmd = {
  data: new SlashCommandBuilder().setName('word-count').setDescription('Analyser un texte')
    .addStringOption(o => o.setName('texte').setDescription('Texte à analyser').setRequired(true)),
  cooldown: 3,
  async execute(interaction) {
    const texte = interaction.options.getString('texte');
    const words = texte.trim().split(/\s+/).filter(Boolean).length;
    const chars = texte.length;
    const charsNoSpace = texte.replace(/\s/g, '').length;
    const sentences = texte.split(/[.!?]+/).filter(s => s.trim()).length;
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle('📊 Analyse du texte').setColor(0x5865f2)
      .addFields(
        { name: '📝 Mots',               value: `**${words}**`,          inline: true },
        { name: '🔤 Caractères',          value: `**${chars}**`,          inline: true },
        { name: '🔡 Sans espaces',        value: `**${charsNoSpace}**`,   inline: true },
        { name: '📖 Phrases (estimées)', value: `**${sentences}**`,       inline: true },
      )], ephemeral: true });
  },
};

// ─── /say ─────────────────────────────────────────────────────────────────────
const sayCmd = {
  data: new SlashCommandBuilder().setName('say').setDescription('Faire parler le bot')
    .addStringOption(o => o.setName('message').setDescription('Message').setRequired(true))
    .addChannelOption(o => o.setName('salon').setDescription('Salon cible'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  cooldown: 5,
  async execute(interaction) {
    const message = interaction.options.getString('message');
    const ch      = interaction.options.getChannel('salon') || interaction.channel;
    await ch.send({ content: message, allowedMentions: { parse: [] } });
    await interaction.reply({ content: '✅ Message envoyé.', ephemeral: true });
  },
};

// ─── /embed-custom ────────────────────────────────────────────────────────────
const embedCustomCmd = {
  data: new SlashCommandBuilder().setName('embed-custom').setDescription('Créer un embed personnalisé')
    .addStringOption(o => o.setName('description').setDescription('Contenu de l\'embed').setRequired(true))
    .addStringOption(o => o.setName('titre').setDescription('Titre'))
    .addStringOption(o => o.setName('couleur').setDescription('Couleur hex'))
    .addStringOption(o => o.setName('footer').setDescription('Pied de page'))
    .addStringOption(o => o.setName('image').setDescription('URL d\'une image'))
    .addChannelOption(o => o.setName('salon').setDescription('Salon cible'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  cooldown: 5,
  async execute(interaction) {
    const desc   = interaction.options.getString('description');
    const titre  = interaction.options.getString('titre');
    const color  = interaction.options.getString('couleur')?.replace('#', '') || '5865F2';
    const footer = interaction.options.getString('footer');
    const image  = interaction.options.getString('image');
    const ch     = interaction.options.getChannel('salon') || interaction.channel;

    const embed = new EmbedBuilder().setDescription(desc).setColor(parseInt(color, 16));
    if (titre)  embed.setTitle(titre);
    if (footer) embed.setFooter({ text: footer });
    if (image)  embed.setImage(image);

    await ch.send({ embeds: [embed] });
    await interaction.reply({ content: '✅ Embed envoyé.', ephemeral: true });
  },
};

// ─── /afk ────────────────────────────────────────────────────────────────────
const afkCmd = {
  data: new SlashCommandBuilder().setName('afk').setDescription('Se mettre en AFK ou vérifier le statut')
    .addSubcommand(s => s.setName('set').setDescription('Se mettre en AFK')
      .addStringOption(o => o.setName('raison').setDescription('Raison de l\'AFK')))
    .addSubcommand(s => s.setName('check').setDescription('Voir qui est AFK'))
    .addSubcommand(s => s.setName('remove').setDescription('Retirer son AFK')),
  cooldown: 5,
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    if (sub === 'set') {
      const raison = interaction.options.getString('raison') || 'AFK';
      afkUsers.set(interaction.user.id, { reason: raison, since: Date.now() });
      return interaction.reply({ embeds: [new EmbedBuilder().setDescription(`😴 **${interaction.user.username}** est maintenant AFK : *${raison}*`).setColor(0x99aab5)] });
    }
    if (sub === 'remove') {
      if (!afkUsers.has(interaction.user.id)) return interaction.reply({ content: 'ℹ️ Tu n\'étais pas AFK.', ephemeral: true });
      afkUsers.delete(interaction.user.id);
      return interaction.reply({ embeds: [new EmbedBuilder().setDescription(`✅ **${interaction.user.username}** n'est plus AFK !`).setColor(0x57f287)] });
    }
    if (sub === 'check') {
      if (!afkUsers.size) return interaction.reply({ content: 'ℹ️ Aucun membre AFK en ce moment.', ephemeral: true });
      const embed = new EmbedBuilder().setTitle('😴 Membres AFK').setColor(0x99aab5)
        .setDescription([...afkUsers.entries()].map(([id, data]) =>
          `<@${id}> — *${data.reason}* (depuis <t:${Math.floor(data.since/1000)}:R>)`
        ).join('\n'));
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  },
};
module.exports.afkUsers = afkUsers;

// ─── /number-fact ─────────────────────────────────────────────────────────────
const numberFactCmd = {
  data: new SlashCommandBuilder().setName('number-fact').setDescription('Un fait sur un nombre')
    .addIntegerOption(o => o.setName('nombre').setDescription('Nombre').setRequired(true)),
  cooldown: 3,
  async execute(interaction) {
    const n     = interaction.options.getInteger('nombre');
    const facts = [
      `Le nombre **${n}** en binaire est \`${n.toString(2)}\`.`,
      `Le nombre **${n}** en hexadécimal est \`${n.toString(16).toUpperCase()}\`.`,
      `Le nombre **${n}** est ${n % 2 === 0 ? 'pair' : 'impair'}.`,
      `Le nombre **${n}** est ${isPrime(n) ? '**premier** 🌟' : 'non premier'}.`,
      `La racine carrée de **${n}** est environ **${Math.sqrt(n).toFixed(4)}**.`,
      `**${n}** × **${n}** = **${n * n}**`,
    ];
    await interaction.reply({ embeds: [new EmbedBuilder().setTitle(`🔢 Fait sur le nombre ${n}`).setDescription(facts.join('\n')).setColor(0x5865f2)] });
  },
};

function isPrime(n) {
  if (n < 2) return false;
  for (let i = 2; i <= Math.sqrt(n); i++) { if (n % i === 0) return false; }
  return true;
}

module.exports = [
  roastCmd, complimentCmd, rateCmd, shipCmd, actionCmd,
  factCmd, quoteCmd, riddleCmd, truthCmd, dareCmd, wyrCmd,
  triviaCmd, fortuneCmd, textCmd, base64Cmd, passwordCmd,
  uuidCmd, loremCmd, wordCountCmd, sayCmd, embedCustomCmd,
  afkCmd, numberFactCmd,
];

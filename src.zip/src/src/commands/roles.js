/**
 * Commandes Reaction Roles & Role Rewards
 * /reactionrole, /rolereward
 */

const {
  SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits,
  ButtonBuilder, ButtonStyle, ActionRowBuilder,
} = require('discord.js');
const {
  createRRPanel, setRRPanelMessageId, getRRPanels, addRRRole, getRRRoles,
  setRoleReward, getRoleRewards, deleteRoleReward,
} = require('../handlers/database');

// ─────────────────────────────────────────────────────────────────────────────
// REACTION ROLES
// ─────────────────────────────────────────────────────────────────────────────

const reactionRoleCmd = {
  data: new SlashCommandBuilder().setName('reactionrole').setDescription('Gérer les panels de reaction roles')
    .addSubcommand(sub => sub.setName('create').setDescription('Créer un nouveau panel')
      .addStringOption(o=>o.setName('titre').setDescription('Titre du panel').setRequired(true))
      .addStringOption(o=>o.setName('description').setDescription('Description du panel')))
    .addSubcommand(sub => sub.setName('addrole').setDescription('Ajouter un rôle à un panel')
      .addIntegerOption(o=>o.setName('panel_id').setDescription('ID du panel').setRequired(true))
      .addRoleOption(o=>o.setName('role').setDescription('Rôle à ajouter').setRequired(true))
      .addStringOption(o=>o.setName('label').setDescription('Texte du bouton').setRequired(true))
      .addStringOption(o=>o.setName('emoji').setDescription('Emoji du bouton'))
      .addStringOption(o=>o.setName('style').setDescription('Couleur: bleu/vert/rouge/gris').addChoices(
        { name:'Bleu (Primary)', value:'1' },
        { name:'Vert (Success)', value:'3' },
        { name:'Rouge (Danger)', value:'4' },
        { name:'Gris (Secondary)', value:'2' },
      )))
    .addSubcommand(sub => sub.setName('send').setDescription('Envoyer un panel dans ce salon')
      .addIntegerOption(o=>o.setName('panel_id').setDescription('ID du panel').setRequired(true)))
    .addSubcommand(sub => sub.setName('list').setDescription('Lister les panels de ce serveur'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),
  cooldown: 5,
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub==='create') {
      const title = interaction.options.getString('titre');
      const desc  = interaction.options.getString('description');
      const res   = createRRPanel(interaction.guild.id, interaction.channel.id, title, desc);
      const id    = res.lastInsertRowid;
      return interaction.reply({ content:`✅ Panel **#${id}** créé !\nUtilise \`/reactionrole addrole\` pour ajouter des rôles, puis \`/reactionrole send\` pour l'envoyer.`, ephemeral:true });
    }

    if (sub==='addrole') {
      const panelId = interaction.options.getInteger('panel_id');
      const role    = interaction.options.getRole('role');
      const label   = interaction.options.getString('label');
      const emoji   = interaction.options.getString('emoji')||null;
      const style   = parseInt(interaction.options.getString('style')||'1');

      if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
        return interaction.reply({ content:'❌ Le bot n\'a pas la permission `Gérer les rôles`.', ephemeral:true });
      }

      const existing = getRRRoles(panelId);
      if (existing.length>=25) return interaction.reply({ content:'❌ Maximum 25 rôles par panel.', ephemeral:true });

      addRRRole(panelId, role.id, label, emoji, style);
      return interaction.reply({ content:`✅ Rôle **${role.name}** ajouté au panel **#${panelId}**.`, ephemeral:true });
    }

    if (sub==='send') {
      const panelId = interaction.options.getInteger('panel_id');
      const roles   = getRRRoles(panelId);
      if (!roles.length) return interaction.reply({ content:'❌ Ce panel n\'a aucun rôle. Ajoutes-en avec `/reactionrole addrole`.', ephemeral:true });

      const panels = getRRPanels(interaction.guild.id);
      const panel  = panels.find(p=>p.id===panelId);
      if (!panel) return interaction.reply({ content:'❌ Panel introuvable.', ephemeral:true });

      const embed = new EmbedBuilder()
        .setTitle(panel.title)
        .setDescription(panel.description||'Cliquez sur un bouton pour obtenir ou retirer un rôle.')
        .setColor(0x5865f2)
        .addFields(roles.map(r=>({ name: r.label, value:`<@&${r.role_id}>`, inline:true })))
        .setTimestamp();

      // Grouper les boutons par rangées de 5
      const rows = [];
      for (let i=0;i<roles.length;i+=5) {
        const row = new ActionRowBuilder();
        const chunk = roles.slice(i,i+5);
        row.addComponents(chunk.map(r=>
          new ButtonBuilder()
            .setCustomId(`rr_toggle:${r.role_id}`)
            .setLabel(r.label.slice(0,80))
            .setStyle(r.style||ButtonStyle.Primary)
            .setEmoji(r.emoji||undefined)
        ).filter(b=>{
          try { b.toJSON(); return true; } catch { return false; }
        }));
        if (row.components.length>0) rows.push(row);
      }

      const msg = await interaction.channel.send({ embeds:[embed], components:rows });
      setRRPanelMessageId(panelId, msg.id);
      return interaction.reply({ content:`✅ Panel **#${panelId}** envoyé dans ce salon.`, ephemeral:true });
    }

    if (sub==='list') {
      const panels = getRRPanels(interaction.guild.id);
      if (!panels.length) return interaction.reply({ content:'ℹ️ Aucun panel créé.', ephemeral:true });
      const embed = new EmbedBuilder().setTitle('🎭 Panels Reaction Roles').setColor(0x5865f2)
        .setDescription(panels.map(p=>{
          const roles = getRRRoles(p.id);
          return `**#${p.id}** — ${p.title} *(${roles.length} rôle(s))*`;
        }).join('\n'));
      return interaction.reply({ embeds:[embed], ephemeral:true });
    }
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// ROLE REWARDS (rôles attribués à certains niveaux XP)
// ─────────────────────────────────────────────────────────────────────────────

const roleRewardCmd = {
  data: new SlashCommandBuilder().setName('rolereward').setDescription('Gérer les rôles de récompense de niveau')
    .addSubcommand(sub=>sub.setName('add').setDescription('Attribuer un rôle à un niveau')
      .addIntegerOption(o=>o.setName('niveau').setDescription('Niveau requis').setRequired(true).setMinValue(1))
      .addRoleOption(o=>o.setName('role').setDescription('Rôle à attribuer').setRequired(true)))
    .addSubcommand(sub=>sub.setName('remove').setDescription('Retirer un rôle de récompense')
      .addIntegerOption(o=>o.setName('niveau').setDescription('Niveau').setRequired(true)))
    .addSubcommand(sub=>sub.setName('list').setDescription('Voir tous les rôles de récompense'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),
  cooldown: 5,
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();

    if (sub==='add') {
      const level = interaction.options.getInteger('niveau');
      const role  = interaction.options.getRole('role');
      setRoleReward(interaction.guild.id, level, role.id);
      return interaction.reply({ content:`✅ Le rôle **${role.name}** sera attribué au niveau **${level}**.`, ephemeral:true });
    }

    if (sub==='remove') {
      const level = interaction.options.getInteger('niveau');
      deleteRoleReward(interaction.guild.id, level);
      return interaction.reply({ content:`✅ Rôle de récompense du niveau **${level}** supprimé.`, ephemeral:true });
    }

    if (sub==='list') {
      const rewards = getRoleRewards(interaction.guild.id);
      if (!rewards.length) return interaction.reply({ content:'ℹ️ Aucun rôle de récompense configuré.', ephemeral:true });
      const embed = new EmbedBuilder().setTitle('🏆 Rôles de récompense').setColor(0xffd700)
        .setDescription(rewards.map(r=>`Niveau **${r.level}** → <@&${r.role_id}>`).join('\n'));
      return interaction.reply({ embeds:[embed], ephemeral:true });
    }
  },
};

module.exports = [reactionRoleCmd, roleRewardCmd];

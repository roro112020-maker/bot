/**
 * Point d'entrée principal du bot Discord
 * Charge automatiquement les commandes et événements
 * Lance le checker de rappels toutes les 30 secondes
 * Lance le checker de fin de giveaways toutes les 30 secondes
 */

require('dotenv').config();
const { Client, GatewayIntentBits, Collection, Partials } = require('discord.js');
const { loadCommands } = require('./handlers/commandHandler');
const { loadEvents }   = require('./handlers/eventHandler');
const { initDatabase, getPendingReminders, markReminderSent, getAllActiveGiveaways } = require('./handlers/database');
const { finishGiveaway } = require('./commands/utility');

// ─── Client ───────────────────────────────────────────────────────────────────
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.GuildVoiceStates,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.User, Partials.GuildMember],
});

// ─── Collections ──────────────────────────────────────────────────────────────
client.commands = new Collection();
client.cooldowns = new Collection();

// snipeCache : Map<channelId, Map<userId, { content, author, deletedAt, attachments }>>
client.snipeCache = new Map();

// antiNukeLog : Map<"guildId:userId", { channelDeletes, roleDeletes, bans }>
client.antiNukeLog = new Map();

// ─── Initialisation ───────────────────────────────────────────────────────────
initDatabase();
loadCommands(client);
loadEvents(client);

// ─── Checker de rappels (toutes les 30s) ──────────────────────────────────────
function startReminderChecker() {
  setInterval(async () => {
    const pending = getPendingReminders();
    for (const reminder of pending) {
      markReminderSent(reminder.id);
      try {
        const user = await client.users.fetch(reminder.user_id);
        await user.send({
          content: `⏰ **Rappel !**\n> ${reminder.message}\n*(créé <t:${reminder.created_at}:R>)*`,
        });
      } catch {
        // Si DM échoue, essayer dans le salon d'origine
        if (reminder.channel_id) {
          const ch = client.channels.cache.get(reminder.channel_id);
          if (ch) await ch.send({ content:`⏰ <@${reminder.user_id}> Rappel : ${reminder.message}` }).catch(()=>{});
        }
      }
    }
  }, 30_000);
}

// ─── Checker de fin de giveaways (toutes les 30s) ─────────────────────────────
function startGiveawayChecker() {
  setInterval(async () => {
    const now     = Math.floor(Date.now()/1000);
    const actives = getAllActiveGiveaways();
    for (const gw of actives) {
      if (gw.ends_at<=now) {
        try { await finishGiveaway(client, gw.id); }
        catch(e) { console.error('[GW CHECKER]', e.message); }
      }
    }
  }, 30_000);
}

// ─── Démarrer les checkers après connexion ────────────────────────────────────
client.once('clientReady', () => {
  startReminderChecker();
  startGiveawayChecker();
  console.log('[BOT] Checkers rappels et giveaways démarrés.');
});

// ─── Connexion ────────────────────────────────────────────────────────────────
client.login(process.env.DISCORD_TOKEN).catch(err => {
  console.error('[FATAL] Connexion Discord impossible:', err.message);
  process.exit(1);
});

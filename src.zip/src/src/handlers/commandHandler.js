/**
 * Chargeur automatique de commandes slash
 * Gère les fichiers exportant un objet (commande unique) ou un tableau (plusieurs commandes)
 */

const fs = require('fs');
const path = require('path');

function loadCommands(client) {
  const commandsPath = path.join(__dirname, '../commands');
  const files = fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'));
  let count = 0;

  for (const file of files) {
    const raw = require(path.join(commandsPath, file));
    // Normaliser en tableau
    const commands = Array.isArray(raw) ? raw : [raw];

    for (const command of commands) {
      if (command.data && command.execute) {
        client.commands.set(command.data.name, command);
        console.log(`[CMD] Commande chargée : /${command.data.name}`);
        count++;
      } else {
        console.warn(`[CMD] Commande ignorée (structure invalide) dans ${file}`);
      }
    }
  }

  console.log(`[CMD] ${count} commande(s) chargée(s).`);
}

module.exports = { loadCommands };

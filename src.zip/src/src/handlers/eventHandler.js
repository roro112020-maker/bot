/**
 * Chargeur automatique d'événements Discord
 * Gère les fichiers exportant un objet (event unique) ou un tableau (plusieurs events)
 */

const fs = require('fs');
const path = require('path');

function loadEvents(client) {
  const eventsPath = path.join(__dirname, '../events');
  const files = fs.readdirSync(eventsPath).filter(f => f.endsWith('.js') && f !== 'index.js');
  let count = 0;

  for (const file of files) {
    const raw = require(path.join(eventsPath, file));
    // Normaliser en tableau
    const events = Array.isArray(raw) ? raw : [raw];

    for (const event of events) {
      if (!event.name || !event.execute) {
        console.warn(`[EVT] Handler ignoré (structure invalide) dans ${file}`);
        continue;
      }
      if (event.once) {
        client.once(event.name, (...args) => event.execute(...args, client));
      } else {
        client.on(event.name, (...args) => event.execute(...args, client));
      }
      console.log(`[EVT] Événement chargé : ${event.name}`);
      count++;
    }
  }

  console.log(`[EVT] ${count} listener(s) d'événement chargé(s).`);
}

module.exports = { loadEvents };

/**
 * Base de données SQLite (node:sqlite natif Node 24+)
 * Tables : guild_config, warns, tickets, ticket_panels, mod_logs, levels,
 *          giveaways, reaction_role_panels, reaction_roles, tags, economy,
 *          suggestions, role_rewards, reminders, starboard, notes, xp_config
 */

const { DatabaseSync } = require('node:sqlite');
const path = require('path');
const fs   = require('fs');

const DATA_DIR = path.join(__dirname, '../../data');
const DB_PATH  = path.join(DATA_DIR, 'bot.db');
let db;

function initDatabase() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  db = new DatabaseSync(DB_PATH);
  db.exec(`PRAGMA journal_mode = WAL;`);

  db.exec(`
    CREATE TABLE IF NOT EXISTS guild_config (
      guild_id TEXT PRIMARY KEY,
      log_channel TEXT, welcome_channel TEXT,
      welcome_message TEXT DEFAULT 'Bienvenue {user} sur **{server}** !',
      auto_role TEXT, mod_role TEXT, ticket_category TEXT,
      antinuke_enabled INTEGER DEFAULT 0,
      antinuke_threshold INTEGER DEFAULT 5,
      antinuke_window INTEGER DEFAULT 10,
      antiraid_enabled INTEGER DEFAULT 0,
      antiraid_joins INTEGER DEFAULT 10,
      antiraid_window INTEGER DEFAULT 10,
      antispam_enabled INTEGER DEFAULT 1,
      antilinks_enabled INTEGER DEFAULT 0,
      bad_words TEXT DEFAULT '',
      starboard_channel TEXT, starboard_threshold INTEGER DEFAULT 3,
      suggestion_channel TEXT,
      economy_enabled INTEGER DEFAULT 1,
      temp_voice_channel TEXT,
      xp_enabled INTEGER DEFAULT 1,
      xp_multiplier REAL DEFAULT 1.0,
      xp_cooldown INTEGER DEFAULT 60,
      no_xp_channels TEXT DEFAULT '',
      created_at INTEGER DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS warns (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL, user_id TEXT NOT NULL,
      moderator_id TEXT NOT NULL, reason TEXT NOT NULL,
      created_at INTEGER DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL, channel_id TEXT NOT NULL,
      user_id TEXT NOT NULL, panel_name TEXT DEFAULT 'Support',
      status TEXT DEFAULT 'open',
      created_at INTEGER DEFAULT (strftime('%s','now')),
      closed_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS ticket_panels (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL, panel_name TEXT NOT NULL,
      category_id TEXT,
      message TEXT DEFAULT 'Cliquez sur le bouton pour ouvrir un ticket.',
      embed_color TEXT DEFAULT '5865F2',
      UNIQUE(guild_id, panel_name)
    );

    CREATE TABLE IF NOT EXISTS mod_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL, action TEXT NOT NULL,
      target_id TEXT NOT NULL, moderator_id TEXT NOT NULL,
      reason TEXT, extra TEXT,
      created_at INTEGER DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS notes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL, user_id TEXT NOT NULL,
      moderator_id TEXT NOT NULL, content TEXT NOT NULL,
      created_at INTEGER DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS levels (
      guild_id TEXT NOT NULL, user_id TEXT NOT NULL,
      xp INTEGER DEFAULT 0, level INTEGER DEFAULT 0,
      messages INTEGER DEFAULT 0, last_xp INTEGER DEFAULT 0,
      PRIMARY KEY(guild_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS giveaways (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL, channel_id TEXT NOT NULL,
      message_id TEXT, host_id TEXT NOT NULL,
      prize TEXT NOT NULL, winners INTEGER DEFAULT 1,
      required_role TEXT,
      ends_at INTEGER NOT NULL,
      ended INTEGER DEFAULT 0,
      participants TEXT DEFAULT '[]',
      winner_ids TEXT DEFAULT '[]',
      created_at INTEGER DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS reaction_role_panels (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL, channel_id TEXT NOT NULL,
      message_id TEXT, title TEXT NOT NULL,
      description TEXT,
      created_at INTEGER DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS reaction_roles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      panel_id INTEGER NOT NULL,
      role_id TEXT NOT NULL, label TEXT NOT NULL,
      emoji TEXT, style INTEGER DEFAULT 1,
      FOREIGN KEY(panel_id) REFERENCES reaction_role_panels(id)
    );

    CREATE TABLE IF NOT EXISTS tags (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL, name TEXT NOT NULL,
      content TEXT NOT NULL, author_id TEXT NOT NULL,
      uses INTEGER DEFAULT 0,
      created_at INTEGER DEFAULT (strftime('%s','now')),
      UNIQUE(guild_id, name)
    );

    CREATE TABLE IF NOT EXISTS economy (
      guild_id TEXT NOT NULL, user_id TEXT NOT NULL,
      balance INTEGER DEFAULT 0,
      last_daily INTEGER DEFAULT 0,
      last_work INTEGER DEFAULT 0,
      total_earned INTEGER DEFAULT 0,
      PRIMARY KEY(guild_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS suggestions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL, channel_id TEXT NOT NULL,
      message_id TEXT, author_id TEXT NOT NULL,
      content TEXT NOT NULL, status TEXT DEFAULT 'pending',
      upvotes INTEGER DEFAULT 0, downvotes INTEGER DEFAULT 0,
      reviewer_id TEXT, review_reason TEXT,
      created_at INTEGER DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS role_rewards (
      guild_id TEXT NOT NULL, level INTEGER NOT NULL,
      role_id TEXT NOT NULL,
      PRIMARY KEY(guild_id, level)
    );

    CREATE TABLE IF NOT EXISTS reminders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL, guild_id TEXT,
      channel_id TEXT, message TEXT NOT NULL,
      remind_at INTEGER NOT NULL, sent INTEGER DEFAULT 0,
      created_at INTEGER DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS starboard (
      guild_id TEXT NOT NULL, message_id TEXT NOT NULL,
      starboard_message_id TEXT, star_count INTEGER DEFAULT 0,
      PRIMARY KEY(guild_id, message_id)
    );

    CREATE TABLE IF NOT EXISTS tempbans (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      guild_id TEXT NOT NULL, user_id TEXT NOT NULL,
      moderator_id TEXT NOT NULL, reason TEXT,
      unban_at INTEGER NOT NULL, unbanned INTEGER DEFAULT 0,
      created_at INTEGER DEFAULT (strftime('%s','now'))
    );
  `);

  // Migrations : colonnes ajoutées après coup
  const safeMigrations = [
    `ALTER TABLE economy ADD COLUMN last_work INTEGER DEFAULT 0`,
    `ALTER TABLE guild_config ADD COLUMN xp_enabled INTEGER DEFAULT 1`,
    `ALTER TABLE guild_config ADD COLUMN xp_multiplier REAL DEFAULT 1.0`,
    `ALTER TABLE guild_config ADD COLUMN xp_cooldown INTEGER DEFAULT 60`,
    `ALTER TABLE guild_config ADD COLUMN no_xp_channels TEXT DEFAULT ''`,
  ];
  for (const sql of safeMigrations) {
    try { db.exec(sql); } catch {}
  }

  console.log('[DB] Base de données initialisée.');
  return db;
}

function getDb() { if (!db) throw new Error('DB non initialisée'); return db; }
const _stmts = {};
function s(sql) { if (!_stmts[sql]) _stmts[sql] = getDb().prepare(sql); return _stmts[sql]; }

// ── Guild Config ──────────────────────────────────────────────────────────────
const ALLOWED_KEYS = [
  'log_channel','welcome_channel','welcome_message','auto_role','mod_role',
  'ticket_category','antinuke_enabled','antinuke_threshold','antinuke_window',
  'antiraid_enabled','antiraid_joins','antiraid_window',
  'antispam_enabled','antilinks_enabled','bad_words',
  'starboard_channel','starboard_threshold','suggestion_channel',
  'economy_enabled','temp_voice_channel',
  'xp_enabled','xp_multiplier','xp_cooldown','no_xp_channels',
];
function getGuildConfig(guildId) {
  let r = s('SELECT * FROM guild_config WHERE guild_id=?').get(guildId);
  if (!r) { s('INSERT INTO guild_config (guild_id) VALUES (?)').run(guildId); r = s('SELECT * FROM guild_config WHERE guild_id=?').get(guildId); }
  return r;
}
function setGuildConfig(guildId, key, value) {
  if (!ALLOWED_KEYS.includes(key)) throw new Error(`Clé invalide: ${key}`);
  getGuildConfig(guildId);
  getDb().prepare(`UPDATE guild_config SET ${key}=? WHERE guild_id=?`).run(value, guildId);
}

// ── Warns ──────────────────────────────────────────────────────────────────────
function addWarn(guildId, userId, modId, reason)  { return s('INSERT INTO warns(guild_id,user_id,moderator_id,reason) VALUES(?,?,?,?)').run(guildId,userId,modId,reason); }
function getWarns(guildId, userId)                 { return s('SELECT * FROM warns WHERE guild_id=? AND user_id=? ORDER BY created_at DESC').all(guildId,userId); }
function clearWarns(guildId, userId)               { return s('DELETE FROM warns WHERE guild_id=? AND user_id=?').run(guildId,userId); }

// ── Notes ─────────────────────────────────────────────────────────────────────
function addNote(guildId, userId, modId, content)  { return s('INSERT INTO notes(guild_id,user_id,moderator_id,content) VALUES(?,?,?,?)').run(guildId,userId,modId,content); }
function getNotes(guildId, userId)                 { return s('SELECT * FROM notes WHERE guild_id=? AND user_id=? ORDER BY created_at DESC').all(guildId,userId); }
function deleteNote(id)                            { return s('DELETE FROM notes WHERE id=?').run(id); }

// ── Tickets ────────────────────────────────────────────────────────────────────
function createTicket(gId,cId,uId,pName)           { return s('INSERT INTO tickets(guild_id,channel_id,user_id,panel_name) VALUES(?,?,?,?)').run(gId,cId,uId,pName); }
function getTicketByChannel(channelId)             { return s('SELECT * FROM tickets WHERE channel_id=?').get(channelId); }
function closeTicket(channelId)                    { return getDb().prepare("UPDATE tickets SET status='closed',closed_at=strftime('%s','now') WHERE channel_id=?").run(channelId); }
function getTicketPanel(guildId, panelName)        { return s('SELECT * FROM ticket_panels WHERE guild_id=? AND panel_name=?').get(guildId,panelName); }
function upsertTicketPanel(guildId,panelName,categoryId,message,color) {
  return getDb().prepare(`INSERT INTO ticket_panels(guild_id,panel_name,category_id,message,embed_color) VALUES(?,?,?,?,?) ON CONFLICT(guild_id,panel_name) DO UPDATE SET category_id=excluded.category_id,message=excluded.message,embed_color=excluded.embed_color`).run(guildId,panelName,categoryId,message,color);
}
function getAllPanels(guildId)                      { return s('SELECT * FROM ticket_panels WHERE guild_id=?').all(guildId); }

// ── Mod Logs ───────────────────────────────────────────────────────────────────
function addModLog(gId,action,targetId,modId,reason,extra) { return s('INSERT INTO mod_logs(guild_id,action,target_id,moderator_id,reason,extra) VALUES(?,?,?,?,?,?)').run(gId,action,targetId,modId,reason,extra||null); }
function getModLogs(guildId,userId,limit=10)        { return getDb().prepare('SELECT * FROM mod_logs WHERE guild_id=? AND target_id=? ORDER BY created_at DESC LIMIT ?').all(guildId,userId,limit); }

// ── Levels ─────────────────────────────────────────────────────────────────────
function getLevel(guildId, userId) {
  let r = s('SELECT * FROM levels WHERE guild_id=? AND user_id=?').get(guildId,userId);
  if (!r) { s('INSERT INTO levels(guild_id,user_id) VALUES(?,?)').run(guildId,userId); r = s('SELECT * FROM levels WHERE guild_id=? AND user_id=?').get(guildId,userId); }
  return r;
}
function addXp(guildId, userId, xpAmount, cooldown=60) {
  const row = getLevel(guildId, userId);
  const now = Math.floor(Date.now()/1000);
  if (now-(row.last_xp||0) < cooldown) return null;
  const newXp    = (row.xp||0)+xpAmount;
  const newLevel = Math.floor(0.1*Math.sqrt(newXp));
  getDb().prepare('UPDATE levels SET xp=?,level=?,messages=?,last_xp=? WHERE guild_id=? AND user_id=?').run(newXp,newLevel,(row.messages||0)+1,now,guildId,userId);
  return { leveledUp: newLevel>(row.level||0), newLevel, oldLevel: row.level||0 };
}
function setUserXp(guildId, userId, xp) {
  getLevel(guildId,userId);
  const level = Math.floor(0.1*Math.sqrt(xp));
  getDb().prepare('UPDATE levels SET xp=?,level=? WHERE guild_id=? AND user_id=?').run(xp,level,guildId,userId);
}
function setUserLevel(guildId, userId, level) {
  getLevel(guildId,userId);
  const xp = Math.pow(level/0.1,2);
  getDb().prepare('UPDATE levels SET xp=?,level=? WHERE guild_id=? AND user_id=?').run(Math.floor(xp),level,guildId,userId);
}
function resetXp(guildId, userId) {
  getLevel(guildId,userId);
  getDb().prepare('UPDATE levels SET xp=0,level=0,messages=0,last_xp=0 WHERE guild_id=? AND user_id=?').run(guildId,userId);
}
function getLeaderboard(guildId,limit=10)          { return getDb().prepare('SELECT * FROM levels WHERE guild_id=? ORDER BY xp DESC LIMIT ?').all(guildId,limit); }

// ── Giveaways ──────────────────────────────────────────────────────────────────
function createGiveaway(gId,cId,hostId,prize,winners,requiredRole,endsAt) { return s('INSERT INTO giveaways(guild_id,channel_id,host_id,prize,winners,required_role,ends_at) VALUES(?,?,?,?,?,?,?)').run(gId,cId,hostId,prize,winners,requiredRole,endsAt); }
function setGiveawayMessageId(id, msgId)           { s('UPDATE giveaways SET message_id=? WHERE id=?').run(msgId,id); }
function getGiveaway(id)                           { return s('SELECT * FROM giveaways WHERE id=?').get(id); }
function getGiveawayByMessage(msgId)               { return s('SELECT * FROM giveaways WHERE message_id=?').get(msgId); }
function getActiveGiveaways(guildId)               { return s('SELECT * FROM giveaways WHERE guild_id=? AND ended=0').all(guildId); }
function getAllActiveGiveaways()                    { return s('SELECT * FROM giveaways WHERE ended=0').all(); }
function updateGiveawayParticipants(id, participants) { s('UPDATE giveaways SET participants=? WHERE id=?').run(JSON.stringify(participants),id); }
function endGiveaway(id, winnerIds)                { s("UPDATE giveaways SET ended=1,winner_ids=? WHERE id=?").run(JSON.stringify(winnerIds),id); }

// ── Reaction Roles ─────────────────────────────────────────────────────────────
function createRRPanel(gId,cId,title,desc)         { return s('INSERT INTO reaction_role_panels(guild_id,channel_id,title,description) VALUES(?,?,?,?)').run(gId,cId,title,desc||null); }
function setRRPanelMessageId(panelId,msgId)        { s('UPDATE reaction_role_panels SET message_id=? WHERE id=?').run(msgId,panelId); }
function getRRPanel(panelId)                       { return s('SELECT * FROM reaction_role_panels WHERE id=?').get(panelId); }
function getRRPanelByMessage(msgId)                { return s('SELECT * FROM reaction_role_panels WHERE message_id=?').get(msgId); }
function getRRPanels(guildId)                      { return s('SELECT * FROM reaction_role_panels WHERE guild_id=?').all(guildId); }
function addRRRole(panelId,roleId,label,emoji,style) { return s('INSERT INTO reaction_roles(panel_id,role_id,label,emoji,style) VALUES(?,?,?,?,?)').run(panelId,roleId,label,emoji||null,style||1); }
function getRRRoles(panelId)                       { return s('SELECT * FROM reaction_roles WHERE panel_id=?').all(panelId); }

// ── Tags ───────────────────────────────────────────────────────────────────────
function createTag(gId,name,content,authorId)      { return getDb().prepare('INSERT INTO tags(guild_id,name,content,author_id) VALUES(?,?,?,?)').run(gId,name,content,authorId); }
function getTag(guildId,name)                      { return s('SELECT * FROM tags WHERE guild_id=? AND name=?').get(guildId,name); }
function incrementTagUses(guildId,name)            { s('UPDATE tags SET uses=uses+1 WHERE guild_id=? AND name=?').run(guildId,name); }
function deleteTag(guildId,name)                   { return s('DELETE FROM tags WHERE guild_id=? AND name=?').run(guildId,name); }
function listTags(guildId)                         { return s('SELECT name,uses,author_id FROM tags WHERE guild_id=? ORDER BY uses DESC').all(guildId); }
function updateTag(guildId,name,content)           { return s('UPDATE tags SET content=? WHERE guild_id=? AND name=?').run(content,guildId,name); }

// ── Economy ────────────────────────────────────────────────────────────────────
function getEconomy(guildId, userId) {
  let r = s('SELECT * FROM economy WHERE guild_id=? AND user_id=?').get(guildId,userId);
  if (!r) { s('INSERT INTO economy(guild_id,user_id) VALUES(?,?)').run(guildId,userId); r = s('SELECT * FROM economy WHERE guild_id=? AND user_id=?').get(guildId,userId); }
  return r;
}
function addCoins(guildId,userId,amount) {
  getEconomy(guildId,userId);
  return s('UPDATE economy SET balance=balance+?,total_earned=total_earned+? WHERE guild_id=? AND user_id=?').run(amount,Math.max(0,amount),guildId,userId);
}
function deductCoins(guildId,userId,amount) {
  getEconomy(guildId,userId);
  return s('UPDATE economy SET balance=MAX(0,balance-?) WHERE guild_id=? AND user_id=?').run(amount,guildId,userId);
}
function transferCoins(guildId,fromId,toId,amount) {
  deductCoins(guildId,fromId,amount);
  addCoins(guildId,toId,amount);
}
function setLastDaily(guildId,userId,ts)            { s('UPDATE economy SET last_daily=? WHERE guild_id=? AND user_id=?').run(ts,guildId,userId); }
function setLastWork(guildId,userId,ts)             { s('UPDATE economy SET last_work=? WHERE guild_id=? AND user_id=?').run(ts,guildId,userId); }
function getEcoLeaderboard(guildId,limit=10)        { return getDb().prepare('SELECT * FROM economy WHERE guild_id=? ORDER BY balance DESC LIMIT ?').all(guildId,limit); }

// ── Suggestions ────────────────────────────────────────────────────────────────
function createSuggestion(gId,cId,authorId,content) { return s('INSERT INTO suggestions(guild_id,channel_id,author_id,content) VALUES(?,?,?,?)').run(gId,cId,authorId,content); }
function setSuggestionMessageId(id,msgId)            { s('UPDATE suggestions SET message_id=? WHERE id=?').run(msgId,id); }
function getSuggestionByMessage(msgId)               { return s('SELECT * FROM suggestions WHERE message_id=?').get(msgId); }
function updateSuggestionVotes(id,upvotes,downvotes) { s('UPDATE suggestions SET upvotes=?,downvotes=? WHERE id=?').run(upvotes,downvotes,id); }
function reviewSuggestion(id,status,reviewerId,reason) { s('UPDATE suggestions SET status=?,reviewer_id=?,review_reason=? WHERE id=?').run(status,reviewerId,reason,id); }

// ── Role Rewards ───────────────────────────────────────────────────────────────
function setRoleReward(guildId,level,roleId)         { return getDb().prepare('INSERT INTO role_rewards(guild_id,level,role_id) VALUES(?,?,?) ON CONFLICT(guild_id,level) DO UPDATE SET role_id=excluded.role_id').run(guildId,level,roleId); }
function getRoleRewards(guildId)                     { return s('SELECT * FROM role_rewards WHERE guild_id=? ORDER BY level ASC').all(guildId); }
function getRoleRewardForLevel(guildId,level)        { return s('SELECT * FROM role_rewards WHERE guild_id=? AND level=?').get(guildId,level); }
function deleteRoleReward(guildId,level)             { return s('DELETE FROM role_rewards WHERE guild_id=? AND level=?').run(guildId,level); }

// ── Reminders ──────────────────────────────────────────────────────────────────
function createReminder(userId,guildId,channelId,message,remindAt) { return s('INSERT INTO reminders(user_id,guild_id,channel_id,message,remind_at) VALUES(?,?,?,?,?)').run(userId,guildId,channelId,message,remindAt); }
function getPendingReminders()                       { return getDb().prepare('SELECT * FROM reminders WHERE sent=0 AND remind_at<=?').all(Math.floor(Date.now()/1000)); }
function markReminderSent(id)                        { s('UPDATE reminders SET sent=1 WHERE id=?').run(id); }
function getUserReminders(userId)                    { return s('SELECT * FROM reminders WHERE user_id=? AND sent=0 ORDER BY remind_at ASC').all(userId); }
function deleteReminder(id,userId)                   { return s('DELETE FROM reminders WHERE id=? AND user_id=?').run(id,userId); }

// ── Starboard ──────────────────────────────────────────────────────────────────
function getStarboard(guildId,messageId)             { return s('SELECT * FROM starboard WHERE guild_id=? AND message_id=?').get(guildId,messageId); }
function upsertStarboard(guildId,messageId,starboardMsgId,count) { return getDb().prepare('INSERT INTO starboard(guild_id,message_id,starboard_message_id,star_count) VALUES(?,?,?,?) ON CONFLICT(guild_id,message_id) DO UPDATE SET starboard_message_id=excluded.starboard_message_id,star_count=excluded.star_count').run(guildId,messageId,starboardMsgId,count); }

// ── Tempbans ──────────────────────────────────────────────────────────────────
function createTempban(guildId,userId,modId,reason,unbanAt) { return s('INSERT INTO tempbans(guild_id,user_id,moderator_id,reason,unban_at) VALUES(?,?,?,?,?)').run(guildId,userId,modId,reason,unbanAt); }
function getPendingUnbans()                          { return getDb().prepare('SELECT * FROM tempbans WHERE unbanned=0 AND unban_at<=?').all(Math.floor(Date.now()/1000)); }
function markUnbanned(id)                            { s('UPDATE tempbans SET unbanned=1 WHERE id=?').run(id); }

module.exports = {
  initDatabase, getDb,
  getGuildConfig, setGuildConfig,
  addWarn, getWarns, clearWarns,
  addNote, getNotes, deleteNote,
  createTicket, getTicketByChannel, closeTicket, getTicketPanel, upsertTicketPanel, getAllPanels,
  addModLog, getModLogs,
  getLevel, addXp, setUserXp, setUserLevel, resetXp, getLeaderboard,
  createGiveaway, setGiveawayMessageId, getGiveaway, getGiveawayByMessage,
  getActiveGiveaways, getAllActiveGiveaways, updateGiveawayParticipants, endGiveaway,
  createRRPanel, setRRPanelMessageId, getRRPanel, getRRPanelByMessage, getRRPanels, addRRRole, getRRRoles,
  createTag, getTag, incrementTagUses, deleteTag, listTags, updateTag,
  getEconomy, addCoins, deductCoins, transferCoins, setLastDaily, setLastWork, getEcoLeaderboard,
  createSuggestion, setSuggestionMessageId, getSuggestionByMessage, updateSuggestionVotes, reviewSuggestion,
  setRoleReward, getRoleRewards, getRoleRewardForLevel, deleteRoleReward,
  createReminder, getPendingReminders, markReminderSent, getUserReminders, deleteReminder,
  getStarboard, upsertStarboard,
  createTempban, getPendingUnbans, markUnbanned,
};
